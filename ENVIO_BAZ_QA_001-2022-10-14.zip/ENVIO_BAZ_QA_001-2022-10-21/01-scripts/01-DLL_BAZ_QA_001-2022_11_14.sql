ALTER TABLE OPERACIONES.TAMBCATA_CATEGORIAS_LN
ADD ind_pep VARCHAR2(2);

ALTER TABLE OPERACIONES.TAMBCATA_CATEGORIAS_LN
ADD CONSTRAINT check_tambcata_pep CHECK (ind_pep IN('S','N'));

--****************************************************************************

--OPERACIONES.CLIENTES
ALTER TABLE operaciones.cliente
ADD nombre_comercial VARCHAR2(2000);

ALTER TABLE operaciones.cliente
ADD sucursales NUMBER;

ALTER TABLE operaciones.cliente
ADD no_empleados INTEGER;

ALTER TABLE operaciones.cliente
ADD dui_rep_legal VARCHAR2(20);

ALTER TABLE operaciones.cliente
ADD actividad_economica_sec VARCHAR2(2000);

ALTER TABLE operaciones.cliente
ADD procedencia_otros_ingresos VARCHAR2(2000);

ALTER TABLE operaciones.cliente
ADD cali_migra_rep_legal VARCHAR2(2000);

ALTER TABLE operaciones.cliente
ADD pasaporte_rep_legal VARCHAR2(20);

ALTER TABLE operaciones.cliente
ADD carne_resi_rep_legal VARCHAR2(20);

ALTER TABLE operaciones.cliente
ADD sexo_rep_legal VARCHAR2(1);

ALTER TABLE operaciones.cliente
ADD RELACION_CON_CLIE VARCHAR2(1);

ALTER TABLE OPERACIONES.CLIENTE
ADD CONSTRAINT check_rela_clie CHECK (relacion_con_clie IN('S','N'));

ALTER TABLE operaciones.cliente
ADD LUGAR_Y_FECHA_ENTRE VARCHAR2(200);

ALTER TABLE operaciones.cliente
ADD carne_resi VARCHAR2(20);

ALTER TABLE operaciones.cliente
ADD cali_migra VARCHAR2(200);

ALTER TABLE operaciones.cliente
ADD nombre_beneficiario VARCHAR2(200);

ALTER TABLE operaciones.cliente
ADD negocio_con_estado VARCHAR2(2);

ALTER TABLE operaciones.cliente
ADD nombre_sociedad VARCHAR2(200);

ALTER TABLE operaciones.cliente
ADD relac_con_sociedad VARCHAR2(200);

ALTER TABLE operaciones.cliente
ADD nacionalidad_soci VARCHAR2(200);


ALTER TABLE operaciones.cliente
ADD cod_ocupacion VARCHAR2(6);
--OPERACIONES.TAMBACCLFATCA

ALTER TABLE operaciones.tambacclfatca
ADD lugar_y_dob VARCHAR2(200);

ALTER TABLE operaciones.tambacclfatca
ADD acc_ind_nombre VARCHAR2(200);

ALTER TABLE operaciones.tambacclfatca
ADD nombre_replegal_accio VARCHAR2(200);

ALTER TABLE operaciones.tambacclfatca
ADD dob_replegal DATE;

ALTER TABLE operaciones.tambacclfatca
ADD nacionalidad_replegal VARCHAR2(200);

ALTER TABLE operaciones.tambacclfatca
ADD tipo_doc_replegal VARCHAR2(200);

/*ALTER TABLE operaciones.tambacclfatca
ADD no_doc_replegal VARCHAR2(200);*/

ALTER TABLE operaciones.tambacclfatca
ADD porc_participa_accionista_ind NUMBER(12,1);

ALTER TABLE operaciones.tambacclfatca
ADD nomb_soci_participa VARCHAR2(200);

ALTER TABLE operaciones.tambacclfatca
ADD porc_participa_soci_partici VARCHAR2(200);

ALTER TABLE operaciones.tambacclfatca
ADD no_doc_replegal VARCHAR2(200);

ALTER TABLE operaciones.tambacclfatca
ADD nacionalidad_accio_direct VARCHAR2(200);

ALTER TABLE operaciones.tambacclfatca
ADD nacionalidad_accio_indirect VARCHAR2(200);

ALTER TABLE operaciones.tambacclfatca
ADD nacionalidad_soci_partici VARCHAR2(200);

--OPERACIONES.BENEFICIARIO

ALTER TABLE operaciones.beneficiario
ADD no_docu_benefi VARCHAR2(20);

ALTER TABLE operaciones.beneficiario
ADD tipo_docu_benefi VARCHAR2(20);
--******************
--*****************
--*****************
--***********VM*****
ALTER TABLE operaciones.dgeneral 
ADD RECIBE_EMAIL_ACT_PROHIBIDA VARCHAR2(500);

COMMENT ON COLUMN operaciones.dgeneral.recibe_email_act_prohibida IS
'Email para notificaciones de actividades prohibidas';
---
ALTER TABLE crm_customer.tacrcat_act_economica_ciiu
ADD COD_T_ACTIVIDAD INTEGER; 

---************** CLIENTES
ALTER TABLE operaciones.cliente
ADD periodicidad_operaciones VARCHAR2(200);

ALTER TABLE operaciones.cliente
ADD conocido_por VARCHAR2(200);


ALTER TABLE operaciones.cliente
ADD actividad_real_cliente varchar2(2000);

COMMENT ON COLUMN operaciones.cliente.actividad_real_cliente 
IS 'Descripci�n de la actividad real del cliente';


--******************EMISIONES

ALTER TABLE operaciones.tacemibv 
ADD descripcion_emision VARCHAR2(2000);

ALTER TABLE operaciones.tacemibv 
ADD dias_al_vencimiento number;

--******************BOLETA

ALTER TABLE operaciones.boleta 
ADD cod_pais_inter varchar2(3);

COMMENT ON COLUMN 
operaciones.boleta.cod_pais_inter is 
'Pa�s de mercado intermediario regional';

ALTER TABLE operaciones.boleta 
ADD cod_pais_benef varchar2(3);

COMMENT ON COLUMN 
operaciones.boleta.cod_pais_benef is 
'Pa�s beficiario en mercado regional';

 