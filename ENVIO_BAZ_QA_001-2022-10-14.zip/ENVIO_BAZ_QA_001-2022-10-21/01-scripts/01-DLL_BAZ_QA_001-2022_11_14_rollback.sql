ALTER TABLE OPERACIONES.TAMBCATA_CATEGORIAS_LN
DROP COLUMN  ind_pep;

--****************************************************************************

--OPERACIONES.CLIENTES
ALTER TABLE operaciones.cliente
DROP COLUMN  nombre_comercial;

ALTER TABLE operaciones.cliente
DROP COLUMN  sucursales;

ALTER TABLE operaciones.cliente
DROP COLUMN  no_empleados;

ALTER TABLE operaciones.cliente
DROP COLUMN  dui_rep_legal;

ALTER TABLE operaciones.cliente
DROP COLUMN  actividad_economica_sec;

ALTER TABLE operaciones.cliente
DROP COLUMN  procedencia_otros_ingresos;

ALTER TABLE operaciones.cliente
DROP COLUMN  cali_migra_rep_legal;

ALTER TABLE operaciones.cliente
DROP COLUMN  pasaporte_rep_legal;

ALTER TABLE operaciones.cliente
DROP COLUMN  carne_resi_rep_legal;

ALTER TABLE operaciones.cliente
DROP COLUMN  sexo_rep_legal;

ALTER TABLE operaciones.cliente
DROP COLUMN  RELACION_CON_CLIE;

ALTER TABLE operaciones.cliente
DROP COLUMN  LUGAR_Y_FECHA_ENTRE;

ALTER TABLE operaciones.cliente
DROP COLUMN  carne_resi;

ALTER TABLE operaciones.cliente
DROP COLUMN  cali_migra;

ALTER TABLE operaciones.cliente
DROP COLUMN  nombre_beneficiario;

ALTER TABLE operaciones.cliente
DROP COLUMN  negocio_con_estado;

ALTER TABLE operaciones.cliente
DROP COLUMN  nombre_sociedad;

ALTER TABLE operaciones.cliente
DROP COLUMN  relac_con_sociedad;

ALTER TABLE operaciones.cliente
DROP COLUMN  nacionalidad_soci;

ALTER TABLE operaciones.cliente
DROP COLUMN cod_ocupacion;

--OPERACIONES.TAMBACCLFATCA

ALTER TABLE operaciones.tambacclfatca
DROP COLUMN  lugar_y_dob;

ALTER TABLE operaciones.tambacclfatca
DROP COLUMN  acc_ind_nombre;

ALTER TABLE operaciones.tambacclfatca
DROP COLUMN  nombre_replegal_accio;

ALTER TABLE operaciones.tambacclfatca
DROP COLUMN  dob_replegal;

ALTER TABLE operaciones.tambacclfatca
DROP COLUMN  nacionalidad_replegal;

ALTER TABLE operaciones.tambacclfatca
DROP COLUMN  tipo_doc_replegal;

/*ALTER TABLE operaciones.tambacclfatca
DROP COLUMN  no_doc_replegal;*/

ALTER TABLE operaciones.tambacclfatca
DROP COLUMN  porc_participa_accionista_ind;

ALTER TABLE operaciones.tambacclfatca
DROP COLUMN  nomb_soci_participa;

ALTER TABLE operaciones.tambacclfatca
DROP COLUMN  porc_participa_soci_partici;

ALTER TABLE operaciones.tambacclfatca
DROP COLUMN  no_doc_replegal;

ALTER TABLE operaciones.tambacclfatca
DROP COLUMN  nacionalidad_accio_direct;

ALTER TABLE operaciones.tambacclfatca
DROP COLUMN  nacionalidad_accio_indirect;

ALTER TABLE operaciones.tambacclfatca
DROP COLUMN  nacionalidad_soci_partici;

--OPERACIONES.BENEFICIARIO

ALTER TABLE operaciones.beneficiario
DROP COLUMN  no_docu_benefi;

ALTER TABLE operaciones.beneficiario
DROP COLUMN  tipo_docu_benefi;


--***********VM*****
--***********************************************
--***********************************************
--***********************************************
--***********************************************
ALTER TABLE operaciones.dgeneral 
DROP COLUMN RECIBE_EMAIL_ACT_PROHIBIDA;
--
ALTER TABLE crm_customer.tacrcat_act_economica_ciiu
DROP COLUMN COD_T_ACTIVIDAD;


--**********CLIENTE
ALTER TABLE operaciones.cliente
DROP COLUMN periodicidad_operaciones;

ALTER TABLE operaciones.cliente
DROP COLUMN conocido_por;

ALTER TABLE operaciones.cliente
DROP COLUMN actividad_real_cliente;

--******************EMISIONES

ALTER TABLE operaciones.tacemibv 
DROP COLUMN descripcion_emision;

ALTER TABLE operaciones.tacemibv 
DROP COLUMN dias_al_vencimiento;

--******************BOLETA
ALTER TABLE operaciones.boleta 
DROP COLUMN cod_pais_inter;

ALTER TABLE operaciones.boleta 
DROP COLUMN cod_pais_BENEF;



