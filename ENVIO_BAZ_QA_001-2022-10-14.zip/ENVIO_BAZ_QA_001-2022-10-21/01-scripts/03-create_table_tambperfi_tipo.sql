CREATE TABLE OPERACIONES.TAMBPERFI_TIPO
(
  COD_CIA  VARCHAR2(3 BYTE),
  TIPO     VARCHAR2(1 BYTE),
  ID       INTEGER,
  DESDE    NUMBER,
  HASTA    NUMBER
)
TABLESPACE OPERACIONES
RESULT_CACHE (MODE DEFAULT)
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MAXSIZE          UNLIMITED
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
            FLASH_CACHE      DEFAULT
            CELL_FLASH_CACHE DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


--  There is no statement for index OPERACIONES.SYS_C0030784.
--  The object is created when the parent object is created.

ALTER TABLE OPERACIONES.TAMBPERFI_TIPO ADD (
  CONSTRAINT CHECK_TAMBPERFI_TIPO
  CHECK (tipo IN('J','N', 'I'))
  ENABLE VALIDATE,
  PRIMARY KEY
  (COD_CIA, TIPO, ID)
  USING INDEX
    TABLESPACE OPERACIONES
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               )
  ENABLE VALIDATE);
  
    GRANT ALL ON  OPERACIONES.TAMBPERFI_TIPO
  TO
  RL_MENU_ADMIN_OPERACIONES,
  RL_SAIF_CUMPLIMIENTO,
  RL_SAIF_OPERADOR,
  RL_SAIF_OPERADOR_CONTABLE,
  RL_SAIF_GERENTE,
  RL_SAIF_SUPERVISOR_OPERACIONES,
  RL_SAIF_CORREDOR;

