CREATE TABLE OPERACIONES.TAMBVALORES_TIPO_PERFIL
(
  COD_CIA          VARCHAR2(3 BYTE),
  TIPO             VARCHAR2(1 BYTE),
  ID_PREGUNTA      INTEGER,
  R1               NUMBER,
  R2               NUMBER,
  R3               NUMBER,
  R4               NUMBER,
  DESCRI_PREGUNTA  VARCHAR2(2000 BYTE)
)
TABLESPACE OPERACIONES
RESULT_CACHE (MODE DEFAULT)
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MAXSIZE          UNLIMITED
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
            FLASH_CACHE      DEFAULT
            CELL_FLASH_CACHE DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;

COMMENT ON COLUMN OPERACIONES.TAMBVALORES_TIPO_PERFIL.DESCRI_PREGUNTA IS 'Pregunta realizada en el formulario por tipo perfil del cliente';



--  There is no statement for index OPERACIONES.SYS_C0030785.
--  The object is created when the parent object is created.

ALTER TABLE OPERACIONES.TAMBVALORES_TIPO_PERFIL ADD (
  CONSTRAINT NO_NEG
  CHECK (R1>=0 AND R2>=0 AND R3>=0 AND R4 >=0)
  ENABLE VALIDATE,
  PRIMARY KEY
  (COD_CIA, TIPO, ID_PREGUNTA)
  USING INDEX
    TABLESPACE OPERACIONES
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               )
  ENABLE VALIDATE);

  GRANT ALL ON  OPERACIONES.TAMBVALORES_TIPO_PERFIL
  TO
  RL_MENU_ADMIN_OPERACIONES,
  RL_SAIF_CUMPLIMIENTO,
  RL_SAIF_OPERADOR,
  RL_SAIF_OPERADOR_CONTABLE,
  RL_SAIF_GERENTE,
  RL_SAIF_SUPERVISOR_OPERACIONES,
  RL_SAIF_CORREDOR;
