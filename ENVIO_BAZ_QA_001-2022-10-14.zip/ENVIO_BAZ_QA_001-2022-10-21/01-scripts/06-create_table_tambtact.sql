/* tipos de actividades*/
create table operaciones.tambtact(
cod_cia varchar2(2) not null,
cod_t_actividad integer not null,
descripcion varchar2(200),
bloqueo_automatico_actividad varchar2(1) default 'N',
primary key(cod_cia, cod_t_actividad));

  GRANT ALL ON  OPERACIONES.tambtact
  TO
  RL_MENU_ADMIN_OPERACIONES,
  RL_SAIF_CUMPLIMIENTO,
  RL_SAIF_OPERADOR,
  RL_SAIF_OPERADOR_CONTABLE,
  RL_SAIF_GERENTE,
  RL_SAIF_SUPERVISOR_OPERACIONES,
  RL_SAIF_CORREDOR;

