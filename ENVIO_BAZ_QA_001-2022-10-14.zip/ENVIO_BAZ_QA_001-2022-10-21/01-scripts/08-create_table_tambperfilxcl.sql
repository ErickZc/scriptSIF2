CREATE TABLE OPERACIONES.TAMBPERFILXCL
(
  COD_CIA          VARCHAR2(3 BYTE)             NOT NULL,
  CODCLIENTE       VARCHAR2(6 BYTE)             NOT NULL,
  TIPO             VARCHAR2(1 BYTE)             NOT NULL,
  ID_PREGUNTA      INTEGER                      NOT NULL,
  DESCRI_PREGUNTA  VARCHAR2(2000 BYTE)          NOT NULL,
  ID_RESPUESTA     NUMBER                       NOT NULL,
  PUNTUACION       NUMBER                       NOT NULL
)
TABLESPACE OPERACIONES
RESULT_CACHE (MODE DEFAULT)
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MAXSIZE          UNLIMITED
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
            FLASH_CACHE      DEFAULT
            CELL_FLASH_CACHE DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


--  There is no statement for index OPERACIONES.SYS_C0031779.
--  The object is created when the parent object is created.

ALTER TABLE OPERACIONES.TAMBPERFILXCL ADD (
  PRIMARY KEY
  (COD_CIA, CODCLIENTE, ID_PREGUNTA)
  USING INDEX
    TABLESPACE OPERACIONES
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               )
  ENABLE VALIDATE);

  GRANT ALL ON  OPERACIONES.tambperfilxcl
  TO
  RL_MENU_ADMIN_OPERACIONES,
  RL_SAIF_CUMPLIMIENTO,
  RL_SAIF_OPERADOR,
  RL_SAIF_OPERADOR_CONTABLE,
  RL_SAIF_GERENTE,
  RL_SAIF_SUPERVISOR_OPERACIONES,
  RL_SAIF_CORREDOR;


