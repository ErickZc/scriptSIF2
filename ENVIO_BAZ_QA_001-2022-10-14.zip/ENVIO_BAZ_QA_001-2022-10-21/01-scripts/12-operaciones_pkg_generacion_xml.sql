CREATE OR REPLACE PACKAGE OPERACIONES.generacion_xml
IS
    PROCEDURE gen_neve_cliente(p_file_id IN INTEGER,
                                p_cod_cia IN VARCHAR2,
                                p_fecha_ini IN DATE,
                                p_fecha_fin IN DATE);

    PROCEDURE gen_neve_opera_val_ext(p_file_id IN INTEGER,
                                p_cod_cia IN VARCHAR2,
                                p_fecha_ini IN DATE,
                                p_fecha_fin IN DATE); 
    
    PROCEDURE gen_saldo_cuenta(p_file_id IN INTEGER,
                                p_cod_cia IN VARCHAR2,
                                p_ano IN NUMBER,
                                p_mes IN NUMBER);
    PROCEDURE gen_reportos_pendientes(p_file_id IN INTEGER,
                                p_cod_cia IN VARCHAR2,
                                p_fecha_ini IN DATE,
                                p_fecha_fin IN DATE);                                                         
END;
/

GRANT EXECUTE ON OPERACIONES.GENERACION_XML TO PUBLIC;
CREATE OR REPLACE PACKAGE BODY OPERACIONES.generacion_xml
IS
    
    PROCEDURE gen_neve_cliente(p_file_id IN INTEGER,
                                p_cod_cia IN VARCHAR2,
                                p_fecha_ini IN DATE,
                                p_fecha_fin IN DATE)
    IS
        xml_neve_cliente XMLTYPE;
        v_ant_decimal_separator VARCHAR2(2);

        FUNCTION records_found
            RETURN INTEGER
        IS
            v_number_of_records INTEGER;
        BEGIN
            SELECT COUNT(*)
            INTO v_number_of_records
            FROM operaciones.cliente 
            INNER JOIN bancos.tabapais pais ON
                pais.cod_pais = cliente.cod_pais_nacimiento
            WHERE cliente.cod_cia = p_cod_cia AND
                cliente.codcliente IN (
                                        SELECT boleta.codcliente AS cod_cliente
                                        FROM operaciones.boleta
                                        WHERE boleta.cod_cia = p_cod_cia AND 
                                            UPPER(boleta.t_mercado) = 'I' AND
                                            boleta.codcliente IS NOT NULL AND
                                            boleta.f_operacion 
                                                BETWEEN p_fecha_ini AND p_fecha_fin
                                        UNION
                                        SELECT boleta.codcliente_v
                                        FROM operaciones.boleta
                                        WHERE boleta.cod_cia = p_cod_cia AND 
                                            UPPER(T_MERCADO) = 'I' AND
                                            boleta.codcliente_v IS NOT NULL AND
                                            boleta.f_operacion
                                                BETWEEN p_fecha_ini AND p_fecha_fin   
                                    );

            RETURN v_number_of_records;
        END records_found;

        -------------------

        PROCEDURE genera_objeto_xml
        IS
            CURSOR c_neve_cliente IS
                WITH datos_xml AS(   
                    SELECT cliente.tipocliente AS codigo_tipo_cliente,
                        cliente.codcliente AS codigo_cliente,
                        TO_NUMBER(cliente.codcliente) AS id_cliente,
                        CASE cliente.persona
                            WHEN 'J' THEN 2
                            WHEN 'N' THEN 1
                        ELSE
                            NULL
                        END AS tipo_persona,
                        pais.id_vare AS nacionalidad_cliente,
                        CASE 
                            WHEN cliente.nacional_extranjero = 'N'
                            THEN
                                REPLACE(cliente.nit, '-', NULL) 
                            ELSE
                                NULL
                        END AS nit_cliente,
                        CASE 
                            WHEN cliente.persona = 'N' AND cliente.nacional_extranjero = 'N'
                            THEN
                                REGEXP_REPLACE(cliente.dui, '-') 
                            ELSE
                                NULL
                        END AS dui,
                        CASE 
                            WHEN cliente.persona = 'N' AND cliente.nacional_extranjero = 'E'
                            THEN
                                COALESCE(SUBSTR(cliente.no_pasaporte_extranjero,1,15), 
                                            SUBSTR(cliente.no_carnet_resid_extranjero,1,15),
                                            SUBSTR(cliente.nit_extranjero,1,15)) 
                            ELSE
                                NULL
                        END AS documento_extranjero,
                        CASE 
                            WHEN cliente.persona = 'N' 
                            THEN 
                                cliente.sexo 
                            ELSE
                                NULL
                        END AS genero,
                         
                        CASE cliente.persona
                            WHEN 'N' THEN                             
                            SUBSTR(SAIF2000.PKG_UTILIDADES.nombre_limpio(REPLACE(cliente.p_apellido, '&', 'Y')),1,20) 
                        ELSE 
                            NULL
                        END AS primer_apellido,
                        CASE cliente.persona
                            WHEN 'N' THEN 
                            SUBSTR(SAIF2000.PKG_UTILIDADES.nombre_limpio(REPLACE(cliente.s_apellido, '&', 'Y')),1,20)  
                        ELSE 
                            NULL
                        END AS segundo_apellido,
                        CASE cliente.persona
                            WHEN 'N' THEN 
                             SUBSTR(SAIF2000.PKG_UTILIDADES.nombre_limpio(REPLACE(cliente.ape_casada, '&', 'Y')),1,20)  
                        ELSE 
                            NULL
                        END AS apellido_casada,
                        CASE cliente.persona
                            WHEN 'N' THEN
                            -- primera expresion del nombre antes del primer espacio                             
                            substr(SAIF2000.PKG_UTILIDADES.nombre_limpio(REGEXP_SUBSTR(REPLACE(cliente.nombre, '&', 'Y') , '[[:alnum:]]+', 1, 1)   ),1,20) 
                             
                        ELSE
                            NULL
                        END AS primer_nombre,
                        CASE cliente.persona
                            WHEN 'N' THEN 
                              --  expresion 2, 3, 4,5,6,7  del nombre entre los espacios, pra formar el segundo nombre
                              
                           SUBSTR(   
                              SAIF2000.PKG_UTILIDADES.nombre_limpio(REGEXP_SUBSTR(REPLACE(cliente.nombre, '&', 'Y') , '[[:alnum:]]+', 1, 2)   )
                              ||' '||SAIF2000.PKG_UTILIDADES.nombre_limpio(REGEXP_SUBSTR(REPLACE(cliente.nombre, '&', 'Y') , '[[:alnum:]]+', 1, 3)   )
                              ||' '||SAIF2000.PKG_UTILIDADES.nombre_limpio(REGEXP_SUBSTR(REPLACE(cliente.nombre, '&', 'Y') , '[[:alnum:]]+', 1, 4)   )
                              ||' '||SAIF2000.PKG_UTILIDADES.nombre_limpio(REGEXP_SUBSTR(REPLACE(cliente.nombre, '&', 'Y') , '[[:alnum:]]+', 1, 5)   )
                              ||' '||SAIF2000.PKG_UTILIDADES.nombre_limpio(REGEXP_SUBSTR(REPLACE(cliente.nombre, '&', 'Y') , '[[:alnum:]]+', 1, 6)   )
                              ||' '||SAIF2000.PKG_UTILIDADES.nombre_limpio(REGEXP_SUBSTR(REPLACE(cliente.nombre, '&', 'Y') , '[[:alnum:]]+', 1, 7)   )
                            , 1, 40)  
                        ELSE
                            NULL
                        END AS segundo_nombre,
                        CASE cliente.persona
                            WHEN 'J' THEN 
                            SUBSTR(SAIF2000.PKG_UTILIDADES.nombre_limpio(REPLACE(cliente.nombrecliente, '&', 'Y') ),1,100) 
                        ELSE
                            NULL
                        END AS nombre_sociedad
                    FROM operaciones.cliente 
                    INNER JOIN bancos.tabapais pais ON
                        pais.cod_pais = cliente.cod_pais_nacimiento
                    WHERE cliente.cod_cia = p_cod_cia AND
                        cliente.codcliente IN (
                                                SELECT boleta.codcliente AS cod_cliente
                                                FROM operaciones.boleta
                                                WHERE boleta.cod_cia = p_cod_cia AND 
                                                    UPPER(boleta.t_mercado) = 'I' AND
                                                    boleta.codcliente IS NOT NULL AND
                                                    boleta.f_operacion 
                                                        BETWEEN p_fecha_ini AND p_fecha_fin
                                                UNION
                                                SELECT boleta.codcliente_v
                                                FROM operaciones.boleta
                                                WHERE boleta.cod_cia = p_cod_cia AND 
                                                    UPPER(T_MERCADO) = 'I' AND
                                                    boleta.codcliente_v IS NOT NULL AND
                                                    boleta.f_operacion
                                                        BETWEEN p_fecha_ini AND p_fecha_fin   
                                            )
                )
                SELECT XMLELEMENT("neve",
                                    XMLATTRIBUTES('http://validador.ssf.gob.sv/neve/cliente' AS "xmlns",
                                                                      'http://www.w3.org/2001/XMLSchema-instance' AS "xmlns:xsi"),
                                        XMLAGG(
                                                XMLELEMENT("cliente",
                                                            XMLELEMENT("codigo_tipo_cliente", datos_xml.codigo_tipo_cliente),
                                                            XMLELEMENT("codigo_cliente", datos_xml.codigo_cliente),
                                                            XMLELEMENT("id_cliente", datos_xml.id_cliente),
                                                            XMLELEMENT("tipo_persona", datos_xml.tipo_persona),
                                                            XMLELEMENT("nacionalidad_cliente", datos_xml.nacionalidad_cliente),
                                                            CASE
                                                                WHEN datos_xml.nit_cliente IS NOT NULL THEN 
                                                                    XMLELEMENT("nit_cliente", datos_xml.nit_cliente)
                                                            ELSE
                                                                XMLELEMENT("nit_cliente", XMLATTRIBUTES('true' AS "xsi:nil"))
                                                            END,
                                                            CASE 
                                                                WHEN  datos_xml.dui IS NOT NULL THEN
                                                                    XMLELEMENT("dui", datos_xml.dui)
                                                            ELSE
                                                                XMLELEMENT("dui", datos_xml.dui)
                                                            /*ELSE vm 06-02-2019
                                                                XMLELEMENT("dui", XMLATTRIBUTES('true' AS "xsi:nil"))*/
                                                            END,
                                                            CASE
                                                                WHEN datos_xml.documento_extranjero IS NOT NULL THEN 
                                                                    XMLELEMENT("documento_extranjero", datos_xml.documento_extranjero)
                                                            ELSE
                                                                XMLELEMENT("documento_extranjero", datos_xml.documento_extranjero)
                                                            /*ELSE vm06-02-201
                                                            
                                                                XMLELEMENT("documento_extranjero", XMLATTRIBUTES('true' AS "xsi:nil"))*/
                                                            END,
                                                            CASE
                                                                WHEN datos_xml.genero IS NOT NULL THEN 
                                                                    XMLELEMENT("genero", datos_xml.genero)
                                                            ELSE
                                                                    XMLELEMENT("genero", datos_xml.genero)
                                                            /*ELSE vm 06-02-2019
                                                                XMLELEMENT("genero", XMLATTRIBUTES('true' AS "xsi:nil"))*/
                                                            END,
                                                            XMLELEMENT("primer_apellido", datos_xml.primer_apellido),
                                                            XMLELEMENT("segundo_apellido", datos_xml.segundo_apellido),
                                                            XMLELEMENT("apellido_casada", datos_xml.apellido_casada),
                                                            XMLELEMENT("primer_nombre", datos_xml.primer_nombre),
                                                            XMLELEMENT("segundo_nombre", datos_xml.segundo_nombre),
                                                            XMLELEMENT("nombre_sociedad", datos_xml.nombre_sociedad)
                                                            )
                                                        )
                                                    )
                FROM datos_xml;                 
        BEGIN
            OPEN c_neve_cliente;
            FETCH c_neve_cliente INTO xml_neve_cliente;
            CLOSE c_neve_cliente;
        END genera_objeto_xml;
    BEGIN
        saif2000.pkg_utilidades.valida_existencia_datos(records_found);
        
        /*Se cambia el separador de decimales para la exportacion del archivo xml
        se mantenga con el formato que exige la SSF*/
        v_ant_decimal_separator := saif2000.pkg_queries.current_nls_numeric_character;
        saif2000.pkg_utilidades.change_decimal_separator(saif2000.pkg_utilidades.g_decimal_separator_american);

        genera_objeto_xml;
        saif2000.pkg_utilidades.xml_to_temp_table(p_doc_id => p_file_id,
                                                    p_objeto_xml => xml_neve_cliente);

        saif2000.pkg_utilidades.change_decimal_separator(v_ant_decimal_separator);                                            
    EXCEPTION
        WHEN pkg_exceptions.e_no_existen_datos THEN
            RAISE_APPLICATION_ERROR(pkg_exceptions.en_no_existen_datos, 
                'No existen datos para Generar XML neve_cliente.xml');
        WHEN OTHERS THEN
            errpkg.log_error('generacion_xml.gen_neve_cliente');
            
            --Si sucede un error se devuelve el decimal separator al que tenia anteriormente
            saif2000.pkg_utilidades.change_decimal_separator(v_ant_decimal_separator);
            RAISE;
    END gen_neve_cliente;

    PROCEDURE gen_neve_opera_val_ext(p_file_id IN INTEGER,
                                p_cod_cia IN VARCHAR2,
                                p_fecha_ini IN DATE,
                                p_fecha_fin IN DATE)
    IS
        xml_neve_opera_val_ext XMLTYPE;
        v_ant_decimal_separator VARCHAR2(2);

        FUNCTION records_found
            RETURN INTEGER
        IS
            v_number_of_records INTEGER;
        BEGIN
            SELECT COUNT(*)
            INTO v_number_of_records
            FROM operaciones.cliente
                    INNER JOIN (
                        SELECT boleta.*, broker.id_broker_ssf,'C' AS compra_venta, 
                            boleta.codcliente AS codigo_cliente
                        FROM operaciones.cliente
                        INNER JOIN operaciones.boleta ON
                            boleta.cod_cia = cliente.cod_cia AND
                            boleta.codcliente = cliente.codcliente
                        INNER JOIN operaciones.tambordenes orden ON 
                            orden.cod_cia = boleta.cod_cia AND
                            orden.no_orden = boleta.no_orden
                        INNER JOIN operaciones.tambbroker broker ON
                            broker.cod_cia = orden.cod_cia AND
                            broker.cod_broker = orden.cod_broker
                        UNION
                        SELECT boleta.*, broker.id_broker_ssf,'V' AS compra_venta, 
                            boleta.codcliente_v AS codigo_cliente
                        FROM operaciones.cliente
                        INNER JOIN operaciones.boleta ON
                            boleta.cod_cia = cliente.cod_cia AND
                            boleta.codcliente_v = cliente.codcliente
                        INNER JOIN operaciones.tambordenes orden ON 
                            orden.cod_cia = boleta.cod_cia AND
                            orden.no_orden = boleta.no_ordenv
                        INNER JOIN operaciones.tambbroker broker ON
                            broker.cod_cia = orden.cod_cia AND
                            broker.cod_broker = orden.cod_broker
                        ) all_boleta ON
                cliente.cod_cia = all_boleta.cod_cia AND
                cliente.codcliente = all_boleta.codigo_cliente  
            INNER JOIN bancos.tabatmon info_moneda ON
                info_moneda.cod_moneda = all_boleta.moneda
            WHERE all_boleta.cod_cia = p_cod_cia AND 
                UPPER(all_boleta.t_mercado) = 'I' AND
                all_boleta.f_operacion BETWEEN p_fecha_ini AND p_fecha_fin;

            RETURN v_number_of_records;
        END records_found;

        -------------------

        PROCEDURE genera_objeto_xml
        IS
            CURSOR c_neve_opera_val_ext IS
                WITH datos_xml AS (
                    SELECT TO_NUMBER(cliente.codcliente) AS id_cliente,
                        TO_NUMBER(all_boleta.nm_operacion) AS numero_operacion,
                        TO_CHAR(all_boleta.f_operacion, 'YYYY-MM-DD') AS fecha_operacion,
                        TO_CHAR(all_boleta.f_operacion, 'DD-MON-RR') AS fecha_operacion1,
                        /*info_moneda.id_moneda_vare*/ null AS moneda,
                        all_boleta.c_titulo AS emision,
                        
                        CASE
                            WHEN all_boleta.serie IS NOT NULL 
                            THEN substr(all_boleta.serie,1,10)
                        ELSE
                            '---'
                        END AS serie,
                        
                        CASE UPPER(all_boleta.operacion)
                            WHEN 'AO' THEN '01'
                            WHEN 'AC' THEN '02'
                            WHEN 'AP' THEN '03'
                        ELSE
                            '04'
                        END AS tipo_operacion,
                        
                        CASE 
                            WHEN UPPER(all_boleta.t_mercado) = 'I' AND
                                (UPPER(all_boleta.tipo_titulo_int) IS NULL OR
                                UPPER(all_boleta.tipo_titulo_int) <> 'A')
                            THEN
                                CASE all_boleta.compra_venta
                                    WHEN 'C' THEN 'SIC'
                                    WHEN 'V' THEN 'SIV'
                                END
                            WHEN UPPER(all_boleta.t_mercado) = 'I' AND
                                UPPER(all_boleta.tipo_titulo_int) = 'A'
                            THEN
                                'AI'
                        END AS mercado_transado,
                        
                        all_boleta.ts_interes AS tasa_interes_nominal,                        
                        99 periodicidad_pago,
                        all_boleta.v_nominal AS valor_nominal,
                        to_char(all_boleta.precio, '99999999990.999999999') AS precio,
                        to_char(all_boleta.v_transado, '99999999990.99') AS valor_transado,
                        to_char('1', '990.99999999')  AS tasa_cambio,
                        to_char(NVL(ROUND(all_boleta.ren_bto, 8), 0), '990.99999999') AS rendimiento_bruto,
                        to_char(NVL(ROUND(all_boleta.rendimiento, 8), 0), '990.99999999') AS rendimiento_neto,
                        
                        CASE
                            WHEN all_boleta.compra_venta = 'C' THEN to_char(all_boleta.v_combolsa, '99999999990.99')
                            WHEN all_boleta.compra_venta = 'V' THEN to_char(all_boleta.v_vtabolsa , '99999999990.99')
                        END AS comision_bolsa,
                        
                        CASE
                            WHEN all_boleta.compra_venta = 'C' THEN to_char(all_boleta.v_comcasa, '99999999990.99')
                            WHEN all_boleta.compra_venta = 'V' THEN to_char(all_boleta.v_vtacasa, '99999999990.99')
                        END AS comision_casa_corredora,
                        
                        TO_CHAR(all_boleta.f_liquida, 'YYYY-MM-DD') AS fecha_liquidacion,
                        all_boleta.id_broker_ssf AS codigo_broker,
                        
                        CASE
                            WHEN all_boleta.compra_venta = 'C' THEN all_boleta.no_orden
                            WHEN all_boleta.compra_venta = 'V' THEN all_boleta.no_ordenv 
                        END AS numero_orden_corredora,
                        
                        to_char(emision.tasa_vigente, '990.99999999') tasa_nominal_emision                                             
                        
                    FROM operaciones.cliente
                    INNER JOIN (
                        SELECT boleta.*, broker.id_broker_ssf,'C' AS compra_venta, 
                            boleta.codcliente AS codigo_cliente
                        FROM operaciones.cliente
                        INNER JOIN operaciones.boleta ON
                            boleta.cod_cia = cliente.cod_cia AND
                            boleta.codcliente = cliente.codcliente
                        INNER JOIN operaciones.tambordenes orden ON 
                            orden.cod_cia = boleta.cod_cia AND
                            orden.no_orden = boleta.no_orden
                        INNER JOIN operaciones.tambbroker broker ON
                            broker.cod_cia = orden.cod_cia AND
                            broker.cod_broker = orden.cod_broker
                            
                        UNION
                        SELECT boleta.*, broker.id_broker_ssf,'V' AS compra_venta, 
                            boleta.codcliente_v AS codigo_cliente
                        FROM operaciones.cliente
                        INNER JOIN operaciones.boleta ON
                            boleta.cod_cia = cliente.cod_cia AND
                            boleta.codcliente_v = cliente.codcliente
                        INNER JOIN operaciones.tambordenes orden ON 
                            orden.cod_cia = boleta.cod_cia AND
                            orden.no_orden = boleta.no_ordenv
                        INNER JOIN operaciones.tambbroker broker ON
                            broker.cod_cia = orden.cod_cia AND
                            broker.cod_broker = orden.cod_broker 
                                                       
                        ) all_boleta ON
                        cliente.cod_cia = all_boleta.cod_cia AND
                        cliente.codcliente = all_boleta.codigo_cliente  
                    INNER JOIN bancos.tabatmon info_moneda ON
                        info_moneda.cod_moneda = all_boleta.moneda
                    INNER JOIN operaciones.tacemibv emision ON
                            all_boleta.c_titulo = emision.titulo AND
                            all_boleta.serie    = emision.serie    
                    WHERE all_boleta.cod_cia = p_cod_cia AND 
                        UPPER(all_boleta.t_mercado) = 'I' AND
                        all_boleta.f_operacion BETWEEN p_fecha_ini AND p_fecha_fin
                )
                SELECT XMLELEMENT("neve",
                                    XMLATTRIBUTES('http://validador.ssf.gob.sv/neve/opera_valor_extranjero' AS "xmlns",
                                                    'http://www.w3.org/2001/XMLSchema-instance' AS "xmlns:xsi"),
                                    XMLAGG(
                                        XMLELEMENT("opera_valor_extranjero",
                                            XMLELEMENT("id_cliente", datos_xml.id_cliente),
                                            XMLELEMENT("numero_operacion", datos_xml.numero_operacion),
                                            XMLELEMENT("fecha_operacion", datos_xml.fecha_operacion),
                                            XMLELEMENT("moneda", datos_xml.moneda),
                                            XMLELEMENT("emision", datos_xml.emision),
                                            XMLELEMENT("serie", datos_xml.serie),
                                            XMLELEMENT("tipo_operacion", datos_xml.tipo_operacion),
                                            XMLELEMENT("mercado_transado", datos_xml.mercado_transado),
                                            XMLELEMENT("tasa_interes_nominal", datos_xml.tasa_nominal_emision),
                                            XMLELEMENT("periodicidad_pago", datos_xml.periodicidad_pago),
                                            XMLELEMENT("valor_nominal", datos_xml.valor_nominal),
                                            XMLELEMENT("precio", datos_xml.precio),
                                            XMLELEMENT("valor_transado", datos_xml.valor_transado),
                                            XMLELEMENT("tasa_cambio", datos_xml.tasa_cambio),
                                            XMLELEMENT("rendimiento_bruto", datos_xml.rendimiento_bruto),
                                            XMLELEMENT("rendimiento_neto", datos_xml.rendimiento_neto),
                                            XMLELEMENT("comision_bolsa", datos_xml.comision_bolsa),
                                            XMLELEMENT("comision_casa_corredora", datos_xml.comision_casa_corredora),
                                            XMLELEMENT("fecha_liquidacion", datos_xml.fecha_liquidacion),
                                            XMLELEMENT("codigo_broker", datos_xml.codigo_broker),
                                            XMLELEMENT("numero_orden_corredora", datos_xml.numero_orden_corredora)
                                            )
                                        )
                                )
                FROM datos_xml;                                 
        BEGIN
            OPEN c_neve_opera_val_ext;
            FETCH c_neve_opera_val_ext INTO xml_neve_opera_val_ext;
            CLOSE c_neve_opera_val_ext;
        END genera_objeto_xml;
    BEGIN
        saif2000.pkg_utilidades.valida_existencia_datos(records_found);
        
        /*Se cambia el separador de decimales para la exportacion del archivo xml
        se mantenga con el formato que exige la SSF*/
        v_ant_decimal_separator := saif2000.pkg_queries.current_nls_numeric_character;
        saif2000.pkg_utilidades.change_decimal_separator(saif2000.pkg_utilidades.g_decimal_separator_american);
        
        genera_objeto_xml;
        saif2000.pkg_utilidades.xml_to_temp_table(p_doc_id => p_file_id,
                                                    p_objeto_xml => xml_neve_opera_val_ext);

        saif2000.pkg_utilidades.change_decimal_separator(v_ant_decimal_separator);                                            
    EXCEPTION
        WHEN pkg_exceptions.e_no_existen_datos THEN
            RAISE_APPLICATION_ERROR(pkg_exceptions.en_no_existen_datos, 
                'No existen datos para Generar XML neve_opera_valor_extranjero.xml');
        WHEN OTHERS THEN
            errpkg.log_error('generacion_xml.gen_neve_opera_val_ext');
            
            --Si sucede un error se devuelve el decimal separator al que tenia anteriormente
            saif2000.pkg_utilidades.change_decimal_separator(v_ant_decimal_separator);
            
            RAISE;
    END gen_neve_opera_val_ext;
    
    -----************************************************************************************
    -----************************************************************************************
    -----************************************************************************************
    PROCEDURE gen_saldo_cuenta(p_file_id IN INTEGER,
                                p_cod_cia IN VARCHAR2,
                                p_ano IN NUMBER,
                                p_mes IN NUMBER)
    IS
        xml_saldo_cuenta XMLTYPE;
        v_ant_decimal_separator VARCHAR2(2);

        FUNCTION records_found
            RETURN INTEGER
        IS
            v_number_of_records INTEGER;
        BEGIN
            SELECT COUNT(1)
            INTO v_number_of_records
            FROM conta.tacfhc
                   where no_cia = p_cod_cia
                     and ano    = p_ano
                     and mes    = p_mes;

            RETURN v_number_of_records;
        END records_found;

        -------------------

        PROCEDURE genera_objeto_xml
        IS
            CURSOR c_saldo_cuenta IS
                WITH datos_xml AS (
                
                
                    -- Cuentas Contables
                    SELECT c.no_cia, c.nivel_1, c.nivel_2, c.nivel_3, c.nivel_4, c.nivel_5
                          ,c.nivel_6, c.nivel_7, c.cuenta_abreviada id_codigo_cuenta
                          ,upper(trim(s.descri)) nombre_cuenta,  
                          abs(decode(t.tipo_saldo,'C',(nvl(c.saldo, 0) - nvl(c.movimiento, 0))*-1,'D',nvl(c.saldo, 0) - nvl(c.movimiento, 0))) saldo_anterior
                          ,abs(nvl(c.mov_db, 0)) cargo_mes, abs(nvl(c.mov_cr, 0)) abono_mes
                          ,abs(nvl(c.mov_db, 0) + nvl(c.mov_cr, 0)) movi
                          ,abs( decode(t.tipo_saldo,'C', nvl(c.saldo, 0) * -1, nvl(c.saldo, 0)))  saldo_actual
                          ,decode(t.tipo_saldo,'C', 'A', 'D') naturaleza_cuenta
                          ,s.signo_saldo signo_saldo 
                    FROM    conta.TACFHC C
                         INNER JOIN
                            conta.TACFMS S
                         ON c.no_cia = s.no_cia and c.cuenta_abreviada = s.cuenta_abreviada
                         INNER JOIN 
                            conta.TACFTI T
                         ON s.no_cia= t.no_cia and s.tipo=t.tipo
                    WHERE     C.NO_CIA = p_cod_cia
                          and c.ano = p_ano
                          and c.mes = p_mes
                          and t.tipo <> '99'

                    UNION
                    -- Digito 1 de la cuenta (Clase)
                    --
                    SELECT s.no_cia, substr(s.nivel_1, 1, 1) nivel_1, max('%') nivel_2
                          ,max('%%%') nivel_3, max('%%') nivel_4, max('%%') nivel_5
                          ,max('%%') nivel_6, max('%%') nivel_7
                          ,substr(s.nivel_1, 1, 1) cuenta_unida, upper(trim(t.elemento_contable)) descri,
                          ABS( DECODE (SUBSTR(s.nivel_1, 1, 1)
                                        , '1' , sum(nvl(s.saldo, 0))-sum(nvl(s.movimiento, 0))
                                        , '2' , (sum(nvl(s.saldo, 0))-sum(nvl(s.movimiento, 0)))*-1
                                        , '3' , (sum(nvl(s.saldo, 0))-sum(nvl(s.movimiento, 0)))*-1
                                        , '4' , sum(nvl(s.saldo, 0))-sum(nvl(s.movimiento, 0))
                                        , '5' , (sum(nvl(s.saldo, 0))-sum(nvl(s.movimiento, 0)))*-1
                                        , '6' , (sum(nvl(s.saldo, 0))-sum(nvl(s.movimiento, 0)))
                                        , '7' , (sum(nvl(s.saldo, 0))-sum(nvl(s.movimiento, 0)))*-1
                                        , '8' , (sum(nvl(s.saldo, 0))-sum(nvl(s.movimiento, 0)))
                                        , '9' , (sum(nvl(s.saldo, 0))-sum(nvl(s.movimiento, 0)))*-1   )) ante
                          ,abs(sum(nvl(s.mov_db, 0))) debe
                          ,abs(sum(nvl(s.mov_cr, 0))) haber
                          ,abs(sum(nvl(s.mov_db, 0) + nvl(s.mov_cr, 0))) movi
                          ,abs( decode (substr(s.nivel_1, 1, 1)
                                        , '1' , sum(nvl(s.saldo, 0))
                                        , '2' , (sum(nvl(s.saldo, 0)))*-1
                                        , '3' , (sum(nvl(s.saldo, 0)))*-1
                                        , '4' , sum(nvl(s.saldo, 0))
                                        , '5' , (sum(nvl(s.saldo, 0)))*-1
                                        , '6' , sum(nvl(s.saldo, 0))
                                        , '7' , (sum(nvl(s.saldo, 0)))*-1
                                        , '8' , sum(nvl(s.saldo, 0))
                                        , '9' , (sum(nvl(s.saldo, 0)))*-1)) saldo
                          ,decode(ti.tipo_saldo,'C', 'A', 'D') naturaleza_cuenta
                          --,decode(ti.tipo_saldo,'C', '-', '+') signo_saldo 
                          
                          --,decode( sign(sum(nvl(s.saldo, 0))),-1, '-', '+') signo_saldo 
                          ,decode(sign(sum(nvl(s.saldo, 0))), -1, '-', '+')  signo_saldo  
                                              
                    FROM    conta.tacfhc s
                         INNER JOIN
                            conta.tacfcatelem t 
                         on substr(s.nivel_1, 1, 1) = t.cod_elemento_contable and s.no_cia = t.no_cia
                         INNER JOIN 
                            conta.TACFTI TI
                         ON s.no_cia= tI.no_cia and s.tipo=tI.tipo
                    WHERE     s.no_cia = p_cod_cia
                          and s.nivel_cuenta = 1
                          and s.ano = p_ano
                          and s.mes = p_mes
                    group by s.no_cia, substr(s.nivel_1, 1, 1), t.elemento_contable, t.cod_clase,
                             ti.tipo_saldo
                     -- tipos de cuenta
                    UNION ALL
                    SELECT x.no_cia, y.tipo nivel_1, max('%'), max('%%%'), max('%%'), max('%%')
                          ,max('%%'), max('%%'), y.tipo cuenta_unida, upper(trim(y.descripcion)) descri
                          ,abs(decode(y.tipo_saldo,'C',(nvl(sum(saldo), 0) - sum(nvl(x.movimiento, 0)))*-1,'D',nvl(sum(saldo), 0) - sum(nvl(x.movimiento, 0)))) ante
                          ,abs(sum(nvl(mov_db, 0))) debe
                          ,abs(sum(nvl(mov_cr, 0))) haber, abs(sum(nvl(mov_db, 0) + nvl(mov_cr, 0))) movi
                          ,abs( decode(y.tipo_saldo,'C', sum(nvl(x.saldo, 0) * -1), sum(nvl(x.saldo, 0)))) saldo
                          ,decode(y.tipo_saldo,'C', 'A', 'D') naturaleza_cuenta
                          ,y.signo_saldo signo_saldo 
                          
                    FROM conta.TACFHC X, conta.TACFTI Y
                    WHERE     x.no_cia = p_cod_cia
                          and x.no_cia = y.no_cia
                          and x.tipo = y.tipo
                          and x.nivel_cuenta = 1
                          and y.tipo <> 99
                          and x.ano = p_ano
                          and x.mes = p_mes
                    group by x.no_cia, y.tipo, y.descripcion, y.tipo_saldo, y.signo_saldo 
                    order by 1,9


                )
                SELECT XMLELEMENT("cccb",
                                    XMLATTRIBUTES('http://validador.ssf.gob.sv/cccb/balance_institucion' AS "xmlns",
                                                    'http://www.w3.org/2001/XMLSchema-instance' AS "xmlns:xsi"),
                                    XMLAGG(
                                        XMLELEMENT("saldo_cuenta",
                                            
                                            XMLELEMENT("id_codigo_cuenta", datos_xml.id_codigo_cuenta),
                                            XMLELEMENT("nombre_cuenta", datos_xml.nombre_cuenta),
                                            XMLELEMENT("saldo_anterior", datos_xml.saldo_anterior),
                                            XMLELEMENT("cargo_mes", datos_xml.cargo_mes),
                                            XMLELEMENT("abono_mes", datos_xml.abono_mes),
                                            XMLELEMENT("saldo_actual", datos_xml.saldo_actual),
                                            XMLELEMENT("naturaleza_cuenta", datos_xml.naturaleza_cuenta),
                                            XMLELEMENT("signo_saldo", datos_xml.signo_saldo)
                                            
                                            )
                                        )
                                )
                FROM datos_xml;                                 
        BEGIN
            OPEN c_saldo_cuenta;
            FETCH c_saldo_cuenta INTO xml_saldo_cuenta;
            CLOSE c_saldo_cuenta;
        END genera_objeto_xml;
    BEGIN
        saif2000.pkg_utilidades.valida_existencia_datos(records_found);
        
        /*Se cambia el separador de decimales para la exportacion del archivo xml
        se mantenga con el formato que exige la SSF*/
        v_ant_decimal_separator := saif2000.pkg_queries.current_nls_numeric_character;
        saif2000.pkg_utilidades.change_decimal_separator(saif2000.pkg_utilidades.g_decimal_separator_american);
        
        genera_objeto_xml;
        saif2000.pkg_utilidades.xml_to_temp_table(p_doc_id => p_file_id,
                                                    p_objeto_xml => xml_saldo_cuenta);

        saif2000.pkg_utilidades.change_decimal_separator(v_ant_decimal_separator);                                            
    EXCEPTION
        WHEN pkg_exceptions.e_no_existen_datos THEN
            RAISE_APPLICATION_ERROR(pkg_exceptions.en_no_existen_datos, 
                'No existen datos para Generar XML saldo_cuenta.xml');
        WHEN OTHERS THEN
            errpkg.log_error('generacion_xml.gen_saldo_cuenta');
            
            --Si sucede un error se devuelve el decimal separator al que tenia anteriormente
            saif2000.pkg_utilidades.change_decimal_separator(v_ant_decimal_separator);
            
            RAISE;
    END gen_saldo_cuenta;

 ---**************************************************************************************
 --***************************************************************************************
 --**************************************************************************************
 PROCEDURE gen_reportos_pendientes(p_file_id IN INTEGER,
                                p_cod_cia IN VARCHAR2,
                                p_fecha_ini IN DATE,
                                p_fecha_fin IN DATE)
    IS
        xml_neve_reportos_pendientes XMLTYPE;
        v_ant_decimal_separator VARCHAR2(2);

        FUNCTION records_found
            RETURN INTEGER
        IS
            v_number_of_records INTEGER;
        BEGIN
            SELECT COUNT(*)
            INTO v_number_of_records
            FROM operaciones.cliente
                    INNER JOIN (
                        SELECT boleta.*, 'C' AS compra_venta, 
                            boleta.codcliente AS codigo_cliente
                        FROM operaciones.cliente
                        INNER JOIN operaciones.boleta ON
                            boleta.cod_cia = cliente.cod_cia AND
                            boleta.codcliente = cliente.codcliente
                        INNER JOIN operaciones.tambordenes orden ON 
                            orden.cod_cia = boleta.cod_cia AND
                            orden.no_orden = boleta.no_orden
                        /*INNER JOIN operaciones.tambbroker broker ON
                            broker.cod_cia = orden.cod_cia AND
                            broker.cod_broker = orden.cod_broker*/
                        UNION
                        SELECT boleta.*, 'V' AS compra_venta, 
                            boleta.codcliente_v AS codigo_cliente
                        FROM operaciones.cliente
                        INNER JOIN operaciones.boleta ON
                            boleta.cod_cia = cliente.cod_cia AND
                            boleta.codcliente_v = cliente.codcliente
                        INNER JOIN operaciones.tambordenes orden ON 
                            orden.cod_cia = boleta.cod_cia AND
                            orden.no_orden = boleta.no_ordenv
                        /*INNER JOIN operaciones.tambbroker broker ON
                            broker.cod_cia = orden.cod_cia AND
                            broker.cod_broker = orden.cod_broker*/
                        ) all_boleta ON
                cliente.cod_cia = all_boleta.cod_cia AND
                cliente.codcliente = all_boleta.codigo_cliente  
            INNER JOIN bancos.tabatmon info_moneda ON
                info_moneda.cod_moneda = all_boleta.moneda
            WHERE all_boleta.cod_cia = p_cod_cia AND 
                UPPER(all_boleta.t_mercado) = 'R' AND
                all_boleta.f_recompra  >= p_fecha_ini;-- AND p_fecha_fin;

            RETURN v_number_of_records;
        END records_found;

        -------------------

        PROCEDURE genera_objeto_xml
        IS
            CURSOR c_neve_reportos_pendientes IS
                WITH datos_xml AS (
                    SELECT TO_NUMBER(cliente.codcliente) AS id_cliente,
                        TO_NUMBER(all_boleta.nm_operacion) AS numero_operacion,
                        TO_CHAR(all_boleta.f_operacion, 'YYYY-MM-DD') AS fecha_operacion,
                        TO_CHAR(all_boleta.f_operacion, 'DD-MON-RR') AS fecha_operacion1,
                        info_moneda.id_moneda_vare AS moneda,
                        all_boleta.c_titulo AS emision,
                        
                        CASE
                            WHEN all_boleta.serie IS NOT NULL 
                            THEN substr(all_boleta.serie,1,10)
                        ELSE
                            '---'
                        END AS serie,
                        
                        CASE UPPER(all_boleta.operacion)
                            WHEN 'AO' THEN '01'
                            WHEN 'AC' THEN '02'
                            WHEN 'AP' THEN '03'
                        ELSE
                            '04'
                        END AS tipo_operacion,
                        
                        CASE 
                            WHEN UPPER(all_boleta.t_mercado) = 'I' AND
                                (UPPER(all_boleta.tipo_titulo_int) IS NULL OR
                                UPPER(all_boleta.tipo_titulo_int) <> 'A')
                            THEN
                                CASE all_boleta.compra_venta
                                    WHEN 'C' THEN 'SIC'
                                    WHEN 'V' THEN 'SIV'
                                END
                            WHEN UPPER(all_boleta.t_mercado) = 'I' AND
                                UPPER(all_boleta.tipo_titulo_int) = 'A'
                            THEN
                                'AI'
                        END AS mercado_transado,
                        
                        all_boleta.ts_interes AS tasa_interes_nominal,                        
                        99 periodicidad_pago,
                        all_boleta.v_nominal AS valor_nominal,
                        to_char(all_boleta.precio, '99999999990.999999999') AS precio,
                        to_char(all_boleta.v_transado, '99999999990.99') AS valor_transado,
                        to_char('1', '990.99999999')  AS tasa_cambio,
                        to_char(NVL(ROUND(all_boleta.ren_bto, 8), 0), '990.99999999') AS rendimiento_bruto,
                        to_char(NVL(ROUND(all_boleta.rendimiento, 8), 0), '990.99999999') AS rendimiento_neto,
                        
                        CASE
                            WHEN all_boleta.compra_venta = 'C' THEN to_char(all_boleta.v_combolsa, '99999999990.99')
                            WHEN all_boleta.compra_venta = 'V' THEN to_char(all_boleta.v_vtabolsa , '99999999990.99')
                        END AS comision_bolsa,
                        
                        CASE
                            WHEN all_boleta.compra_venta = 'C' THEN to_char(all_boleta.v_comcasa, '99999999990.99')
                            WHEN all_boleta.compra_venta = 'V' THEN to_char(all_boleta.v_vtacasa, '99999999990.99')
                        END AS comision_casa_corredora,
                        
                        TO_CHAR(all_boleta.f_liquida, 'YYYY-MM-DD') AS fecha_liquidacion,
                        --all_boleta.id_broker_ssf AS codigo_broker,
                        
                        CASE
                            WHEN all_boleta.compra_venta = 'C' THEN all_boleta.no_orden
                            WHEN all_boleta.compra_venta = 'V' THEN all_boleta.no_ordenv 
                        END AS numero_orden_corredora,
                        
                        to_char(emision.tasa_vigente, '990.99999999') tasa_nominal_emision  ,
                        all_boleta.cte, all_boleta.cta, all_boleta.tcta,
                        round( (all_boleta.v_transado* all_boleta.pre_recomp)/100,2) valor_recompra,
                        all_boleta.nombrecliente,
                        all_boleta.compra_venta
                                                                 
                        
                    FROM operaciones.cliente
                    INNER JOIN (
                        SELECT boleta.*, /*broker.id_broker_ssf,*/'C' AS compra_venta, 
                            boleta.codcliente AS codigo_cliente,
                            orden.cte, orden.cta, orden.tcta,
                            cliente.nombrecliente
                        FROM operaciones.cliente
                        INNER JOIN operaciones.boleta ON
                            boleta.cod_cia = cliente.cod_cia AND
                            boleta.codcliente = cliente.codcliente
                        INNER JOIN operaciones.tambordenes orden ON 
                            orden.cod_cia = boleta.cod_cia AND
                            orden.no_orden = boleta.no_orden
                       /* INNER JOIN operaciones.tambbroker broker ON
                            broker.cod_cia = orden.cod_cia AND
                            broker.cod_broker = orden.cod_broker*/
                            
                        UNION
                        SELECT boleta.*, /*broker.id_broker_ssf,*/'V' AS compra_venta, 
                            boleta.codcliente_v AS codigo_cliente,
                            orden.cte, orden.cta, orden.tcta,
                            cliente.nombrecliente
                        FROM operaciones.cliente
                        INNER JOIN operaciones.boleta ON
                            boleta.cod_cia = cliente.cod_cia AND
                            boleta.codcliente_v = cliente.codcliente
                        INNER JOIN operaciones.tambordenes orden ON 
                            orden.cod_cia = boleta.cod_cia AND
                            orden.no_orden = boleta.no_ordenv
                       /* INNER JOIN operaciones.tambbroker broker ON
                            broker.cod_cia = orden.cod_cia AND
                            broker.cod_broker = orden.cod_broker */
                                                       
                        ) all_boleta ON
                        cliente.cod_cia = all_boleta.cod_cia AND
                        cliente.codcliente = all_boleta.codigo_cliente  
                    INNER JOIN bancos.tabatmon info_moneda ON
                        info_moneda.cod_moneda = all_boleta.moneda
                    INNER JOIN operaciones.tacemibv emision ON
                            all_boleta.c_titulo = emision.titulo AND
                            all_boleta.serie    = emision.serie    
                    WHERE all_boleta.cod_cia = p_cod_cia AND 
                        UPPER(all_boleta.t_mercado) = 'R' AND
                        all_boleta.f_recompra >= p_fecha_ini--BETWEEN p_fecha_ini AND p_fecha_fin
                )
                
                
                SELECT XMLELEMENT("cccb",
                                    XMLATTRIBUTES('http://validador.ssf.gob.sv/cccb/reportos_pendientes' AS "xmlns",
                                                    'http://www.w3.org/2001/XMLSchema-instance' AS "xmlns:xsi"),
                                    XMLAGG(
                                        XMLELEMENT("reportos_pendientes",
                                        
                                            XMLELEMENT("cuenta_casa", datos_xml.cte),
                                            XMLELEMENT("cuenta_cliente", datos_xml.cta),
                                            XMLELEMENT("tipo_cuenta", datos_xml.tcta),
                                            XMLELEMENT("numero_operacion", datos_xml.numero_operacion),
                                            XMLELEMENT("tipo_operacion", datos_xml.compra_venta),                                            
                                            XMLELEMENT("codigo_cliente", datos_xml.id_cliente),
                                            XMLELEMENT("nombre_cliente", datos_xml.nombrecliente),
                                            XMLELEMENT("concepto", null),
                                            XMLELEMENT("valor_recompra", datos_xml.valor_recompra),
                                            XMLELEMENT("tipo_registro", 'D')
                                            
                                           /* XMLELEMENT("fecha_operacion", datos_xml.fecha_operacion),
                                            XMLELEMENT("moneda", datos_xml.moneda),
                                            XMLELEMENT("emision", datos_xml.emision),
                                            XMLELEMENT("serie", datos_xml.serie),
                                            
                                            XMLELEMENT("mercado_transado", datos_xml.mercado_transado),
                                            XMLELEMENT("tasa_interes_nominal", datos_xml.tasa_nominal_emision),
                                            XMLELEMENT("periodicidad_pago", datos_xml.periodicidad_pago),
                                            XMLELEMENT("valor_nominal", datos_xml.valor_nominal),
                                            XMLELEMENT("precio", datos_xml.precio),
                                            
                                            XMLELEMENT("tasa_cambio", datos_xml.tasa_cambio),
                                            XMLELEMENT("rendimiento_bruto", datos_xml.rendimiento_bruto),
                                            XMLELEMENT("rendimiento_neto", datos_xml.rendimiento_neto),
                                            XMLELEMENT("comision_bolsa", datos_xml.comision_bolsa),
                                            XMLELEMENT("comision_casa_corredora", datos_xml.comision_casa_corredora),
                                            XMLELEMENT("fecha_liquidacion", datos_xml.fecha_liquidacion),
                                           -- XMLELEMENT("codigo_broker", datos_xml.codigo_broker),
                                            XMLELEMENT("numero_orden_corredora", datos_xml.numero_orden_corredora)*/
                                            )
                                        )
                                )
                FROM datos_xml;                                 
        BEGIN
            OPEN c_neve_reportos_pendientes;
            FETCH c_neve_reportos_pendientes INTO xml_neve_reportos_pendientes;
            CLOSE c_neve_reportos_pendientes;
        END genera_objeto_xml;
    BEGIN
        saif2000.pkg_utilidades.valida_existencia_datos(records_found);
        
        /*Se cambia el separador de decimales para la exportacion del archivo xml
        se mantenga con el formato que exige la SSF*/
        v_ant_decimal_separator := saif2000.pkg_queries.current_nls_numeric_character;
        saif2000.pkg_utilidades.change_decimal_separator(saif2000.pkg_utilidades.g_decimal_separator_american);
        
        genera_objeto_xml;
        saif2000.pkg_utilidades.xml_to_temp_table(p_doc_id => p_file_id,
                                                    p_objeto_xml => xml_neve_reportos_pendientes);

        saif2000.pkg_utilidades.change_decimal_separator(v_ant_decimal_separator);                                            
    EXCEPTION
        WHEN pkg_exceptions.e_no_existen_datos THEN
            RAISE_APPLICATION_ERROR(pkg_exceptions.en_no_existen_datos, 
                'No existen datos para Generar XML neve_opera_valor_extranjero.xml');
        WHEN OTHERS THEN
            errpkg.log_error('generacion_xml.gen_neve_opera_val_ext');
            
            --Si sucede un error se devuelve el decimal separator al que tenia anteriormente
            saif2000.pkg_utilidades.change_decimal_separator(v_ant_decimal_separator);
            
            RAISE;
    END gen_reportos_pendientes;
       
END;
/

GRANT EXECUTE ON OPERACIONES.GENERACION_XML TO PUBLIC;
