
CREATE OR REPLACE PACKAGE OPERACIONES.PKG_OPERACIONES_REGLAS_NEGOCIO AS
/******************************************************************************
   NAME:       PKG_OPERACIONES_REGLAS_NEGOCIO
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        9/10/2017      BID       1. Created this package.
******************************************************************************/
  FUNCTION cliente_tiene_operaciones(p_cod_cia  IN VARCHAR2, 
                                     p_cod_cliente IN VARCHAR2,
                                     p_fecha_proceso IN DATE,
                                     p_dias_inactividad_cliente in number) RETURN BOOLEAN;
  FUNCTION cliente_tiene_titulos(p_cod_cia  IN VARCHAR2, 
                               p_cte  IN VARCHAR2,
                               p_cta  IN VARCHAR2,
                               p_tcta IN VARCHAR2,
                               p_fecha_proceso IN DATE) RETURN BOOLEAN;
  PROCEDURE activa_cliente(p_cod_cia IN VARCHAR2,
                           p_cod_cliente IN VARCHAR2);
  PROCEDURE inactiva_cliente(p_cod_cia IN VARCHAR2,
                             p_cod_cliente IN VARCHAR2);                                                                                             
  PROCEDURE cambiar_estado_clientes(p_cod_cia IN VARCHAR2,
                                    p_fecha_proceso IN DATE);
                                    
  PROCEDURE inserta_default_familiares_pep(p_cod_cia IN VARCHAR2, p_cod_cliente IN VARCHAR2);
  
  PROCEDURE inserta_checklist_docu_cliente(p_cod_cia IN VARCHAR2, p_cod_cliente IN VARCHAR2, 
            p_persona in varchar2);  
  
  PROCEDURE inserta_cuenta_cedeval_cliente(p_cod_cia IN VARCHAR2, p_cod_cliente IN VARCHAR2, 
            p_cte in varchar2, p_cta in varchar2, p_tcta in varchar2);  
            
  PROCEDURE actualiza_cuenta_cedeval_clt(p_cod_cia IN VARCHAR2, p_cod_cliente IN VARCHAR2, 
            p_cte in varchar2, p_cta in varchar2, p_tcta in varchar2);
  
  PROCEDURE actualiza_datos_cuenta_cedeval(p_cod_cia IN VARCHAR2, p_cod_cliente IN VARCHAR2, 
            p_cte in varchar2, p_cta in varchar2, p_tcta in varchar2);
  
  PROCEDURE email_envia_rev_operativa(p_cod_cia IN VARCHAR2, p_cod_cliente IN VARCHAR2);
  
  PROCEDURE email_envia_aut_operativa(p_cod_cia IN VARCHAR2, p_cod_cliente IN VARCHAR2);
  
  PROCEDURE email_verifica_fatca(p_cod_cia IN VARCHAR2, p_cod_cliente IN VARCHAR2);
  
  PROCEDURE email_cliente_autorizado(p_cod_cia IN VARCHAR2, p_cod_cliente IN VARCHAR2);
  
  PROCEDURE email_rechazo_rev_operativa(p_cod_cia IN VARCHAR2, p_cod_cliente IN VARCHAR2,
                                        p_justificacion_rechazo IN VARCHAR2 );
                                        
  PROCEDURE email_rechazo_aut_operativa(p_cod_cia IN VARCHAR2, p_cod_cliente IN VARCHAR2,
                                        p_justificacion_rechazo IN VARCHAR2 );       
  PROCEDURE email_envia_aut_orden(p_cod_cia IN VARCHAR2, p_cod_cliente IN VARCHAR2,
                                           p_no_orden IN VARCHAR2); 
  PROCEDURE email_envia_aut_orden_ln(p_cod_cia IN VARCHAR2, p_cod_cliente IN VARCHAR2,
                                           p_no_orden IN VARCHAR2);
  PROCEDURE email_autoriza_clt_orden_ln(p_cod_cia IN VARCHAR2, p_cod_cliente IN VARCHAR2);
  
  PROCEDURE email_envia_orden_fuera_perfil(p_cod_cia IN VARCHAR2, p_cod_cliente IN VARCHAR2,
                                           p_no_orden IN VARCHAR2, p_titulos_fuera_perfil in varchar2);  
  
  --Duplica la orden que se le pase como argumento y devuelve el nuevo numero de orden                                         
  FUNCTION duplica_orden_con_nuevo_id(
    p_cod_cia IN VARCHAR2, 
    p_no_orden INTEGER) RETURN INTEGER;  
    
  PROCEDURE rectifica_orden(
    p_cod_cia IN VARCHAR2, 
    p_no_orden INTEGER, 
    p_new_no_orden IN INTEGER);
    
  PROCEDURE modifica_orden(
    p_cod_cia IN VARCHAR2, 
    p_no_orden INTEGER, 
    p_new_no_orden IN INTEGER);  
    
  PROCEDURE actualiza_numero_orden_boleta(p_cod_cia IN VARCHAR2, 
                                         p_nm_operacion IN INTEGER, 
                                         P_no_orden IN INTEGER,
                                         P_tipo_orden IN VARCHAR2);                                                                                                                                                                                         

END PKG_OPERACIONES_REGLAS_NEGOCIO;
/

GRANT EXECUTE ON OPERACIONES.PKG_OPERACIONES_REGLAS_NEGOCIO TO ACTIVO;

GRANT EXECUTE ON OPERACIONES.PKG_OPERACIONES_REGLAS_NEGOCIO TO BANCOS;

GRANT EXECUTE ON OPERACIONES.PKG_OPERACIONES_REGLAS_NEGOCIO TO CONTA;

GRANT EXECUTE ON OPERACIONES.PKG_OPERACIONES_REGLAS_NEGOCIO TO CUSTODIA;

GRANT EXECUTE ON OPERACIONES.PKG_OPERACIONES_REGLAS_NEGOCIO TO IVA;

GRANT EXECUTE ON OPERACIONES.PKG_OPERACIONES_REGLAS_NEGOCIO TO PLANILLA;

GRANT EXECUTE ON OPERACIONES.PKG_OPERACIONES_REGLAS_NEGOCIO TO PROVEE;

GRANT EXECUTE ON OPERACIONES.PKG_OPERACIONES_REGLAS_NEGOCIO TO PUBLIC;

GRANT EXECUTE ON OPERACIONES.PKG_OPERACIONES_REGLAS_NEGOCIO TO SAIF2000;


CREATE OR REPLACE PACKAGE BODY OPERACIONES.PKG_OPERACIONES_REGLAS_NEGOCIO AS
/******************************************************************************
   NAME:       PKG_OPERACIONES_REGLAS_NEGOCIO
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        9/10/2017      BID       1. Created this package.
******************************************************************************/
  
  FUNCTION cliente_tiene_operaciones(p_cod_cia  IN VARCHAR2, 
                                     p_cod_cliente IN VARCHAR2,
                                     p_fecha_proceso IN DATE,
                                     p_dias_inactividad_cliente in number) RETURN BOOLEAN IS
  v_registros number;                                     
  BEGIN
      SELECT COUNT(1) INTO v_registros
      FROM operaciones.boleta
      WHERE cod_cia = p_cod_cia
        AND TRUNC(f_operacion) between p_fecha_proceso - p_dias_inactividad_cliente AND p_fecha_proceso
        AND(codcliente = p_cod_cliente
         OR codcliente_v = p_cod_cliente); 
      RETURN v_registros > 0;
  END cliente_tiene_operaciones; 
  
FUNCTION cliente_tiene_titulos(p_cod_cia  IN VARCHAR2, 
                               p_cte  IN VARCHAR2,
                               p_cta  IN VARCHAR2,
                               p_tcta IN VARCHAR2,
                               p_fecha_proceso IN DATE) RETURN BOOLEAN IS
  v_registros number;                                     
  BEGIN
      SELECT COUNT(1) INTO v_registros
      FROM custodia.tacuinven_bac
      WHERE cte  = p_cte
        AND cta  = p_cta
        AND tcta = p_tcta;  
      RETURN v_registros > 0;
  END cliente_tiene_titulos;                         
  PROCEDURE activa_cliente(p_cod_cia IN VARCHAR2,
                           p_cod_cliente IN VARCHAR2) IS
  BEGIN
    UPDATE operaciones.cliente
    SET estado_cliente = 'A'
    WHERE cod_cia = p_cod_cia
      AND  codcliente = p_cod_cliente;
  END activa_cliente; 
  PROCEDURE inactiva_cliente(p_cod_cia IN VARCHAR2,
                           p_cod_cliente IN VARCHAR2) IS
  BEGIN
    UPDATE operaciones.cliente
    SET estado_cliente = 'I'
    WHERE cod_cia = p_cod_cia
      AND  codcliente = p_cod_cliente;
  END inactiva_cliente;   
  
  PROCEDURE cambiar_estado_clientes(p_cod_cia IN VARCHAR2,
                                    p_fecha_proceso IN DATE) IS
      CURSOR C1 IS
          SELECT cliente.codcliente, cliente.estado_cliente,
                 cliente.cte, cliente.cta, cliente.tcta,
                 nvl(compania.dias_inactividad_cliente,0) dias_inactividad_cliente
          FROM operaciones.cliente cliente
          INNER JOIN operaciones.dgeneral compania
                ON compania.codigo = cliente.cod_cia   
          WHERE cliente.cod_cia = p_cod_cia
          ORDER BY 1; 
      
  BEGIN
     FOR F1 IN c1 LOOP
        IF f1.estado_cliente = 'I'  
           AND (cliente_tiene_operaciones(p_cod_cia, f1.codcliente, p_fecha_proceso, f1.dias_inactividad_cliente)
            OR cliente_tiene_titulos(p_cod_cia, f1.cte, f1.cta, f1.tcta, p_fecha_proceso))
        THEN
           activa_cliente(p_cod_cia, f1.codcliente);           
        ELSIF f1.estado_cliente = 'A' 
           AND NOT (cliente_tiene_operaciones(p_cod_cia, f1.codcliente, p_fecha_proceso, f1.dias_inactividad_cliente)
            AND cliente_tiene_titulos(p_cod_cia, f1.cte, f1.cta, f1.tcta, p_fecha_proceso)) 
        THEN
           inactiva_cliente(p_cod_cia, f1.codcliente);
        END IF;
     END LOOP;
  EXCEPTION 
    WHEN OTHERS THEN
        SAIF2000.ERRPKG.LOG_ERROR('cambiar_estado_clientes');
        RAISE;
  END;
  
  PROCEDURE inserta_default_familiares_pep(p_cod_cia IN VARCHAR2, p_cod_cliente IN VARCHAR2)IS
    CURSOR familiares_en_reporte IS
      SELECT cod_cia, id_parentesco, num_apariciones_report_pep, parentesco
      FROM operaciones.tambparentescos
      WHERE cod_cia = p_cod_cia AND
        num_apariciones_report_pep > 0;
  BEGIN
    FOR rec IN familiares_en_reporte LOOP
      FOR indx IN 1 .. rec.num_apariciones_report_pep LOOP
        INSERT INTO operaciones.tambfamiliares_clientes_pep(cod_cia, id_familiar_cliente_pep,
                                                            cod_cliente, id_parentesco)
        VALUES(rec.cod_cia, operaciones.seq_id_familiar_cliente_pep.NEXTVAL,
               p_cod_cliente, rec.id_parentesco);
      END LOOP;
    END LOOP;
    EXCEPTION 
    WHEN OTHERS THEN
        SAIF2000.ERRPKG.LOG_ERROR('Insertando familiares PEP');
        RAISE;
  END;
  
   
  PROCEDURE inserta_checklist_docu_cliente(p_cod_cia IN VARCHAR2, p_cod_cliente IN VARCHAR2, 
            p_persona in varchar2)IS
  
  BEGIN
        INSERT INTO operaciones.tambchecklist (cod_cia, codcliente, correlativo, 
                  chequeado, fecha_ck, persona, documento_vence, 
                  fecha_vencimiento, plazo_entrega_documento, 
                  ultima_fecha_entrega_esperada)
        SELECT cod_cia,p_cod_cliente,correlativo,
              'P',null,p_persona,documento_vence,
              null,plazo_entrega_documento,
              (sysdate + plazo_entrega_documento) fecha_venc
        FROM operaciones.tambdfchecklist
        WHERE cod_cia = p_cod_cia
                     AND persona in (p_persona,'A') 
                     AND estado_dfckl = 'A';
       EXCEPTION 
    WHEN OTHERS THEN
        SAIF2000.ERRPKG.LOG_ERROR('Insertanto Checklist Documentos Cliente');
        RAISE;              
  END inserta_checklist_docu_cliente;
  
  
  
  PROCEDURE inserta_cuenta_cedeval_cliente(p_cod_cia IN VARCHAR2, p_cod_cliente IN VARCHAR2, 
            p_cte in varchar2, p_cta in varchar2, p_tcta in varchar2)IS
  
  BEGIN
        INSERT INTO operaciones.tambcuentas_cedeval (cod_cia, cod_cliente, 
                    cte, cta, tcta, cuenta_default)
        VALUES (p_cod_cia, p_cod_cliente, p_cte, p_cta, p_tcta, 'S');      
        EXCEPTION 
    WHEN OTHERS THEN
        SAIF2000.ERRPKG.LOG_ERROR('insertando Cuenta CEDEVAL del Cliente');
        RAISE;
  END inserta_cuenta_cedeval_cliente;
  
  
  PROCEDURE actualiza_cuenta_cedeval_clt(p_cod_cia IN VARCHAR2, p_cod_cliente IN VARCHAR2, 
            p_cte in varchar2, p_cta in varchar2, p_tcta in varchar2)IS
  
  BEGIN
        UPDATE operaciones.cliente
        SET cte = p_cte, cta = p_cta, tcta = p_tcta
        WHERE cod_cia    = p_cod_cia
         AND  codcliente = p_cod_cliente;      
        EXCEPTION 
    WHEN OTHERS THEN
        SAIF2000.ERRPKG.LOG_ERROR('actualizando Cuenta CEDEVAL del Cliente');
        RAISE;
  END actualiza_cuenta_cedeval_clt;
  
  
  PROCEDURE actualiza_datos_cuenta_cedeval(p_cod_cia IN VARCHAR2, p_cod_cliente IN VARCHAR2, 
            p_cte in varchar2, p_cta in varchar2, p_tcta in varchar2)IS
  
  vt_cliente operaciones.cliente%rowtype;
  BEGIN
        
    vt_cliente := operaciones.pkg_queries.datos_cliente (p_cod_cia, p_cod_cliente);        
    
    Update custodia.tacucuentas_bac
          set no_cliente     = vt_cliente.codcliente,
              no_domiciliado = vt_cliente.no_domiciliado,
              credito_fiscal = vt_cliente.credito_fiscal,
              exento_isr     = vt_cliente.exento_isr,
              exento_iva     = vt_cliente.exento_iva          
    where cte  = p_cte
      AND cta  = p_cta
      AND tcta = p_tcta;
      
  EXCEPTION 
    WHEN OTHERS THEN
      SAIF2000.ERRPKG.LOG_ERROR('actualizando Cuenta CEDEVAL');
      RAISE;
  END actualiza_datos_cuenta_cedeval;
  
  PROCEDURE email_envia_rev_operativa(p_cod_cia IN VARCHAR2, p_cod_cliente IN VARCHAR2)IS    
    
    vt_dgeneral operaciones.dgeneral%ROWTYPE;
    vt_corredor operaciones.corredor%ROWTYPE;
    vt_cliente  operaciones.cliente%ROWTYPE;
    v_host      saif2000.tasepara.smtp_out_server_activo%TYPE;
    v_cuenta_envio_email saif2000.tasepara.cuenta_envio_email%TYPE;
    
  BEGIN  
      vt_dgeneral := operaciones.pkg_queries.datos_dgeneral(p_cod_cia);
      vt_cliente  := operaciones.pkg_queries.datos_cliente(p_cod_cia,p_cod_cliente);
      vt_corredor := operaciones.pkg_queries.datos_corredor(p_cod_cia,vt_cliente.corredor);
      v_host      := SAIF2000.PKG_UTILIDADES.host_email(p_cod_cia);
      v_cuenta_envio_email := saif2000.pkg_utilidades.cuenta_envio_email(p_cod_cia);
       -- corredor      
       saif2000.pkg_utilidades.Send_email(p_envia => v_cuenta_envio_email,
                               p_destinatarios => vt_corredor.email_corredor,
                               p_asunto => 'Cliente en Revision Operativa',                                            
                               p_mensaje => 'Se ha enviado a Revisi�n Operativa el cliente '||
                                             vt_cliente.nombrecliente||'('||vt_cliente.codcliente||')',
                                p_host => v_host);
       -- Revisi�n operativa en negocios                         
       saif2000.pkg_utilidades.Send_email(p_envia => v_cuenta_envio_email,
                               p_destinatarios => vt_dgeneral.recibe_email_rev_operativa_clt,
                               p_asunto => 'Revision Operativa Cliente ',                                            
                               p_mensaje => 'Se solicita revision operativa para el cliente '||
                                             vt_cliente.nombrecliente||'('||vt_cliente.codcliente||'). '
                                             ||CHR(10)||' Para seguimiento o consultas, favor comunicarse con corredor asignado : '||
                                             vt_corredor.nombrecorredor||' al tel�fono: '||vt_corredor.telefono_corredor||
                                             ' , o email: '||vt_corredor.email_corredor ,
                                p_host => v_host);
  END email_envia_rev_operativa;

  PROCEDURE email_envia_aut_operativa(p_cod_cia IN VARCHAR2, p_cod_cliente IN VARCHAR2)IS    
    
    vt_dgeneral operaciones.dgeneral%ROWTYPE;
    vt_corredor operaciones.corredor%ROWTYPE;
    vt_cliente  operaciones.cliente%ROWTYPE;
    v_host      saif2000.tasepara.smtp_out_server_activo%TYPE;
    v_cuenta_envio_email saif2000.tasepara.cuenta_envio_email%TYPE;
    
  BEGIN  
      vt_dgeneral := operaciones.pkg_queries.datos_dgeneral(p_cod_cia);
      vt_cliente  := operaciones.pkg_queries.datos_cliente(p_cod_cia,p_cod_cliente);
      vt_corredor := operaciones.pkg_queries.datos_corredor(p_cod_cia,vt_cliente.corredor);
      v_host      := SAIF2000.PKG_UTILIDADES.host_email(p_cod_cia);
      v_cuenta_envio_email := saif2000.pkg_utilidades.cuenta_envio_email(p_cod_cia);
       -- corredor
       saif2000.pkg_utilidades.Send_email(p_envia => v_cuenta_envio_email,
                               p_destinatarios => vt_corredor.email_corredor,
                               p_asunto => 'Cliente en Autorizaci�n',                                            
                               p_mensaje => 'Se ha enviado para autorizaci�n el cliente '||
                                             vt_cliente.nombrecliente||'('||vt_cliente.codcliente||')',
                               p_host => v_host);
       -- cumplimiento                         
       saif2000.pkg_utilidades.Send_email(p_envia => v_cuenta_envio_email,
                               p_destinatarios => vt_dgeneral.recibe_email_aut_operativa_clt,
                               p_asunto => 'Autorizaci�n Cliente',                                            
                               p_mensaje => 'Se solicita Autorizacion para el cliente '||
                                             vt_cliente.nombrecliente||'('||vt_cliente.codcliente||'). '
                                             ||CHR(10)||' Para seguimiento o consultas, favor comunicarse con corredor asignado : '||
                                             vt_corredor.nombrecorredor||' al tel�fono: '||vt_corredor.telefono_corredor||
                                             ' , o email: '||vt_corredor.email_corredor ,
                               p_host => v_host);
  END email_envia_aut_operativa;
  
  PROCEDURE email_verifica_fatca(p_cod_cia IN VARCHAR2, p_cod_cliente IN VARCHAR2)IS    
    
    vt_dgeneral operaciones.dgeneral%ROWTYPE;
    vt_corredor operaciones.corredor%ROWTYPE;
    vt_cliente  operaciones.cliente%ROWTYPE;
    v_host      saif2000.tasepara.smtp_out_server_activo%TYPE;
    v_cuenta_envio_email saif2000.tasepara.cuenta_envio_email%TYPE;
    
  BEGIN  
      vt_dgeneral := operaciones.pkg_queries.datos_dgeneral(p_cod_cia);
      vt_cliente  := operaciones.pkg_queries.datos_cliente(p_cod_cia,p_cod_cliente);
      vt_corredor := operaciones.pkg_queries.datos_corredor(p_cod_cia,vt_cliente.corredor);
      v_host      := SAIF2000.PKG_UTILIDADES.host_email(p_cod_cia);
      v_cuenta_envio_email := saif2000.pkg_utilidades.cuenta_envio_email(p_cod_cia);
       -- cumplimeinto FATCA
       saif2000.pkg_utilidades.Send_email(p_envia => v_cuenta_envio_email,
                               p_destinatarios => vt_dgeneral.recibe_email_verifi_clt_fatca,
                               p_asunto => 'Veficaci�n FATCA',                                            
                               p_mensaje => 'Se le informa que el cliente '||
                                             vt_cliente.nombrecliente||'('||vt_cliente.codcliente||')'
                                             ||' necesita verificac�n FATCA, antes de su respectiva autorizaci�n'                                             
                                             ||CHR(10)||' Para seguimiento o cosultas, favor comunicarse con corredor asignado : '||
                                             vt_corredor.nombrecorredor||' al tel�fono: '||vt_corredor.telefono_corredor||
                                             ' , o email: '||vt_corredor.email_corredor ,
                               p_host => v_host);
                                
  END email_verifica_fatca;
  
  PROCEDURE email_cliente_autorizado(p_cod_cia IN VARCHAR2, p_cod_cliente IN VARCHAR2)IS    
    
    vt_dgeneral operaciones.dgeneral%ROWTYPE;
    vt_corredor operaciones.corredor%ROWTYPE;
    vt_cliente  operaciones.cliente%ROWTYPE;
    v_host      saif2000.tasepara.smtp_out_server_activo%TYPE;
    v_cuenta_envio_email saif2000.tasepara.cuenta_envio_email%TYPE;
    
  BEGIN  
      vt_dgeneral := operaciones.pkg_queries.datos_dgeneral(p_cod_cia);
      vt_cliente  := operaciones.pkg_queries.datos_cliente(p_cod_cia,p_cod_cliente);
      vt_corredor := operaciones.pkg_queries.datos_corredor(p_cod_cia,vt_cliente.corredor);
      v_host      := SAIF2000.PKG_UTILIDADES.host_email(p_cod_cia);
      v_cuenta_envio_email := saif2000.pkg_utilidades.cuenta_envio_email(p_cod_cia);
      -- Corredor
       saif2000.pkg_utilidades.Send_email(p_envia => v_cuenta_envio_email,
                               p_destinatarios => vt_corredor.email_corredor,
                               p_asunto => 'Cliente Autorizado',                                            
                               p_mensaje => 'Se le informa que el cliente '||
                                             vt_cliente.nombrecliente||'('||vt_cliente.codcliente||')'
                                             ||' Ha sido autorizado para operar',
                               p_host => v_host);
                                
  END email_cliente_autorizado;
  
  PROCEDURE email_rechazo_rev_operativa(p_cod_cia IN VARCHAR2, p_cod_cliente IN VARCHAR2,
                                        p_justificacion_rechazo IN VARCHAR2 )IS    
    
    vt_dgeneral operaciones.dgeneral%ROWTYPE;
    vt_corredor operaciones.corredor%ROWTYPE;
    vt_cliente  operaciones.cliente%ROWTYPE;
    v_host      saif2000.tasepara.smtp_out_server_activo%TYPE;
    v_cuenta_envio_email saif2000.tasepara.cuenta_envio_email%TYPE;
    
  BEGIN  
      vt_dgeneral := operaciones.pkg_queries.datos_dgeneral(p_cod_cia);
      vt_cliente  := operaciones.pkg_queries.datos_cliente(p_cod_cia,p_cod_cliente);
      vt_corredor := operaciones.pkg_queries.datos_corredor(p_cod_cia,vt_cliente.corredor);
      v_host      := SAIF2000.PKG_UTILIDADES.host_email(p_cod_cia);
      v_cuenta_envio_email := saif2000.pkg_utilidades.cuenta_envio_email(p_cod_cia);
      -- corredor
       saif2000.pkg_utilidades.Send_email(p_envia => v_cuenta_envio_email,
                               p_destinatarios => vt_corredor.email_corredor,
                               p_asunto => 'Rechazo de Cliente en Revision Operativa',                                            
                               p_mensaje => 'Cliente rechazado y devuelto a mantenimiento '||
                                             vt_cliente.nombrecliente||'('||vt_cliente.codcliente||')'||
                                             ' Motivo de rechazo '||p_justificacion_rechazo,
                                p_host => v_host);
  END email_rechazo_rev_operativa;

PROCEDURE email_rechazo_aut_operativa(p_cod_cia IN VARCHAR2, p_cod_cliente IN VARCHAR2,
                                        p_justificacion_rechazo IN VARCHAR2 )IS    
    
    vt_dgeneral operaciones.dgeneral%ROWTYPE;
    vt_corredor operaciones.corredor%ROWTYPE;
    vt_cliente  operaciones.cliente%ROWTYPE;
    v_host      saif2000.tasepara.smtp_out_server_activo%TYPE;
    v_cuenta_envio_email saif2000.tasepara.cuenta_envio_email%TYPE;
    
  BEGIN  
      vt_dgeneral := operaciones.pkg_queries.datos_dgeneral(p_cod_cia);
      vt_cliente  := operaciones.pkg_queries.datos_cliente(p_cod_cia,p_cod_cliente);
      vt_corredor := operaciones.pkg_queries.datos_corredor(p_cod_cia,vt_cliente.corredor);
      v_host      := SAIF2000.PKG_UTILIDADES.host_email(p_cod_cia);
      v_cuenta_envio_email := saif2000.pkg_utilidades.cuenta_envio_email(p_cod_cia);
       -- corredor
       saif2000.pkg_utilidades.Send_email(p_envia => v_cuenta_envio_email,
                               p_destinatarios => vt_corredor.email_corredor,
                               p_asunto => 'Rechazo de Cliente en Autorizaci�n',                                            
                               p_mensaje => 'Cliente rechazado y devuelto a mantenimiento '||
                                             vt_cliente.nombrecliente||'('||vt_cliente.codcliente||')'||
                                             ' Motivo de rechazo '||p_justificacion_rechazo,
                                p_host => v_host);
  END email_rechazo_aut_operativa;
  
  PROCEDURE email_envia_aut_orden(p_cod_cia IN VARCHAR2, p_cod_cliente IN VARCHAR2,
                                           p_no_orden IN VARCHAR2)IS    
    
    vt_dgeneral operaciones.dgeneral%ROWTYPE;
    vt_corredor operaciones.corredor%ROWTYPE;
    vt_cliente  operaciones.cliente%ROWTYPE;
    v_host      saif2000.tasepara.smtp_out_server_activo%TYPE;
    v_cuenta_envio_email saif2000.tasepara.cuenta_envio_email%TYPE;
    
  BEGIN  
      vt_dgeneral := operaciones.pkg_queries.datos_dgeneral(p_cod_cia);
      vt_cliente  := operaciones.pkg_queries.datos_cliente(p_cod_cia,p_cod_cliente);
      vt_corredor := operaciones.pkg_queries.datos_corredor(p_cod_cia,vt_cliente.corredor);
      v_host      := SAIF2000.PKG_UTILIDADES.host_email(p_cod_cia);
      v_cuenta_envio_email := saif2000.pkg_utilidades.cuenta_envio_email(p_cod_cia);
       -- corredor
       saif2000.pkg_utilidades.Send_email(p_envia => v_cuenta_envio_email,
                               p_destinatarios => vt_corredor.email_corredor,
                               p_asunto => 'Orden No.'||p_no_orden||' en Autorizaci�n',                                            
                               p_mensaje => 'Se ha enviado para autorizaci�n la orden No. '||p_no_orden||
                               ' del cliente '||vt_cliente.nombrecliente||'('||vt_cliente.codcliente||')',
                               p_host => v_host);
       -- autorizador de ordenes de operacion                         
       saif2000.pkg_utilidades.Send_email(p_envia => v_cuenta_envio_email,
                               p_destinatarios => vt_dgeneral.recibe_email_aut_ordenes_clt,
                               p_asunto => 'Autorizaci�n de Orden No.'||p_no_orden,                                            
                               p_mensaje => 'Se solicita Autorizacion para la orden No. '||p_no_orden||
                               ' del cliente '||vt_cliente.nombrecliente||'('||vt_cliente.codcliente||'). '
                               ||CHR(10)||' Para seguimiento o consultas, favor comunicarse con corredor asignado : '||
                               vt_corredor.nombrecorredor||' al tel�fono: '||vt_corredor.telefono_corredor||
                               ' , o email: '||vt_corredor.email_corredor ,
                               p_host => v_host);
  END email_envia_aut_orden;
   
  PROCEDURE email_envia_aut_orden_ln(p_cod_cia IN VARCHAR2, p_cod_cliente IN VARCHAR2,
                                           p_no_orden IN VARCHAR2)IS    
    
    vt_dgeneral operaciones.dgeneral%ROWTYPE;
    vt_corredor operaciones.corredor%ROWTYPE;
    vt_cliente  operaciones.cliente%ROWTYPE;
    v_host      saif2000.tasepara.smtp_out_server_activo%TYPE;
    v_cuenta_envio_email saif2000.tasepara.cuenta_envio_email%TYPE;
    
  BEGIN  
      vt_dgeneral := operaciones.pkg_queries.datos_dgeneral(p_cod_cia);
      vt_cliente  := operaciones.pkg_queries.datos_cliente(p_cod_cia,p_cod_cliente);
      vt_corredor := operaciones.pkg_queries.datos_corredor(p_cod_cia,vt_cliente.corredor);
      v_host      := SAIF2000.PKG_UTILIDADES.host_email(p_cod_cia);
      v_cuenta_envio_email := saif2000.pkg_utilidades.cuenta_envio_email(p_cod_cia);
       -- corredor
       saif2000.pkg_utilidades.Send_email(p_envia => v_cuenta_envio_email,
                               p_destinatarios => vt_corredor.email_corredor,
                               p_asunto => 'Orden No.'||p_no_orden||' Revisi�n en Listas de Cautela',                                            
                               p_mensaje => 'Se ha enviado para revisi�n en Listas de Cautela la orden No. '||p_no_orden||
                               ' del cliente '||vt_cliente.nombrecliente||'('||vt_cliente.codcliente||')',
                               p_host => v_host);
       -- Cumplimiento - autorizacion operativa de Clientes                                             
       saif2000.pkg_utilidades.Send_email(p_envia => v_cuenta_envio_email,
                               p_destinatarios => vt_dgeneral.recibe_email_aut_operativa_clt,
                               p_asunto => 'AUTORIZACION URGENTE de cliente para transar en BOLSA DE VALORES',                                            
                               p_mensaje => 'Se solicita Revisi�n en lista negra y Autorizacion URGENTE del cliente '
                                            ||vt_cliente.nombrecliente||'('||vt_cliente.codcliente||
                                            '), para poder realizar transacciones en la Bolsa de Valores'
                                             ||CHR(10)||' Para seguimiento o consultas, favor comunicarse con corredor asignado : '||
                                             vt_corredor.nombrecorredor||' al tel�fono: '||vt_corredor.telefono_corredor||
                                             ' , o email: '||vt_corredor.email_corredor ,
                               p_host => v_host);
  END email_envia_aut_orden_ln;
  
  PROCEDURE email_autoriza_clt_orden_ln(p_cod_cia IN VARCHAR2, p_cod_cliente IN VARCHAR2)IS    
    
    vt_dgeneral operaciones.dgeneral%ROWTYPE;
    vt_corredor operaciones.corredor%ROWTYPE;
    vt_cliente  operaciones.cliente%ROWTYPE;
    v_host      saif2000.tasepara.smtp_out_server_activo%TYPE;
    v_cuenta_envio_email saif2000.tasepara.cuenta_envio_email%TYPE;
    
  BEGIN  
      vt_dgeneral := operaciones.pkg_queries.datos_dgeneral(p_cod_cia);
      vt_cliente  := operaciones.pkg_queries.datos_cliente(p_cod_cia,p_cod_cliente);
      vt_corredor := operaciones.pkg_queries.datos_corredor(p_cod_cia,vt_cliente.corredor);
      v_host      := SAIF2000.PKG_UTILIDADES.host_email(p_cod_cia);
      v_cuenta_envio_email := saif2000.pkg_utilidades.cuenta_envio_email(p_cod_cia);
       -- corredor
       saif2000.pkg_utilidades.Send_email(p_envia => v_cuenta_envio_email,
                               p_destinatarios => vt_corredor.email_corredor,
                               p_asunto => 'Revisi�n en Listas de Cautela Finalizada',                                            
                               p_mensaje => 'Revisi�n en Listas de Cautela finalizada para el cliente '||vt_cliente.nombrecliente||'('||vt_cliente.codcliente||'), Su orden se encuentra en autorizaci�n',
                               p_host => v_host);
       -- Cumplimiento - Autorizacion de Clientes para operar                        
       saif2000.pkg_utilidades.Send_email(p_envia => v_cuenta_envio_email,
                               p_destinatarios => vt_dgeneral.recibe_email_aut_ordenes_clt,
                               p_asunto => 'Revisi�n de Cliente en Lista Negra Finalizada',                                            
                               p_mensaje => 'Se ha finalizado la revisi�n en Lista Negra del cliente '||
                               vt_cliente.nombrecliente||'('||vt_cliente.codcliente||
                               '), Prosiga con la autorizaci�n de ordenes pendientes.'
                               ||CHR(10)||' Para seguimiento o consultas, favor comunicarse con corredor asignado : '||
                              vt_corredor.nombrecorredor||' al tel�fono: '||vt_corredor.telefono_corredor||
                              ' , o email: '||vt_corredor.email_corredor ,
                               p_host => v_host);                                                        
  END email_autoriza_clt_orden_ln;
       
  PROCEDURE email_envia_orden_fuera_perfil(p_cod_cia IN VARCHAR2, p_cod_cliente IN VARCHAR2,
                                           p_no_orden IN VARCHAR2, p_titulos_fuera_perfil in varchar2)
  IS    
    
    vt_dgeneral operaciones.dgeneral%ROWTYPE;
    vt_corredor operaciones.corredor%ROWTYPE;
    vt_cliente  operaciones.cliente%ROWTYPE;
    v_host      saif2000.tasepara.smtp_out_server_activo%TYPE;
    v_cuenta_envio_email saif2000.tasepara.cuenta_envio_email%TYPE;
    
  BEGIN  
      vt_dgeneral := operaciones.pkg_queries.datos_dgeneral(p_cod_cia);
      vt_cliente  := operaciones.pkg_queries.datos_cliente(p_cod_cia,p_cod_cliente);
      vt_corredor := operaciones.pkg_queries.datos_corredor(p_cod_cia,vt_cliente.corredor);
      v_host      := SAIF2000.PKG_UTILIDADES.host_email(p_cod_cia);
      v_cuenta_envio_email := saif2000.pkg_utilidades.cuenta_envio_email(p_cod_cia);
       -- autorizador de ordenes de operacion                         
       saif2000.pkg_utilidades.Send_email(p_envia => v_cuenta_envio_email,
                               p_destinatarios => vt_dgeneral.recibe_email_aut_ordenes_clt,
                               p_asunto => 'TITULOS FUERA DE PERFIL DEL CLIENTE en Orden No.'||p_no_orden,                                            
                               p_mensaje => 'Se informa que la orden No. '||p_no_orden||
                               ' del cliente '||vt_cliente.nombrecliente||'('||vt_cliente.codcliente||'). '
                               ||CHR(10)||' Contiene los siguiente t�tulos fuera de su perfil'||p_titulos_fuera_perfil
                               ||CHR(10)||' Para seguimiento o consultas, favor comunicarse con corredor asignado : '||
                               vt_corredor.nombrecorredor||' al tel�fono: '||vt_corredor.telefono_corredor||
                               ' , o email: '||vt_corredor.email_corredor ,
                               p_host => v_host);
  END email_envia_orden_fuera_perfil; 
  
  PROCEDURE copia_titulos_a_otra_orden(
    p_cod_cia IN VARCHAR2, 
    p_no_orden INTEGER, 
    p_new_no_orden IN INTEGER)
  IS
    TYPE tt_titulos IS TABLE OF operaciones.tambtitxord%ROWTYPE;
    
    vtt_titulos tt_titulos;
  BEGIN
    SELECT *
    BULK COLLECT INTO vtt_titulos
    FROM operaciones.tambtitxord
    WHERE cod_cia = p_cod_cia AND
        no_orden = p_no_orden;
        
    FOR indx IN 1 .. vtt_titulos.COUNT
    LOOP
        vtt_titulos(indx).no_orden := p_new_no_orden; 
    END LOOP;
    
    FORALL indx IN 1 .. vtt_titulos.COUNT
        INSERT INTO operaciones.tambtitxord
        VALUES  vtt_titulos(indx);
  END;
  
  PROCEDURE copia_datos_a_otra_orden(
    p_cod_cia IN VARCHAR2, 
    p_no_orden INTEGER, 
    p_new_no_orden IN INTEGER)
  IS
    vrt_new_orden operaciones.tambordenes%ROWTYPE;
  BEGIN
    SELECT *
    INTO vrt_new_orden
    FROM operaciones.tambordenes
    WHERE cod_cia = p_cod_cia AND
        no_orden = p_no_orden;
        
    vrt_new_orden.no_orden := p_new_no_orden;   
    vrt_new_orden.fecha_proceso := null;
    vrt_new_orden.observaciones := null;
    --Inserta la nueva orden con el estado pendiente de ejecutar y no autorizada
    vrt_new_orden.estado_orden := 'P';
    vrt_new_orden.orden_autorizada := 'N';
    
    INSERT INTO operaciones.tambordenes
    VALUES vrt_new_orden;
  END;
  
  FUNCTION duplica_orden_con_nuevo_id(
    p_cod_cia IN VARCHAR2, 
    p_no_orden INTEGER) RETURN INTEGER
  IS
    v_no_orden INTEGER;  
  
    FUNCTION calcula_no_orden(p_cod_cia IN VARCHAR2) RETURN INTEGER
    IS
        v_no_orden INTEGER;
    BEGIN
        SELECT MAX(NVL(no_orden,0)) + 1
        INTO v_no_orden
        FROM operaciones.tambordenes
        WHERE cod_cia = p_cod_cia;
        
        RETURN v_no_orden;
    END;
  BEGIN
    v_no_orden := calcula_no_orden(p_cod_cia);
    copia_datos_a_otra_orden(p_cod_cia, p_no_orden, v_no_orden);
    copia_titulos_a_otra_orden(p_cod_cia, p_no_orden, v_no_orden);
    
    RETURN v_no_orden;
  EXCEPTION 
    WHEN OTHERS THEN
      SAIF2000.ERRPKG.LOG_ERROR('operaciones.pkg_operaciones_reglas_negocio.duplica_orden_con_nuevo_id');
      RAISE;
  END;
  
  PROCEDURE rectifica_orden(
    p_cod_cia IN VARCHAR2, 
    p_no_orden INTEGER, 
    p_new_no_orden IN INTEGER)
  IS
  BEGIN
    UPDATE operaciones.tambordenes
    SET estado_orden = 'R', observaciones = 'RECTIFICADA con nuevo numero de orden '||p_new_no_orden
        ||'. '||observaciones
    WHERE cod_cia = p_cod_cia AND 
        no_orden = p_no_orden;
  END;
  
  PROCEDURE modifica_orden(
    p_cod_cia IN VARCHAR2, 
    p_no_orden INTEGER, 
    p_new_no_orden IN INTEGER)
  IS
  BEGIN
    UPDATE operaciones.tambordenes
    SET estado_orden = 'A', observaciones = 'MODIFICADA con nuevo numero de orden '||p_new_no_orden
        ||'. '||observaciones
    WHERE cod_cia = p_cod_cia AND 
        no_orden = p_no_orden;
  END;
  
 PROCEDURE actualiza_numero_orden_boleta(p_cod_cia IN VARCHAR2, 
                                         p_nm_operacion IN INTEGER, 
                                         P_no_orden IN INTEGER,
                                         P_tipo_orden IN VARCHAR2)
 IS                                          
   BEGIN
        IF p_tipo_orden = 'C' THEN
          Update operaciones.boleta
          Set no_orden = p_no_orden
          WHERE Cod_cia      = p_cod_cia
          AND nm_operacion = p_nm_operacion;
        END IF;              
        IF p_tipo_orden = 'V' THEN
          Update operaciones.boleta
          Set no_ordenv = p_no_orden
          WHERE Cod_cia      = p_cod_cia
            AND nm_operacion = p_nm_operacion;  
        END IF; 
   EXCEPTION 
    WHEN OTHERS THEN
      SAIF2000.ERRPKG.LOG_ERROR('operaciones.pkg_operaciones_reglas_negocio.actualiza n�mero orden boleta. Orden '||p_no_orden||' Opracion '||p_nm_operacion);
      RAISE;     
   END actualiza_numero_orden_boleta;
END PKG_OPERACIONES_REGLAS_NEGOCIO;
/

GRANT EXECUTE ON OPERACIONES.PKG_OPERACIONES_REGLAS_NEGOCIO TO ACTIVO;

GRANT EXECUTE ON OPERACIONES.PKG_OPERACIONES_REGLAS_NEGOCIO TO BANCOS;

GRANT EXECUTE ON OPERACIONES.PKG_OPERACIONES_REGLAS_NEGOCIO TO CONTA;

GRANT EXECUTE ON OPERACIONES.PKG_OPERACIONES_REGLAS_NEGOCIO TO CUSTODIA;

GRANT EXECUTE ON OPERACIONES.PKG_OPERACIONES_REGLAS_NEGOCIO TO IVA;

GRANT EXECUTE ON OPERACIONES.PKG_OPERACIONES_REGLAS_NEGOCIO TO PLANILLA;

GRANT EXECUTE ON OPERACIONES.PKG_OPERACIONES_REGLAS_NEGOCIO TO PROVEE;

GRANT EXECUTE ON OPERACIONES.PKG_OPERACIONES_REGLAS_NEGOCIO TO PUBLIC;

GRANT EXECUTE ON OPERACIONES.PKG_OPERACIONES_REGLAS_NEGOCIO TO SAIF2000;
