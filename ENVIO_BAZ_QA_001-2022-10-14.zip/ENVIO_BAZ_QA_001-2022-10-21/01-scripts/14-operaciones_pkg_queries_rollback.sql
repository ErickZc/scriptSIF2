
CREATE OR REPLACE PACKAGE OPERACIONES."PKG_QUERIES" AS
/******************************************************************************
   NAME:       PKG_QUERIES
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        24/04/2017      Vicky       1. Created this package.
******************************************************************************/
    TYPE record_datos_operacion_orden IS RECORD
    ( cod_cia                       operaciones.boleta.cod_cia%type, 
      titulo                        operaciones.boleta.c_titulo%type,
      serie                         operaciones.boleta.serie%type, 
      plazo_titulo                  number, 
      emisor                        operaciones.tacemibv.emisor%type, 
      tasa_vigente                  operaciones.tacemibv.tasa_vigente%type, 
      fecha_venc_emision            operaciones.tacemibv.fecha_vence%type,
      plazo_operacion_ejecutado     operaciones.boleta.plazo_op%type,
      rendimiento_bruto_ejecutado   operaciones.boleta.ren_bto%type,  
      monto_ejecutado               operaciones.boleta.v_transado %type,  
      nm_operacion                  operaciones.boleta.nm_operacion%type, 
      codcliente                    operaciones.boleta.codcliente%type,       
      tipo_operacion                varchar2(1),
      perfil_riesgo_emision         operaciones.tacemibv.perfil_riesgo%type
    );    
    
    FUNCTION codigo_casa (p_compania IN VARCHAR2, p_raise_exception IN BOOLEAN)
        RETURN operaciones.dgeneral.cod_casa%TYPE;

    FUNCTION descri_estado_cliente(p_compania IN VARCHAR2,
                                    p_cod_cliente IN VARCHAR2,
                                    p_raise_no_data_found IN BOOLEAN := FALSE)
        RETURN VARCHAR2;

    FUNCTION nombre_cliente(p_compania IN VARCHAR2,
                                    p_cod_cliente IN VARCHAR2,
                                    p_raise_no_data_found IN BOOLEAN := FALSE)
        RETURN VARCHAR2;

    FUNCTION nombre_corredor(p_compania IN VARCHAR2,
                                    p_cod_corredor IN VARCHAR2,
                                    p_raise_no_data_found IN BOOLEAN := FALSE)
        RETURN VARCHAR2;

    FUNCTION nombre_tipoclie(p_compania IN VARCHAR2,
                                    p_tipoclie IN VARCHAR2,
                                    p_raise_no_data_found IN BOOLEAN := FALSE)
    RETURN VARCHAR2;

    FUNCTION descripcion_perfil(p_compania IN VARCHAR2,
                                    p_id_perfil IN VARCHAR2,
                                    p_raise_no_data_found IN BOOLEAN := FALSE)
    RETURN VARCHAR2;

    FUNCTION id_duplicado_nacionalidad(p_compania IN VARCHAR2,
                                    p_id_catalogo IN VARCHAR2)
    RETURN BOOLEAN;

    FUNCTION id_duplicado_motivos(p_compania IN VARCHAR2,
                                    p_id_motivos IN VARCHAR2)
    RETURN BOOLEAN;

    FUNCTION id_duplicado_categorias(p_compania IN VARCHAR2,
                                     p_id IN VARCHAR2)
    RETURN BOOLEAN;

    FUNCTION id_duplicado_procedencia(p_compania IN VARCHAR2,
                                     p_id_procedencia IN VARCHAR2)
    RETURN BOOLEAN;

    FUNCTION id_duplicado_perfiles_riesgo(p_compania IN VARCHAR2,
                                     p_id_perfiles_riesgo IN VARCHAR2)
    RETURN BOOLEAN;

    FUNCTION descripcion_mercado(p_codmercado IN VARCHAR2,
                                 p_raise_no_data_found IN BOOLEAN := FALSE)
    RETURN VARCHAR2;

    FUNCTION tipo_mercado_duplicado(p_compania IN VARCHAR2,
                                    p_id_procedencia IN VARCHAR2,
                                    p_cod_mercado IN VARCHAR2)
    RETURN BOOLEAN;

    FUNCTION descripcion_procedencia(p_compania IN VARCHAR2,
                                 p_id_procedencia IN VARCHAR2,
                                 p_raise_no_data_found IN BOOLEAN := FALSE)
    RETURN VARCHAR2;

    FUNCTION descripcion_cuenta(p_compania IN VARCHAR2,
                                 p_cte IN VARCHAR2,
                                 p_cta IN VARCHAR2,
                                 p_tcta IN VARCHAR2,
                                 p_raise_no_data_found IN BOOLEAN := FALSE)
    RETURN VARCHAR2;

    FUNCTION nombre_cliente_cuenta(p_compania IN VARCHAR2,
                                 p_cliente IN VARCHAR2,
                                 p_raise_no_data_found IN BOOLEAN := FALSE)
    RETURN VARCHAR2;

    FUNCTION id_lista_negra(p_nombre_persona IN VARCHAR2,
                            p_raise_no_data_found IN BOOLEAN := FALSE)
    RETURN INTEGER;

    FUNCTION nombre_archivo_ln(p_id IN VARCHAR2,
                                p_raise_no_data_found IN BOOLEAN := FALSE)
    RETURN VARCHAR2;

    FUNCTION ruta_lista_negra(p_compania IN VARCHAR2,
                                p_raise_no_data_found IN BOOLEAN := FALSE)
    RETURN VARCHAR2;

    FUNCTION ruta_subida_firmas(p_compania IN VARCHAR2,
                                p_raise_no_data_found IN BOOLEAN := FALSE)
    RETURN VARCHAR2;

    FUNCTION sensibilidad_busqueda_ln(p_compania IN VARCHAR2,
                                    p_raise_no_data_found IN BOOLEAN := FALSE)
    RETURN INTEGER;

    FUNCTION ruta_descarga_xml(p_compania IN VARCHAR2,
                                        p_raise_no_data_found IN BOOLEAN := FALSE)
    RETURN VARCHAR2;

    FUNCTION edit_distance_busqueda_ln(p_compania IN VARCHAR2,
                                        p_raise_no_data_found IN BOOLEAN := FALSE)
    RETURN INTEGER;
    FUNCTION nombre_conyuge(p_compania IN VARCHAR2,
                           p_cod_cliente IN VARCHAR2,
                           p_raise_no_data_found IN BOOLEAN := FALSE)
        RETURN VARCHAR2;
    FUNCTION lugar_trabajo(p_compania IN VARCHAR2,
                           p_cod_cliente IN VARCHAR2,
                           p_raise_no_data_found IN BOOLEAN := FALSE)
        RETURN VARCHAR2;
    FUNCTION nombre_persona_dependencia(p_compania IN VARCHAR2,
                           p_cod_cliente IN VARCHAR2,
                           p_raise_no_data_found IN BOOLEAN := FALSE)
        RETURN VARCHAR2;
    FUNCTION nombre_relacionado_ppe(p_compania IN VARCHAR2,
                           p_cod_cliente IN VARCHAR2,
                           p_raise_no_data_found IN BOOLEAN := FALSE)
        RETURN VARCHAR2;
    FUNCTION datos_cliente(p_cod_cia IN VARCHAR2,
                            p_cod_cliente IN VARCHAR2,
                            p_raise_no_data_found IN BOOLEAN DEFAULT FALSE)
        RETURN operaciones.cliente%ROWTYPE;
        
    FUNCTION datos_tambcargos_preview (p_cod_cia in varchar2, 
                                    p_no_operacion in INTEGER, 
                                    p_raise_no_data_found IN BOOLEAN DEFAULT FALSE)
    
    RETURN operaciones.tambcargos_preview%ROWTYPE;
    
    
    FUNCTION datos_tambordenes (p_cod_cia in varchar2, 
                                    p_no_orden in INTEGER, 
                                    p_raise_no_data_found IN BOOLEAN DEFAULT FALSE)
    
    RETURN operaciones.tambordenes%ROWTYPE;    
    
    
    FUNCTION datos_operacion_orden (pcompania in varchar2, 
                                    p_no_orden in INTEGER, 
                                    p_nm_operacion in INTEGER,
                                    p_tipo_operacion in varchar2,
                                    p_raise_no_data_found IN BOOLEAN DEFAULT FALSE)
    
    RETURN pkg_queries.record_datos_operacion_orden;
    

    FUNCTION reg_pend_verifica_ln(p_compania IN VARCHAR2,
                                  p_cod_cliente IN VARCHAR2)
        RETURN BOOLEAN;

    FUNCTION reg_pend_verifica_fatca(p_compania IN VARCHAR2,
                                  p_cod_cliente IN VARCHAR2)
        RETURN BOOLEAN;

    FUNCTION techo_uif (p_compania IN VARCHAR2,
                        p_raise_no_data_found IN BOOLEAN DEFAULT FALSE)
        RETURN NUMBER;
    FUNCTION existe_plantilla_contable (p_cod_cia IN VARCHAR2,
                                        p_tipo_plantilla IN VARCHAR2,
                                        p_tipo_cliente IN VARCHAR2,
                                        p_mercado IN VARCHAR2,
                                        p_tipo_partida IN VARCHAR2)
        RETURN BOOLEAN;

    FUNCTION existe_liquidacion (p_cod_cia IN VARCHAR2,
                                 p_fecha IN VARCHAR2)
        RETURN BOOLEAN;

    
    FUNCTION tipo_documento_iva_compra (p_compania IN VARCHAR2,  
                                  p_no_operacion IN VARCHAR2,
                                  p_raise_no_data_found IN BOOLEAN DEFAULT FALSE)
        RETURN VARCHAR2;
        
    FUNCTION tipo_documento_iva_venta (p_compania IN VARCHAR2,  
                              p_no_operacion IN VARCHAR2,
                              p_raise_no_data_found IN BOOLEAN DEFAULT FALSE)
    RETURN VARCHAR2;
    
    FUNCTION correla_movim_iva_compra (p_compania IN VARCHAR2,  
                              p_no_operacion IN VARCHAR2,
                              p_raise_no_data_found IN BOOLEAN DEFAULT FALSE)
    RETURN VARCHAR2;
    
    FUNCTION correla_movim_iva_venta (p_compania IN VARCHAR2,  
                              p_no_operacion IN VARCHAR2,
                              p_raise_no_data_found IN BOOLEAN DEFAULT FALSE)
    RETURN VARCHAR2;
    
    FUNCTION numero_documento_iva_compra (p_compania IN VARCHAR2,  
                              p_no_operacion IN VARCHAR2,
                              p_raise_no_data_found IN BOOLEAN DEFAULT FALSE)
    RETURN VARCHAR2;
    FUNCTION numero_documento_iva_venta (p_compania IN VARCHAR2,  
                              p_no_operacion IN VARCHAR2,
                              p_raise_no_data_found IN BOOLEAN DEFAULT FALSE)
    RETURN VARCHAR2;
    
    FUNCTION monto_retencion_iva (p_compania IN VARCHAR2, p_tipo_documento_iva IN VARCHAR2, 
                                  p_correla_movim_iva IN VARCHAR2,
                                  p_raise_no_data_found IN BOOLEAN DEFAULT FALSE)
        RETURN NUMBER;
    FUNCTION get_monto_plantilla_operacion (pcompania IN VARCHAR2,ptipo_partida IN VARCHAR2,
                                            ptipo_Monto IN VARCHAR2, pno_operacion IN INTEGER)
        RETURN NUMBER;

    FUNCTION es_pais_operaciones (p_cod_cia IN VARCHAR2,
                                  p_cod_pais IN VARCHAR)
        RETURN BOOLEAN;

    FUNCTION cod_banco_pago_intereses(p_compania IN VARCHAR2,
                                        p_raise_no_data_found IN BOOLEAN DEFAULT FALSE)
        RETURN VARCHAR2;

    FUNCTION no_cuenta_pago_intereses(p_compania IN VARCHAR2,
                                        p_raise_no_data_found IN BOOLEAN DEFAULT FALSE)
        RETURN VARCHAR2;

    FUNCTION monto_cobro_trans_ext(p_compania IN VARCHAR2,
                                    p_raise_no_data_found IN BOOLEAN DEFAULT FALSE)
        RETURN NUMBER;
      
    FUNCTION techo_cobro_trans_ext(p_compania IN VARCHAR2,
                                    p_raise_no_data_found IN BOOLEAN DEFAULT FALSE)
        RETURN NUMBER;
    FUNCTION vence_documento_identidad (p_cod_cia IN VARCHAR2,
                              p_tipo_documento IN VARCHAR)
    RETURN BOOLEAN;
    FUNCTION descripcion_parentesco(p_compania IN VARCHAR2,
                                 p_id_parentesco IN VARCHAR2,
                                 p_raise_no_data_found IN BOOLEAN := FALSE)
    RETURN VARCHAR2;
    
    FUNCTION datos_dgeneral(p_cod_cia IN VARCHAR2,                            
                            p_raise_no_data_found IN BOOLEAN DEFAULT FALSE)
        RETURN operaciones.dgeneral%ROWTYPE;    
        
    FUNCTION datos_corredor(p_cod_cia IN VARCHAR2, p_cod_corredor IN VARCHAR2,                            
                        p_raise_no_data_found IN BOOLEAN DEFAULT FALSE)
    RETURN operaciones.corredor%ROWTYPE;
    
    
    FUNCTION datos_tambcuentas_cedeval(p_cod_cia IN VARCHAR2, p_cte IN VARCHAR2, p_cta in varchar2, p_tcta in varchar2,                            
                            p_raise_no_data_found IN BOOLEAN DEFAULT FALSE)
        RETURN operaciones.tambcuentas_cedeval%ROWTYPE;    
    
    FUNCTION operacion_en_orden(
      p_cod_cia IN VARCHAR2, p_tipo_orden IN VARCHAR2,
      p_cod_cliente IN VARCHAR2, p_mercado IN VARCHAR2,
      p_cod_titulo IN VARCHAR2, p_serie IN VARCHAR2,
      p_fecha_proceso IN DATE, p_dias_vigencia IN NUMBER,
      p_nm_operacion IN VARCHAR2
    )
      RETURN BOOLEAN;
    
    FUNCTION cod_cliente_cta_cedeval(p_compania IN VARCHAR2,
                                     p_cte IN VARCHAR2,
                                     p_cta IN VARCHAR2,
                                     p_tcta IN VARCHAR2,
                                     p_raise_no_data_found IN BOOLEAN := FALSE)
    RETURN VARCHAR2;
END PKG_QUERIES;
/

GRANT EXECUTE ON OPERACIONES.PKG_QUERIES TO PUBLIC;

GRANT EXECUTE ON OPERACIONES.PKG_QUERIES TO RL_MENU_ADMIN_OPERACIONES;

GRANT EXECUTE ON OPERACIONES.PKG_QUERIES TO RL_SAIF_ADMIN_PROVEE;

GRANT EXECUTE ON OPERACIONES.PKG_QUERIES TO RL_SAIF_ANALISTA_PROYECTOS;

GRANT EXECUTE ON OPERACIONES.PKG_QUERIES TO RL_SAIF_AUDITOR_INTERNO;

GRANT EXECUTE ON OPERACIONES.PKG_QUERIES TO RL_SAIF_CONTADOR;

GRANT EXECUTE ON OPERACIONES.PKG_QUERIES TO RL_SAIF_CORREDOR;

GRANT EXECUTE ON OPERACIONES.PKG_QUERIES TO RL_SAIF_GERENTE;

GRANT EXECUTE ON OPERACIONES.PKG_QUERIES TO RL_SAIF_JEFE_OPERACIONES;

GRANT EXECUTE ON OPERACIONES.PKG_QUERIES TO RL_SAIF_OPERADOR;

GRANT EXECUTE ON OPERACIONES.PKG_QUERIES TO RL_SAIF_OPERADOR_CONTABLE;

GRANT EXECUTE ON OPERACIONES.PKG_QUERIES TO RL_SAIF_SUPERVISOR_OPERACIONES;

CREATE OR REPLACE PACKAGE BODY OPERACIONES.PKG_QUERIES AS
/******************************************************************************
   NAME:       OPERACIONES.PKG_QUERIES
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        24/04/2017      Walter       1. Created this package body.
******************************************************************************/
    FUNCTION codigo_casa (p_compania IN VARCHAR2, p_raise_exception IN BOOLEAN)
        RETURN operaciones.dgeneral.cod_casa%TYPE
    IS
        l_codigo_casa operaciones.dgeneral.cod_casa%TYPE;
    BEGIN
        SELECT cod_casa
        INTO l_codigo_casa
        FROM operaciones.dgeneral
        WHERE codigo = p_compania;

        IF l_codigo_casa IS NULL
        THEN
            RAISE NO_DATA_FOUND;
        END IF;

        RETURN l_codigo_casa;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            IF p_raise_exception
            THEN
                RAISE NO_DATA_FOUND;
            ELSE
                RETURN NULL;
            END IF;
    END codigo_casa;

    FUNCTION descri_estado_cliente(p_compania IN VARCHAR2,
                                    p_cod_cliente IN VARCHAR2,
                                    p_raise_no_data_found IN BOOLEAN := FALSE)
        RETURN VARCHAR2
    IS
        l_estado_cliente operaciones.cliente.estado_cliente%TYPE;
    BEGIN
        SELECT estado_cliente
        INTO l_estado_cliente
        FROM operaciones.cliente
        WHERE cod_cia = p_compania AND
            codcliente = p_cod_cliente;

        IF l_estado_cliente IS NULL
        THEN
            RAISE NO_DATA_FOUND;
        END IF;

        RETURN  CASE
                    WHEN l_estado_cliente = 'A' THEN 'Activo'
                    WHEN l_estado_cliente = 'I' THEN 'Inactivo'
                END;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            IF p_raise_no_data_found
            THEN
                saif2000.errpkg.log_error;
                RAISE NO_DATA_FOUND;
            ELSE
                RETURN NULL;
            END IF;
        WHEN OTHERS THEN
            saif2000.errpkg.log_error;
            RAISE;
    END descri_estado_cliente;

    FUNCTION nombre_cliente(p_compania IN VARCHAR2,
                                    p_cod_cliente IN VARCHAR2,
                                    p_raise_no_data_found IN BOOLEAN := FALSE)
        RETURN VARCHAR2
    IS
        l_nombre_cliente operaciones.cliente.nombrecliente%TYPE;
    BEGIN
        SELECT nombrecliente
        INTO l_nombre_cliente
        FROM operaciones.cliente
        WHERE cod_cia = p_compania AND
            codcliente = p_cod_cliente;

        IF l_nombre_cliente IS NULL
        THEN
            RAISE NO_DATA_FOUND;
        END IF;

        RETURN  l_nombre_cliente;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            IF p_raise_no_data_found
            THEN
                saif2000.errpkg.log_error;
                RAISE NO_DATA_FOUND;
            ELSE
                RETURN NULL;
            END IF;
        WHEN OTHERS THEN
            saif2000.errpkg.log_error;
            RAISE;
    END nombre_cliente;

    FUNCTION nombre_corredor(p_compania IN VARCHAR2,
                                    p_cod_corredor IN VARCHAR2,
                                    p_raise_no_data_found IN BOOLEAN := FALSE)
        RETURN VARCHAR2
    IS
        l_nombre_corredor operaciones.corredor.nombrecorredor%TYPE;
    BEGIN
        SELECT nombrecorredor
        INTO l_nombre_corredor
        FROM operaciones.corredor
        WHERE cod_cia = p_compania AND
          codcorredor = p_cod_corredor;

        IF l_nombre_corredor IS NULL
        THEN
            RAISE NO_DATA_FOUND;
        ELSE
            RETURN  l_nombre_corredor;
        END IF;

    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            IF p_raise_no_data_found
            THEN
                saif2000.errpkg.log_error;
                RAISE NO_DATA_FOUND;
            ELSE
                RETURN NULL;
            END IF;
        WHEN OTHERS THEN
            saif2000.errpkg.log_error;
            RAISE;
    END nombre_corredor;

    FUNCTION nombre_tipoclie(p_compania IN VARCHAR2,
                                    p_tipoclie IN VARCHAR2,
                                    p_raise_no_data_found IN BOOLEAN := FALSE)
    RETURN VARCHAR2
    IS
        l_nombre_tipoclie operaciones.tipoclie.nombretipo%TYPE;
    BEGIN
        SELECT nombretipo
        INTO l_nombre_tipoclie
        FROM operaciones.tipoclie
        WHERE codtipo = p_tipoclie;

        IF l_nombre_tipoclie IS NULL
        THEN
            RAISE NO_DATA_FOUND;
        ELSE
            RETURN  l_nombre_tipoclie;
        END IF;

    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            IF p_raise_no_data_found
            THEN
                saif2000.errpkg.log_error;
                RAISE NO_DATA_FOUND;
            ELSE
                RETURN NULL;
            END IF;
        WHEN OTHERS THEN
            saif2000.errpkg.log_error;
            RAISE;
    END nombre_tipoclie;

      FUNCTION descripcion_perfil(p_compania IN VARCHAR2,
                                    p_id_perfil IN VARCHAR2,
                                    p_raise_no_data_found IN BOOLEAN := FALSE)
    RETURN VARCHAR2
    IS
        l_descripcion_perfil operaciones.tambperfiles_riesgo.descripcion%TYPE;
    BEGIN
        SELECT descripcion
        INTO l_descripcion_perfil
        FROM operaciones.tambperfiles_riesgo
        WHERE id = p_id_perfil;

        IF l_descripcion_perfil IS NULL
        THEN
            RAISE NO_DATA_FOUND;
        ELSE
            RETURN  l_descripcion_perfil;
        END IF;

    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            IF p_raise_no_data_found
            THEN
                saif2000.errpkg.log_error;
                RAISE NO_DATA_FOUND;
            ELSE
                RETURN NULL;
            END IF;
        WHEN OTHERS THEN
            saif2000.errpkg.log_error;
            RAISE;
    END descripcion_perfil;

    FUNCTION id_duplicado_nacionalidad(p_compania IN VARCHAR2,
                                    p_id_catalogo IN VARCHAR2)
    RETURN BOOLEAN
    IS
        l_numero_registros INTEGER;
    BEGIN
        SELECT COUNT(1)
        INTO l_numero_registros
        FROM operaciones.tambcata_nacionalidades
        WHERE cod_cia = p_compania AND
              id = TRIM (p_id_catalogo);

        IF l_numero_registros = 0
        THEN
            RETURN FALSE;
        ELSE
            RETURN TRUE;
        END IF;

    EXCEPTION
        WHEN OTHERS THEN
            saif2000.errpkg.log_error;
            RAISE;
    END id_duplicado_nacionalidad;

    FUNCTION id_duplicado_motivos(p_compania IN VARCHAR2,
                                    p_id_motivos IN VARCHAR2)
    RETURN BOOLEAN
    IS
        l_numero_registros INTEGER;
    BEGIN
        SELECT COUNT(1)
        INTO l_numero_registros
        FROM operaciones.tambcata_motivos_ln
        WHERE cod_cia = p_compania AND
              id = TRIM (p_id_motivos);

        IF l_numero_registros = 0
        THEN
            RETURN FALSE;
        ELSE
            RETURN TRUE;
        END IF;

    EXCEPTION
        WHEN OTHERS THEN
            saif2000.errpkg.log_error;
            RAISE;
    END id_duplicado_motivos;

    FUNCTION id_duplicado_categorias(p_compania IN VARCHAR2,
                                     p_id IN VARCHAR2)
    RETURN BOOLEAN
    IS
        l_numero_registros INTEGER;
    BEGIN
        SELECT COUNT(1)
        INTO l_numero_registros
        FROM operaciones.tambcata_categorias_ln
        WHERE cod_cia = p_compania AND
              id = TRIM (p_id);

        IF l_numero_registros = 0
        THEN
            RETURN FALSE;
        ELSE
            RETURN TRUE;
        END IF;
    EXCEPTION
        WHEN OTHERS THEN
            saif2000.errpkg.log_error;
            RAISE;
    END id_duplicado_categorias;

    FUNCTION id_duplicado_procedencia(p_compania IN VARCHAR2,
                                     p_id_procedencia IN VARCHAR2)
    RETURN BOOLEAN
    IS
        l_numero_registros INTEGER;
    BEGIN
        SELECT COUNT(1)
        INTO l_numero_registros
        FROM operaciones.tambprocedencia_clientes
        WHERE cod_cia = p_compania AND
              id = TRIM (p_id_procedencia);

        IF l_numero_registros = 0
        THEN
            RETURN FALSE;
        ELSE
            RETURN TRUE;
        END IF;
    EXCEPTION
        WHEN OTHERS THEN
            saif2000.errpkg.log_error;
            RAISE;
    END id_duplicado_procedencia;

    FUNCTION id_duplicado_perfiles_riesgo(p_compania IN VARCHAR2,
                                     p_id_perfiles_riesgo IN VARCHAR2)
    RETURN BOOLEAN
    IS
        l_numero_registros INTEGER;
    BEGIN
        SELECT COUNT(1)
        INTO l_numero_registros
        FROM operaciones.tambperfiles_riesgo
        WHERE cod_cia = p_compania AND
              id = TRIM (p_id_perfiles_riesgo);

        IF l_numero_registros = 0
        THEN
            RETURN FALSE;
        ELSE
            RETURN TRUE;
        END IF;
    EXCEPTION
        WHEN OTHERS THEN
            saif2000.errpkg.log_error;
            RAISE;
    END id_duplicado_perfiles_riesgo;

    FUNCTION descripcion_mercado(p_codmercado IN VARCHAR2,
                                 p_raise_no_data_found IN BOOLEAN := FALSE)
    RETURN VARCHAR2
    IS
        l_descripcion_mercado operaciones.mercado.mercado%TYPE;
    BEGIN
        SELECT mercado
        INTO l_descripcion_mercado
        FROM operaciones.mercado
        WHERE codmercado = p_codmercado;

        IF l_descripcion_mercado IS NULL
        THEN
            RAISE NO_DATA_FOUND;
        ELSE

            RETURN  l_descripcion_mercado;
        END IF;

    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            IF p_raise_no_data_found
            THEN
                saif2000.errpkg.log_error;
                RAISE NO_DATA_FOUND;
            ELSE
                RETURN NULL;
            END IF;
        WHEN OTHERS THEN
            saif2000.errpkg.log_error;
            RAISE;
    END descripcion_mercado;

    FUNCTION tipo_mercado_duplicado(p_compania IN VARCHAR2,
                                    p_id_procedencia IN VARCHAR2,
                                    p_cod_mercado IN VARCHAR2)
    RETURN BOOLEAN
    IS
        l_numero_registros INTEGER;
    BEGIN
        SELECT COUNT(1)
        INTO l_numero_registros
        FROM operaciones.tambcomisiones_procedencia
        WHERE cod_cia = p_compania AND
              id_procedencia = p_id_procedencia AND
              cod_mercado = p_cod_mercado;

        IF l_numero_registros = 0
        THEN
            RETURN FALSE;
        ELSE
            RETURN TRUE;
        END IF;
    EXCEPTION
        WHEN OTHERS THEN
            saif2000.errpkg.log_error;
            RAISE;
    END tipo_mercado_duplicado;

    FUNCTION descripcion_procedencia(p_compania IN VARCHAR2,
                                 p_id_procedencia IN VARCHAR2,
                                 p_raise_no_data_found IN BOOLEAN := FALSE)
    RETURN VARCHAR2
    IS
        l_descripcion_procedencias operaciones.tambprocedencia_clientes.descripcion%TYPE;
    BEGIN
        SELECT descripcion
        INTO l_descripcion_procedencias
        FROM operaciones.tambprocedencia_clientes
        WHERE cod_cia = p_compania AND
              id = p_id_procedencia;

        IF l_descripcion_procedencias  IS NULL
        THEN
            RAISE NO_DATA_FOUND;
        ELSE
            RETURN  l_descripcion_procedencias ;
        END IF;

    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            IF p_raise_no_data_found
            THEN
                saif2000.errpkg.log_error;
                RAISE NO_DATA_FOUND;
            ELSE
                RETURN NULL;
            END IF;
        WHEN OTHERS THEN
            saif2000.errpkg.log_error;
            RAISE;
    END descripcion_procedencia ;

    FUNCTION descripcion_cuenta(p_compania IN VARCHAR2,
                                 p_cte IN VARCHAR2,
                                 p_cta IN VARCHAR2,
                                 p_tcta IN VARCHAR2,
                                 p_raise_no_data_found IN BOOLEAN := FALSE)
    RETURN VARCHAR2
    IS
        l_llena_nombre custodia.tacucuentas_bac.nombre%TYPE;
    BEGIN
        SELECT nombre
        INTO l_llena_nombre
        FROM custodia.tacucuentas_bac
        WHERE cte = p_cte and
              cta = p_cta and
              tcta = p_tcta;

        IF l_llena_nombre  IS NULL
        THEN
            RAISE NO_DATA_FOUND;
        ELSE
            RETURN  l_llena_nombre ;
        END IF;

    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            IF p_raise_no_data_found
            THEN
                saif2000.errpkg.log_error;
                RAISE NO_DATA_FOUND;
            ELSE
                RETURN NULL;
            END IF;
        WHEN OTHERS THEN
            saif2000.errpkg.log_error;
            RAISE;
    END descripcion_cuenta ;

    FUNCTION nombre_cliente_cuenta(p_compania IN VARCHAR2,
                                 p_cliente IN VARCHAR2,
                                 p_raise_no_data_found IN BOOLEAN := FALSE)
    RETURN VARCHAR2
    IS
        l_llena_nombre operaciones.cliente.nombrecliente%TYPE;
    BEGIN
        SELECT nombrecliente
        INTO l_llena_nombre
        FROM operaciones.cliente
        WHERE cod_cia = p_compania and
              codcliente = p_cliente;

        IF l_llena_nombre  IS NULL
        THEN
            RAISE NO_DATA_FOUND;
        ELSE
            RETURN  l_llena_nombre ;
        END IF;

    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            IF p_raise_no_data_found
            THEN
                saif2000.errpkg.log_error;
                RAISE NO_DATA_FOUND;
            ELSE
                RETURN NULL;
            END IF;
        WHEN OTHERS THEN
            saif2000.errpkg.log_error;
            RAISE;
    END nombre_cliente_cuenta ;

    FUNCTION id_lista_negra(p_nombre_persona IN VARCHAR2,
                            p_raise_no_data_found IN BOOLEAN := FALSE)
    RETURN INTEGER
    IS
        v_id operaciones.tamblista_negra.id%TYPE;
    BEGIN
        SELECT id
        INTO v_id
        FROM operaciones.tamblista_negra
        WHERE nombre_persona = TRIM(UPPER(p_nombre_persona));

        IF v_id IS NULL
        THEN
            RAISE NO_DATA_FOUND;
        ELSE
            RETURN v_id;
        END IF;

    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            IF p_raise_no_data_found
            THEN
                saif2000.errpkg.log_error;
                RAISE NO_DATA_FOUND;
            ELSE
                RETURN NULL;
            END IF;
        WHEN OTHERS THEN
            saif2000.errpkg.log_error;
            RAISE;
    END id_lista_negra;

    FUNCTION nombre_archivo_ln(p_id IN VARCHAR2,
                                p_raise_no_data_found IN BOOLEAN := FALSE)
    RETURN VARCHAR2
    IS
        v_nombre_archivo operaciones.tambinsumos_lista_negra.nombre_archivo%TYPE;
    BEGIN
        SELECT nombre_archivo
        INTO v_nombre_archivo
        FROM operaciones.tambinsumos_lista_negra
        WHERE id = p_id;

        IF v_nombre_archivo IS NULL
        THEN
            RAISE NO_DATA_FOUND;
        ELSE
            RETURN v_nombre_archivo;
        END IF;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            IF p_raise_no_data_found
            THEN
                saif2000.errpkg.log_error('No se encontraron datos para nombre archivo lista negra');
                RAISE NO_DATA_FOUND;
            ELSE
                RETURN NULL;
            END IF;
        WHEN OTHERS THEN
            saif2000.errpkg.log_error;
            RAISE;
    END nombre_archivo_ln;

    FUNCTION ruta_lista_negra(p_compania IN VARCHAR2,
                                p_raise_no_data_found IN BOOLEAN := FALSE)
    RETURN VARCHAR2
    IS
        v_ruta operaciones.dgeneral.ruta_lista_negra%TYPE;
    BEGIN
        SELECT ruta_lista_negra
        INTO v_ruta
        FROM operaciones.dgeneral
        WHERE codigo = p_compania;

        IF v_ruta IS NULL
        THEN
            RAISE NO_DATA_FOUND;
        ELSE
            RETURN v_ruta;
        END IF;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            IF p_raise_no_data_found
            THEN
                saif2000.errpkg.log_error('No se encontro ruta para archivo lista negra');
                RAISE NO_DATA_FOUND;
            ELSE
                RETURN NULL;
            END IF;
        WHEN OTHERS THEN
            saif2000.errpkg.log_error('Error consultando ruata subida XML');
            RAISE;
    END ruta_lista_negra;

    FUNCTION ruta_subida_firmas(p_compania IN VARCHAR2,
                                p_raise_no_data_found IN BOOLEAN := FALSE)
    RETURN VARCHAR2
    IS
        v_ruta operaciones.dgeneral.ruta_subida_firmas%TYPE;
    BEGIN
        SELECT ruta_subida_firmas
        INTO v_ruta
        FROM operaciones.dgeneral
        WHERE codigo = p_compania;

        IF v_ruta IS NULL
        THEN
            RAISE NO_DATA_FOUND;
        ELSE
            RETURN v_ruta;
        END IF;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            IF p_raise_no_data_found
            THEN
                saif2000.errpkg.log_error('No se encontro ruta para subida de firmas');
                RAISE NO_DATA_FOUND;
            ELSE
                RETURN NULL;
            END IF;
        WHEN OTHERS THEN
            saif2000.errpkg.log_error('Error consultando ruta subida firmas');
            RAISE;
    END ruta_subida_firmas;

    FUNCTION sensibilidad_busqueda_ln(p_compania IN VARCHAR2,
                                        p_raise_no_data_found IN BOOLEAN := FALSE)
    RETURN INTEGER
    IS
        v_sensibilidad_busqueda operaciones.dgeneral.sensibilidad_busqueda_ln%TYPE;
    BEGIN
        SELECT sensibilidad_busqueda_ln
        INTO v_sensibilidad_busqueda
        FROM operaciones.dgeneral
        WHERE codigo = p_compania;

        IF v_sensibilidad_busqueda IS NULL
        THEN
            RAISE NO_DATA_FOUND;
        ELSE
            RETURN v_sensibilidad_busqueda;
        END IF;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            IF p_raise_no_data_found
            THEN
                RAISE NO_DATA_FOUND;
            ELSE
                RETURN NULL;
            END IF;
        WHEN OTHERS THEN
            saif2000.errpkg.log_error('Error consultando el grado de sensibilidad busqueda');
            RAISE;
    END sensibilidad_busqueda_ln;

    FUNCTION ruta_descarga_xml(p_compania IN VARCHAR2,
                                        p_raise_no_data_found IN BOOLEAN := FALSE)
    RETURN VARCHAR2
    IS
        v_ruta_descarga_xml operaciones.dgeneral.ruta_descarga_xml%TYPE;
    BEGIN
        SELECT ruta_descarga_xml
        INTO v_ruta_descarga_xml
        FROM operaciones.dgeneral
        WHERE codigo = p_compania;

        IF v_ruta_descarga_xml IS NULL
        THEN
            RAISE NO_DATA_FOUND;
        ELSE
            RETURN v_ruta_descarga_xml;
        END IF;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            IF p_raise_no_data_found
            THEN
                RAISE NO_DATA_FOUND;
            ELSE
                RETURN NULL;
            END IF;
        WHEN OTHERS THEN
            saif2000.errpkg.log_error('RUTA_DESCARGA_XML');
            RAISE;
    END ruta_descarga_xml;

    FUNCTION edit_distance_busqueda_ln(p_compania IN VARCHAR2,
                                        p_raise_no_data_found IN BOOLEAN := FALSE)
    RETURN INTEGER
    IS
        v_edit_distance_busqueda_ln operaciones.dgeneral.edit_distance_busqueda_ln%TYPE;
    BEGIN
        SELECT edit_distance_busqueda_ln
        INTO v_edit_distance_busqueda_ln
        FROM operaciones.dgeneral
        WHERE codigo = p_compania;

        IF v_edit_distance_busqueda_ln IS NULL
        THEN
            RAISE NO_DATA_FOUND;
        ELSE
            RETURN v_edit_distance_busqueda_ln;
        END IF;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            IF p_raise_no_data_found
            THEN
                RAISE NO_DATA_FOUND;
            ELSE
                RETURN NULL;
            END IF;
        WHEN OTHERS THEN
            saif2000.errpkg.log_error('pkg_queries.edit_distance_busqueda_ln');
            RAISE;
    END edit_distance_busqueda_ln;
   FUNCTION nombre_conyuge(p_compania IN VARCHAR2,
                           p_cod_cliente IN VARCHAR2,
                           p_raise_no_data_found IN BOOLEAN := FALSE)
        RETURN VARCHAR2
    IS
        l_nombre_conyuge operaciones.cliente.nombre_conyuge%TYPE;
    BEGIN
        SELECT nombre_conyuge
        INTO l_nombre_conyuge
        FROM operaciones.cliente
        WHERE cod_cia = p_compania AND
            codcliente = p_cod_cliente;

        IF l_nombre_conyuge IS NULL
        THEN
            RAISE NO_DATA_FOUND;
        END IF;

        RETURN  l_nombre_conyuge;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            IF p_raise_no_data_found
            THEN
                saif2000.errpkg.log_error;
                RAISE NO_DATA_FOUND;
            ELSE
                RETURN NULL;
            END IF;
        WHEN OTHERS THEN
            saif2000.errpkg.log_error;
            RAISE;
    END nombre_conyuge;
    FUNCTION lugar_trabajo(p_compania IN VARCHAR2,
                           p_cod_cliente IN VARCHAR2,
                           p_raise_no_data_found IN BOOLEAN := FALSE)
        RETURN VARCHAR2
    IS
        l_lugar_trabajo operaciones.cliente.lugartrabajo%TYPE;
    BEGIN
        SELECT lugartrabajo
        INTO l_lugar_trabajo
        FROM operaciones.cliente
        WHERE cod_cia = p_compania AND
            codcliente = p_cod_cliente;

        IF l_lugar_trabajo IS NULL
        THEN
            RAISE NO_DATA_FOUND;
        END IF;

        RETURN  l_lugar_trabajo;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            IF p_raise_no_data_found
            THEN
                saif2000.errpkg.log_error;
                RAISE NO_DATA_FOUND;
            ELSE
                RETURN NULL;
            END IF;
        WHEN OTHERS THEN
            saif2000.errpkg.log_error;
            RAISE;
    END lugar_trabajo;
    FUNCTION nombre_persona_dependencia(p_compania IN VARCHAR2,
                           p_cod_cliente IN VARCHAR2,
                           p_raise_no_data_found IN BOOLEAN := FALSE)
        RETURN VARCHAR2
    IS
        l_nombre_persona_dependencia operaciones.cliente.nombre_persona_dependencia%TYPE;
    BEGIN
        SELECT nombre_persona_dependencia
        INTO l_nombre_persona_dependencia
        FROM operaciones.cliente
        WHERE cod_cia = p_compania AND
            codcliente = p_cod_cliente;

        IF l_nombre_persona_dependencia IS NULL
        THEN
            RAISE NO_DATA_FOUND;
        END IF;

        RETURN  l_nombre_persona_dependencia;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            IF p_raise_no_data_found
            THEN
                saif2000.errpkg.log_error;
                RAISE NO_DATA_FOUND;
            ELSE
                RETURN NULL;
            END IF;
        WHEN OTHERS THEN
            saif2000.errpkg.log_error;
            RAISE;
    END nombre_persona_dependencia;
    FUNCTION nombre_relacionado_ppe(p_compania IN VARCHAR2,
                           p_cod_cliente IN VARCHAR2,
                           p_raise_no_data_found IN BOOLEAN := FALSE)
        RETURN VARCHAR2
    IS
        l_nombre_relacionado_ppe operaciones.cliente.nombre_rela%TYPE;
    BEGIN
        SELECT nombre_rela
        INTO l_nombre_relacionado_ppe
        FROM operaciones.cliente
        WHERE cod_cia = p_compania AND
            codcliente = p_cod_cliente;

        IF l_nombre_relacionado_ppe IS NULL
        THEN
            RAISE NO_DATA_FOUND;
        END IF;

        RETURN  l_nombre_relacionado_ppe;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            IF p_raise_no_data_found
            THEN
                saif2000.errpkg.log_error;
                RAISE NO_DATA_FOUND;
            ELSE
                RETURN NULL;
            END IF;
        WHEN OTHERS THEN
            saif2000.errpkg.log_error;
            RAISE;
    END nombre_relacionado_ppe;

    FUNCTION datos_cliente(p_cod_cia IN VARCHAR2,
                            p_cod_cliente IN VARCHAR2,
                            p_raise_no_data_found IN BOOLEAN DEFAULT FALSE)
        RETURN operaciones.cliente%ROWTYPE
    IS
        vrt_datos_cliente operaciones.cliente%ROWTYPE;
    BEGIN
        SELECT *
        INTO vrt_datos_cliente
        FROM operaciones.cliente
        WHERE cod_cia = p_cod_cia
          AND codcliente = p_cod_cliente;

        RETURN vrt_datos_cliente;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            IF p_raise_no_data_found
            THEN
                RAISE NO_DATA_FOUND;
            ELSE
                RETURN NULL;
            END IF;
        WHEN OTHERS THEN
            errpkg.log_error('operaciones.pkg_queries.datos_cliente');
            RAISE;
    END datos_cliente;
    
    FUNCTION datos_tambordenes (p_cod_cia in varchar2, 
                                    p_no_orden in INTEGER, 
                                    p_raise_no_data_found IN BOOLEAN DEFAULT FALSE)
    
    RETURN operaciones.tambordenes%ROWTYPE
    IS
        vrt_datos_tambordenes operaciones.tambordenes%ROWTYPE;
    BEGIN
        SELECT *
        INTO vrt_datos_tambordenes
        FROM operaciones.tambordenes
        WHERE cod_cia = p_cod_cia
          AND no_orden = p_no_orden;

        RETURN vrt_datos_tambordenes;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            IF p_raise_no_data_found
            THEN
                RAISE NO_DATA_FOUND;
            ELSE
                RETURN NULL;
            END IF;
        WHEN OTHERS THEN
            errpkg.log_error('operaciones.pkg_queries.datos_tambordenes');
            RAISE;
    END datos_tambordenes;
    
    FUNCTION datos_tambcargos_preview (p_cod_cia in varchar2, 
                                    p_no_operacion in INTEGER, 
                                    p_raise_no_data_found IN BOOLEAN DEFAULT FALSE)
    
    RETURN operaciones.tambcargos_preview%ROWTYPE
    IS
        vrt_datos_tambcargos_preview operaciones.tambcargos_preview%ROWTYPE;
    BEGIN
        SELECT *
        INTO vrt_datos_tambcargos_preview
        FROM operaciones.tambcargos_preview
        WHERE cod_cia = p_cod_cia
          AND nm_operacion = p_no_operacion;
        RETURN vrt_datos_tambcargos_preview;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            IF p_raise_no_data_found
            THEN
                RAISE NO_DATA_FOUND;
            ELSE
                RETURN NULL;
            END IF;
        WHEN OTHERS THEN
            errpkg.log_error('operaciones.pkg_queries.datos_tambcargos_preview');
            RAISE;
    END datos_tambcargos_preview;
    
    FUNCTION datos_operacion_orden (pcompania in varchar2, 
                                    p_no_orden in INTEGER, 
                                    p_nm_operacion in INTEGER,
                                    p_tipo_operacion in varchar2,
                                    p_raise_no_data_found IN BOOLEAN DEFAULT FALSE)
    
    RETURN pkg_queries.record_datos_operacion_orden
    
    IS
        vrt_datos_operacion_orden operaciones.pkg_queries.record_datos_operacion_orden;    

    BEGIN    
        SELECT todas_las_operaciones.cod_cia, todas_las_operaciones.c_titulo as titulo,
               todas_las_operaciones.serie, (fecha_vence - fecha_emision) as plazo_titulo, 
               emisor.emisor, emisor.tasa_vigente, 
               to_char(fecha_vence, 'dd-mm-yyyy') as periodicidad_pago_titulo, todas_las_operaciones.plazo_op as plazo_operacion_ejecutado,
               nvl(todas_las_operaciones.ren_bto,0) as rendimiento_bruto_ejecutado, 
               todas_las_operaciones.v_nominal as monto_ejecutado, 
               todas_las_operaciones.nm_operacion,
               todas_las_operaciones.codcliente, 
               todas_las_operaciones.tipo_operacion,
               emisor.perfil_riesgo
         INTO vrt_datos_operacion_orden                 
              FROM (
                 SELECT cod_cia, c_titulo, 'V' as tipo_operacion, serie,
                     codcliente_v as cod_cliente, t_mercado as mercado, 
                     f_operacion, nm_operacion, plazo_op, 
                     v_nominal, ren_bto, codcliente_v codcliente
                 FROM operaciones.boleta
                 WHERE codcliente_v is not null
                 UNION ALL
                 SELECT cod_cia, c_titulo, 'C' as tipo_operacion, serie,
                     codcliente as cod_cliente, t_mercado as mercado, 
                     f_operacion, nm_operacion,
                     plazo_op, v_nominal, ren_bto, codcliente                     
                  FROM operaciones.boleta
                  WHERE codcliente IS NOT NULL
                  ) todas_las_operaciones           
        INNER JOIN operaciones.tacemibv emisor ON
        emisor.titulo = todas_las_operaciones.c_titulo AND
        emisor.serie = todas_las_operaciones.serie    
    WHERE todas_las_operaciones.cod_cia = pcompania AND
           todas_las_operaciones.nm_operacion = p_nm_operacion AND
           todas_las_operaciones.tipo_operacion = p_tipo_operacion;
    RETURN vrt_datos_operacion_orden;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            IF p_raise_no_data_found
            THEN
                RAISE NO_DATA_FOUND;
            ELSE
                RETURN NULL;
            END IF;
        WHEN OTHERS THEN
            errpkg.log_error('operaciones.pkg_queries.datos_operacion_orden');
            RAISE;
    END datos_operacion_orden;
    
    FUNCTION reg_pend_verifica_ln(p_compania IN VARCHAR2,
                                  p_cod_cliente IN VARCHAR2)
    RETURN BOOLEAN
    IS
        l_numero_registros INTEGER;
    BEGIN
        SELECT COUNT(1)
        INTO l_numero_registros
        FROM operaciones.tambcoincidencia_lista_negra
        WHERE cod_cia = p_compania
          AND cod_cliente = p_cod_cliente
          AND coincidencia_verdadera is null;

        IF l_numero_registros = 0
        THEN
            RETURN FALSE;
        ELSE
            RETURN TRUE;
        END IF;

    EXCEPTION
        WHEN OTHERS THEN
            saif2000.errpkg.log_error;
            RAISE;
    END reg_pend_verifica_ln;

    FUNCTION reg_pend_verifica_fatca(p_compania IN VARCHAR2,
                                  p_cod_cliente IN VARCHAR2)
    RETURN BOOLEAN
    IS
        l_numero_registros INTEGER;
    BEGIN
        SELECT COUNT(1)
        INTO l_numero_registros
        FROM operaciones.tamblog_indicio_fatca
        WHERE cod_cia = p_compania
          AND cod_cliente = p_cod_cliente
          AND indicio_verdadero is null;

        IF l_numero_registros = 0
        THEN
            RETURN FALSE;
        ELSE
            RETURN TRUE;
        END IF;

    EXCEPTION
        WHEN OTHERS THEN
            saif2000.errpkg.log_error;
            RAISE;
    END reg_pend_verifica_fatca;

    FUNCTION techo_uif (p_compania IN VARCHAR2,
                        p_raise_no_data_found IN BOOLEAN DEFAULT FALSE)
        RETURN NUMBER
    IS
        v_techo_uif NUMBER;
    BEGIN
        SELECT codigo
        INTO v_techo_uif
        FROM operaciones.dgeneral
        WHERE codigo = p_compania;

         IF v_techo_uif IS NULL
        THEN
            RAISE NO_DATA_FOUND;
        END IF;

        RETURN  v_techo_uif;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            IF p_raise_no_data_found
            THEN
                saif2000.errpkg.log_error;
                RAISE NO_DATA_FOUND;
            ELSE
                RETURN NULL;
            END IF;
        WHEN OTHERS THEN
            saif2000.errpkg.log_error;
            RAISE;
    END techo_uif;

    FUNCTION existe_plantilla_contable (p_cod_cia IN VARCHAR2,
                                        p_tipo_plantilla IN VARCHAR2,
                                        p_tipo_cliente IN VARCHAR2,
                                        p_mercado IN VARCHAR2,
                                        p_tipo_partida IN VARCHAR2)
    RETURN BOOLEAN
    IS
        l_numero_registros INTEGER;
    BEGIN
        SELECT COUNT(1)
        INTO l_numero_registros
        From operaciones.tambconta
        WHERE Cod_cia          = p_cod_cia and
              Tipo_plantilla   = p_tipo_plantilla and
              Tipo_clt_conta   = p_tipo_cliente   and
              mercado          = p_mercado        and
              Tipo_partida     = p_tipo_partida;

        IF l_numero_registros = 0
        THEN
            RETURN FALSE;
        ELSE
            RETURN TRUE;
        END IF;

    EXCEPTION
        WHEN OTHERS THEN
            errpkg.log_error('operaciones.pkg_queries.existe_plantilla_contable');
        RAISE;
    END existe_plantilla_contable;

    FUNCTION existe_liquidacion (p_cod_cia IN VARCHAR2,
                                 p_fecha IN VARCHAR2)
    RETURN BOOLEAN
    IS
        l_numero_registros INTEGER;
    BEGIN
        SELECT count(1)
        INTO l_numero_registros
        FROM operaciones.tambeliquidacion
        WHERE  Codigo = p_cod_cia and
               fecha_liquidacion = p_fecha and
               estado_Liquidacion  = 'L'          and      -- Liquidado
               tipo_clt_conta       <> 'BF';               -- Bancos y Financieras

        IF l_numero_registros = 0
        THEN
            RETURN FALSE;
        ELSE
            RETURN TRUE;
        END IF;

    EXCEPTION
        WHEN OTHERS THEN
            errpkg.log_error('operaciones.pkg_queries.existe_liquidacion');
        RAISE;
    END existe_liquidacion;

    FUNCTION tipo_documento_iva_compra (p_compania IN VARCHAR2,  
                                  p_no_operacion IN VARCHAR2,                                  
                                  p_raise_no_data_found IN BOOLEAN DEFAULT FALSE)
        RETURN VARCHAR2
    IS
        v_tipo_documento operaciones.boleta.tipo_documento_iva_compra%type;
    BEGIN
        SELECT tipo_documento_iva_compra
        INTO v_tipo_documento
        FROM operaciones.boleta
        WHERE cod_cia = p_compania
          and nm_operacion = p_no_operacion;

         IF v_tipo_documento IS NULL
        THEN
            RAISE NO_DATA_FOUND;
        END IF;

        RETURN  v_tipo_documento;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            IF p_raise_no_data_found
            THEN
                errpkg.log_error('operaciones.pkg_queries.tipo_documento_iva_compra');
                RAISE NO_DATA_FOUND;
            ELSE
                RETURN NULL;
            END IF;
        WHEN OTHERS THEN
            errpkg.log_error('operaciones.pkg_queries.tipo_documento_iva_compra');
            RAISE;
    END tipo_documento_iva_compra;
    
    FUNCTION tipo_documento_iva_venta (p_compania IN VARCHAR2,  
                                  p_no_operacion IN VARCHAR2,
                                  p_raise_no_data_found IN BOOLEAN DEFAULT FALSE)
        RETURN VARCHAR2
    IS
        v_tipo_documento operaciones.boleta.tipo_documento_iva_compra%type;
    BEGIN
        SELECT tipo_documento_iva_venta
        INTO v_tipo_documento
        FROM operaciones.boleta
        WHERE cod_cia = p_compania
          and nm_operacion = p_no_operacion;

         IF v_tipo_documento IS NULL
        THEN
            RAISE NO_DATA_FOUND;
        END IF;

        RETURN  v_tipo_documento;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            IF p_raise_no_data_found
            THEN
                errpkg.log_error('operaciones.pkg_queries.tipo_documento_iva_venta');
                RAISE NO_DATA_FOUND;
            ELSE
                RETURN NULL;
            END IF;
        WHEN OTHERS THEN
            errpkg.log_error('operaciones.pkg_queries.tipo_documento_iva_venta');
            RAISE;
    END tipo_documento_iva_venta;

    
    FUNCTION correla_movim_iva_compra (p_compania IN VARCHAR2,  
                                  p_no_operacion IN VARCHAR2,                                  
                                  p_raise_no_data_found IN BOOLEAN DEFAULT FALSE)
        RETURN VARCHAR2
    IS
        v_correla_movim operaciones.boleta.correla_movim_iva_compra%type;
    BEGIN
        SELECT correla_movim_iva_compra
        INTO v_correla_movim
        FROM operaciones.boleta
        WHERE cod_cia = p_compania
          and nm_operacion = p_no_operacion;

         IF v_correla_movim IS NULL
        THEN
            RAISE NO_DATA_FOUND;
        END IF;

        RETURN  v_correla_movim;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            IF p_raise_no_data_found
            THEN
                errpkg.log_error('operaciones.pkg_queries.correla_movim_iva_compra');
                RAISE NO_DATA_FOUND;
            ELSE
                RETURN NULL;
            END IF;
        WHEN OTHERS THEN
            errpkg.log_error('operaciones.pkg_queries.correla_movim_iva_compra');
            RAISE;
    END correla_movim_iva_compra;
    
        
    FUNCTION correla_movim_iva_venta (p_compania IN VARCHAR2,  
                                  p_no_operacion IN VARCHAR2,                                  
                                  p_raise_no_data_found IN BOOLEAN DEFAULT FALSE)
        RETURN VARCHAR2
    IS
        v_correla_movim operaciones.boleta.correla_movim_iva_venta%type;
    BEGIN
        SELECT correla_movim_iva_venta
        INTO v_correla_movim
        FROM operaciones.boleta
        WHERE cod_cia = p_compania
          and nm_operacion = p_no_operacion;

         IF v_correla_movim IS NULL
        THEN
            RAISE NO_DATA_FOUND;
        END IF;

        RETURN  v_correla_movim;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            IF p_raise_no_data_found
            THEN
                errpkg.log_error('operaciones.pkg_queries.correla_movim_iva_venta');
                RAISE NO_DATA_FOUND;
            ELSE
                RETURN NULL;
            END IF;
        WHEN OTHERS THEN
            errpkg.log_error('operaciones.pkg_queries.correla_movim_iva_venta');
            RAISE;
    END correla_movim_iva_venta;
    
    FUNCTION numero_documento_iva_compra (p_compania IN VARCHAR2,  
                                  p_no_operacion IN VARCHAR2,
                                  p_raise_no_data_found IN BOOLEAN DEFAULT FALSE)
        RETURN VARCHAR2
    IS
        v_tipo_documento_iva_compra operaciones.boleta.tipo_documento_iva_compra%type;
        v_correla_movim_iva_compra  operaciones.boleta.correla_movim_iva_compra%type;
        v_no_documento_iva_compra   iva.taivecrf.no_documento%type;
    BEGIN
        v_tipo_documento_iva_compra := tipo_documento_iva_compra (p_compania,p_no_operacion);
        v_correla_movim_iva_compra  := correla_movim_iva_compra  (p_compania,p_no_operacion);
        
        SELECT No_documento||serie
        INTO v_no_documento_iva_compra
        FROM iva.taivecrf
        WHERE cod_cia        = p_compania  
          and tipo_documento = v_tipo_documento_iva_compra
          and correla_movim  = v_correla_movim_iva_compra
          and estado_documento = 'I';
         IF v_no_documento_iva_compra IS NULL
        THEN
            RAISE NO_DATA_FOUND;
        END IF;

        RETURN  v_no_documento_iva_compra;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            IF p_raise_no_data_found
            THEN
                errpkg.log_error('operaciones.pkg_queries.no_documento_iva_compra');
                RAISE NO_DATA_FOUND;
            ELSE
                RETURN NULL;
            END IF;
        WHEN OTHERS THEN
            errpkg.log_error('operaciones.pkg_queries.no_documento_iva_compra');
            RAISE;
    END numero_documento_iva_compra;
    
    FUNCTION numero_documento_iva_venta (p_compania IN VARCHAR2,  
                                  p_no_operacion IN VARCHAR2,
                                  p_raise_no_data_found IN BOOLEAN DEFAULT FALSE)
        RETURN VARCHAR2
    IS
        v_tipo_documento_iva_venta operaciones.boleta.tipo_documento_iva_venta%type;
        v_correla_movim_iva_venta  operaciones.boleta.correla_movim_iva_venta%type;
        v_no_documento_iva_venta   iva.taivecrf.no_documento%type;
    BEGIN
        v_tipo_documento_iva_venta := tipo_documento_iva_venta (p_compania,p_no_operacion);
        v_correla_movim_iva_venta  := correla_movim_iva_venta  (p_compania,p_no_operacion);
        
        SELECT No_documento||serie
        INTO v_no_documento_iva_venta
        FROM iva.taivecrf
        WHERE cod_cia        = p_compania  
          and tipo_documento = v_tipo_documento_iva_venta
          and correla_movim  = v_correla_movim_iva_venta
          and estado_documento = 'I';
         IF v_no_documento_iva_venta IS NULL
        THEN
            RAISE NO_DATA_FOUND;
        END IF;

        RETURN  v_no_documento_iva_venta;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            IF p_raise_no_data_found
            THEN
                errpkg.log_error('operaciones.pkg_queries.no_documento_iva_venta');
                RAISE NO_DATA_FOUND;
            ELSE
                RETURN NULL;
            END IF;
        WHEN OTHERS THEN
            errpkg.log_error('operaciones.pkg_queries.no_documento_iva_venta');
            RAISE;
    END numero_documento_iva_venta;
    
    FUNCTION monto_retencion_iva (p_compania IN VARCHAR2, p_tipo_documento_iva IN VARCHAR2, 
                                  p_correla_movim_iva IN VARCHAR2, 
                                  p_raise_no_data_found IN BOOLEAN DEFAULT FALSE)
        RETURN NUMBER
    IS
        v_monto NUMBER;
        
    BEGIN
        SELECT nvl(total_retencion,0)
        INTO v_monto
        FROM iva.taivecrf
        WHERE cod_cia = p_compania
         AND  tipo_documento = p_tipo_documento_iva
         --AND  no_documento||serie = p_no_documento_iva
         AND  correla_movim  = p_correla_movim_iva
         AND  estado_documento = 'I';
         IF v_monto IS NULL
        THEN
            RAISE NO_DATA_FOUND;
        END IF;

        RETURN  v_monto;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            IF p_raise_no_data_found
            THEN
                errpkg.log_error('operaciones.pkg_queries.monto_retencion_iva' );
                RAISE NO_DATA_FOUND;
            ELSE
                RETURN NULL;
            END IF;
        WHEN OTHERS THEN
            errpkg.log_error('operaciones.pkg_queries.monto_retencion_iva');
            RAISE;
    END Monto_retencion_iva;
    
    FUNCTION get_monto_plantilla_operacion (pcompania IN VARCHAR2,ptipo_partida IN VARCHAR2,
                                  ptipo_Monto IN VARCHAR2, pno_operacion IN INTEGER)
    RETURN NUMBER
    IS
        v_monto   number(18,2) := 0;
        tasa    iva.taivpara.tasa_iva%type;
        
    BEGIN
       v_monto := 0;
       
              
       Begin
        Select nvl(tasa_iva,0) /100
        Into tasa
        From IVA.taivpara
        Where Cod_cia = pcompania;
       Exception
           When no_data_found then
                tasa:= 0;
       End;
                       

        Select decode(
               Ptipo_monto, 'N',nvl(v_nominal,0), -- valor nominal
                            'R',round(nvl(v_nominal,0)* (nvl(pre_recomp,0)/100),2), -- valor recompra
                            'T',nvl(v_transado,0), -- valor transado                            
                            -- valor a liquidar cliente:
                            'C', decode(ptipo_partida, '1', (nvl(v_transado,0) + round(nvl(v_comcasa,0),2) + round(nvl(v_combolsa,0),2)), -- compras
                                                       '2', (nvl(v_transado,0) - round(nvl(v_vtacasa,0),2) - round(nvl(v_vtabolsa,0),2)) -- ventas
                                        ), -- fin decode compra / venta

                            -- valor a liquidar Bolsa:
                            'B', decode(ptipo_partida, '1', (nvl(v_transado,0) + round(nvl(v_combolsa,0),2)), -- compras
                                                       '2', (nvl(v_transado,0) - round(nvl(v_vtabolsa,0),2))  -- ventas
                                        ), -- fin decode compra / venta

                            -- valor de las comisiones casa:
                            'M', decode(ptipo_partida, '1', (round(nvl(v_comcasa,0),2) /*+ round(nvl(v_combolsa,0),2)*/), -- compras
                                                       '2', (round(nvl(v_vtacasa,0),2) /*+ round(nvl(v_vtabolsa,0),2)*/)  -- ventas
                                        ), -- fin decode compra / venta

                            -- valor de Garantia:
                            'G', nvl(monto_dado_en_garantia,0), -- valor dado en garantia

                            -- valor gravado de las comisiones casa:
                            'V', decode(ptipo_partida, '1', round((round(nvl(v_comcasa,0),2) /*+ round(nvl(v_combolsa,0),2)*/)/(1+tasa),2), -- compras
                                                       '2', round((round(nvl(v_vtacasa,0),2) /*+ round(nvl(v_vtabolsa,0),2)*/)/(1+tasa),2)  -- ventas
                                        ), -- fin decode compra / venta
                  
                            -- valor Iva de las comisiones casa:
                            'I', decode(ptipo_partida, '1', round((round(nvl(v_comcasa,0),2) /*+ round(nvl(v_combolsa,0),2)*/),2)-
                                                            round((round(nvl(v_comcasa,0),2) /*+ round(nvl(v_combolsa,0),2)*/)/(1+tasa),2),-- compras
                                                       '2', round((round(nvl(v_vtacasa,0),2) /*+ round(nvl(v_vtabolsa,0),2)*/),2)-
                                                            round((round(nvl(v_vtacasa,0),2) /*+ round(nvl(v_vtabolsa,0),2)*/)/(1+tasa),2)  -- ventas
                                        ), -- fin decode compra / venta
                            -- valor de las comisiones BOLSA:
                            'A', decode(ptipo_partida, '1', (/*round(nvl(v_comcasa,0),2) +*/ round(nvl(v_combolsa,0),2)), -- compras
                                                       '2', (/*round(nvl(v_vtacasa,0),2) +*/ round(nvl(v_vtabolsa,0),2))  -- ventas
                                        ), -- fin decode compra / venta
                            -- valor gravado de las comisiones BOLSA:
                            'D', decode(ptipo_partida, '1', round((round(nvl(v_combolsa,0),2))/(1+tasa),2), -- compras
                                                       '2', round((round(nvl(v_vtabolsa,0),2))/(1+tasa),2)  -- ventas
                                        ), -- fin decode compra / venta
                            -- valor Iva de las comisiones BOLSA:
                            'E', decode(ptipo_partida, '1', round((round(nvl(v_combolsa,0),2)),2)-
                                                            round((round(nvl(v_combolsa,0),2))/(1+tasa),2),-- compras
                                                       '2', round((round(nvl(v_vtabolsa,0),2)),2)-
                                                            round((round(nvl(v_vtabolsa,0),2))/(1+tasa),2)  -- ventas
                                        ), -- fin decode compra / venta
                                        
                                        
                            -- valor total de las comisiones casa + comisiones bolsa restando retencion (casa es peque�o o mediano contribuyente) 
                            'S', decode(ptipo_partida, '1', (round(nvl(v_comcasa,0),2) + round(nvl(v_combolsa,0),2)), -- compras
                                                       '2', (round(nvl(v_vtacasa,0),2) + round(nvl(v_vtabolsa,0),2))   -- ventas
                                        ),-- fin decode compra / venta

                            -- valor Transado + Intereses Acumulados de la operacion:
                            'F', decode(ptipo_partida, '1', round(nvl(v_transado,0),2) + round(nvl(Int_acum,0),2), -- compras
                                                       '2', round(nvl(v_transado,0),2) + round(nvl(Int_acum,0),2)  -- ventas
                                        ), -- fin decode compra / venta

                            -- intereses acumulados del recompra
                            'U', nvl(v_nominal,0)- (round(nvl(v_nominal,0)* (nvl(pre_recomp,0)/100),2))
                            
                            ,             

                            --valor total de otros cargos al cliente
                           'O', decode(ptipo_partida, '1', round(nvl(monto_otros_cargos_factura,0),2),
                                                      '2',  round(nvl(monto_otros_cargos_fact_vta,0),2)
                                      ), -- fin decode compra / venta           
                            -- valor gravado otros cargos
                            'P', decode(ptipo_partida, '1',  round((round(nvl(monto_otros_cargos_factura,0),2))/(1+tasa),2),
                                                       '2',  round((round(nvl(monto_otros_cargos_fact_vta,0),2))/(1+tasa),2)
                                        ), -- fin decode compra / venta
                            -- Iva Otros Cargos Al cliente
                            'H', decode(ptipo_partida, '1',  
                                       round(((round(nvl(monto_otros_cargos_factura,0),2))/(1+tasa)) * tasa,2),
                                                       '2', 
                                         round(((round(nvl(monto_otros_cargos_fact_vta,0),2))/(1+tasa))*tasa,2)
                                        ) -- fin decode compra / venta                                             
        
               , 0       ) -- fin decode tipo monto
        Into v_monto
        From operaciones.boleta
        Where  Cod_cia      = pcompania  and
               Nm_operacion = Pno_operacion;
        RETURN v_monto;
    Exception
        WHEN OTHERS THEN
        errpkg.log_error('operaciones.pkg_queries.get_monto_plantilla_operacion');
        RAISE;
    END get_monto_plantilla_operacion;
    
    FUNCTION es_pais_operaciones (p_cod_cia IN VARCHAR2,
                                  p_cod_pais IN VARCHAR)
    RETURN BOOLEAN
    IS
        l_numero_registros INTEGER;
    BEGIN
        SELECT COUNT(1)
        INTO l_numero_registros
        From operaciones.dgeneral
        WHERE codigo          = p_cod_cia and
              cod_pais         = p_cod_pais;
        IF l_numero_registros = 0
        THEN
            RETURN FALSE;
        ELSE
            RETURN TRUE;
        END IF;

    EXCEPTION
        WHEN OTHERS THEN
            errpkg.log_error('operaciones.pkg_queries.existe_plantilla_contable');
        RAISE;
    END es_pais_operaciones;

    FUNCTION cod_banco_pago_intereses(p_compania IN VARCHAR2,
                                        p_raise_no_data_found IN BOOLEAN DEFAULT FALSE)
        RETURN VARCHAR2
    IS
        v_codigo_banco operaciones.dgeneral.cod_banco_pago_intereses%TYPE;
    BEGIN
        SELECT dgeneral.cod_banco_pago_intereses
        INTO v_codigo_banco
        FROM operaciones.dgeneral
        WHERE codigo = p_compania;

         IF v_codigo_banco IS NULL
        THEN
            RAISE NO_DATA_FOUND;
        END IF;

        RETURN  v_codigo_banco;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            IF p_raise_no_data_found
            THEN
                saif2000.errpkg.log_error;
                RAISE NO_DATA_FOUND;
            ELSE
                RETURN NULL;
            END IF;
        WHEN OTHERS THEN
            saif2000.errpkg.log_error('operaciones.pkg_queries.cod_banco_pago_intereses');
            RAISE;
    END cod_banco_pago_intereses;

    FUNCTION no_cuenta_pago_intereses(p_compania IN VARCHAR2,
                                        p_raise_no_data_found IN BOOLEAN DEFAULT FALSE)
        RETURN VARCHAR2
    IS
        v_cuenta_pago_intereses operaciones.dgeneral.no_cuenta_pago_intereses%TYPE;
    BEGIN
        SELECT dgeneral.no_cuenta_pago_intereses
        INTO v_cuenta_pago_intereses
        FROM operaciones.dgeneral
        WHERE codigo = p_compania;

         IF v_cuenta_pago_intereses IS NULL
        THEN
            RAISE NO_DATA_FOUND;
        END IF;

        RETURN  v_cuenta_pago_intereses;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            IF p_raise_no_data_found
            THEN
                saif2000.errpkg.log_error;
                RAISE NO_DATA_FOUND;
            ELSE
                RETURN NULL;
            END IF;
        WHEN OTHERS THEN
            saif2000.errpkg.log_error('operaciones.pkg_queries.no_cuenta_pago_intereses');
            RAISE;
    END no_cuenta_pago_intereses;
    
    FUNCTION monto_cobro_trans_ext(p_compania IN VARCHAR2,
                                    p_raise_no_data_found IN BOOLEAN DEFAULT FALSE)
        RETURN NUMBER
    IS
        v_cobro_transferencia_ext operaciones.dgeneral.cobro_transferencia_exterior%TYPE;
    BEGIN
        SELECT dgeneral.cobro_transferencia_exterior
        INTO v_cobro_transferencia_ext
        FROM operaciones.dgeneral
        WHERE codigo = p_compania;

         IF v_cobro_transferencia_ext IS NULL
        THEN
            RAISE NO_DATA_FOUND;
        END IF;

        RETURN  v_cobro_transferencia_ext;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            IF p_raise_no_data_found
            THEN
                saif2000.errpkg.log_error;
                RAISE NO_DATA_FOUND;
            ELSE
                RETURN NULL;
            END IF;
        WHEN OTHERS THEN
            saif2000.errpkg.log_error('operaciones.pkg_queries.monto_cobro_trans_ext');
            RAISE;
    END monto_cobro_trans_ext;
        
    FUNCTION techo_cobro_trans_ext(p_compania IN VARCHAR2,
                                    p_raise_no_data_found IN BOOLEAN DEFAULT FALSE)
        RETURN NUMBER
    IS
        v_techo_cobro_transf_ext operaciones.dgeneral.techo_cobro_transferencia_ext%TYPE;
    BEGIN
        SELECT dgeneral.techo_cobro_transferencia_ext
        INTO v_techo_cobro_transf_ext
        FROM operaciones.dgeneral
        WHERE codigo = p_compania;

         IF v_techo_cobro_transf_ext IS NULL
        THEN
            RAISE NO_DATA_FOUND;
        END IF;

        RETURN  v_techo_cobro_transf_ext;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            IF p_raise_no_data_found
            THEN
                saif2000.errpkg.log_error;
                RAISE NO_DATA_FOUND;
            ELSE
                RETURN NULL;
            END IF;
        WHEN OTHERS THEN
            saif2000.errpkg.log_error('operaciones.pkg_queries.techo_cobro_trans_ext');
            RAISE;
    END techo_cobro_trans_ext;
    FUNCTION vence_documento_identidad (p_cod_cia IN VARCHAR2,
                              p_tipo_documento IN VARCHAR)
    RETURN BOOLEAN
    IS
        l_numero_registros INTEGER;
    BEGIN
        SELECT COUNT(1)
        INTO l_numero_registros
        From operaciones.tambtipo_documento
        WHERE cod_cia          = p_cod_cia and
              nombre_tipo_documento = p_tipo_documento and
              documento_vence = 'S';
        IF l_numero_registros = 0
        THEN
            RETURN FALSE;
        ELSE
            RETURN TRUE;
        END IF;

    EXCEPTION
        WHEN OTHERS THEN
            errpkg.log_error('operaciones.pkg_queries.vence_documento_identidad');
        RAISE;
    END vence_documento_identidad;
    
    FUNCTION descripcion_parentesco(p_compania IN VARCHAR2,
                                 p_id_parentesco IN VARCHAR2,
                                 p_raise_no_data_found IN BOOLEAN := FALSE)
    RETURN VARCHAR2
    IS
        l_descripcion_parentesco operaciones.tambparentescos.parentesco%TYPE;
    BEGIN
        SELECT parentesco
        INTO l_descripcion_parentesco
        FROM operaciones.tambparentescos
        WHERE cod_cia = p_compania AND
              id_parentesco = p_id_parentesco;

        IF l_descripcion_parentesco  IS NULL
        THEN
            RAISE NO_DATA_FOUND;
        ELSE
            RETURN  l_descripcion_parentesco ;
        END IF;

    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            IF p_raise_no_data_found
            THEN
                saif2000.errpkg.log_error;
                RAISE NO_DATA_FOUND;
            ELSE
                RETURN NULL;
            END IF;
        WHEN OTHERS THEN
            errpkg.log_error('operaciones.pkg_queries.descripcion_parentesco');
            RAISE;
    END descripcion_parentesco;
    
    FUNCTION datos_dgeneral(p_cod_cia IN VARCHAR2,                            
                            p_raise_no_data_found IN BOOLEAN DEFAULT FALSE)
        RETURN operaciones.dgeneral%ROWTYPE
    IS
        vrt_datos_dgeneral operaciones.dgeneral%ROWTYPE;
    BEGIN
        SELECT *
        INTO vrt_datos_dgeneral
        FROM operaciones.dgeneral
        WHERE codigo = p_cod_cia;

        RETURN vrt_datos_dgeneral;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            IF p_raise_no_data_found
            THEN
                RAISE NO_DATA_FOUND;
            ELSE
                RETURN NULL;
            END IF;
        WHEN OTHERS THEN
            errpkg.log_error('operaciones.pkg_queries.datos_dgeneral');
            RAISE;
    END datos_dgeneral; 
    
    FUNCTION datos_corredor(p_cod_cia IN VARCHAR2, p_cod_corredor IN VARCHAR2,                            
                            p_raise_no_data_found IN BOOLEAN DEFAULT FALSE)
        RETURN operaciones.corredor%ROWTYPE
    IS
        vrt_datos_corredor operaciones.corredor%ROWTYPE;
    BEGIN
        SELECT *
        INTO vrt_datos_corredor
        FROM operaciones.corredor
        WHERE cod_cia = p_cod_cia
          AND codcorredor = p_cod_corredor;

        RETURN vrt_datos_corredor;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            IF p_raise_no_data_found
            THEN
                RAISE NO_DATA_FOUND;
            ELSE
                RETURN NULL;
            END IF;
        WHEN OTHERS THEN
            errpkg.log_error('operaciones.pkg_queries.datos_corredor');
            RAISE;
    END datos_corredor; 
    
    
    FUNCTION datos_tambcuentas_cedeval(p_cod_cia IN VARCHAR2, p_cte IN VARCHAR2, p_cta in varchar2, p_tcta in varchar2,                            
                            p_raise_no_data_found IN BOOLEAN DEFAULT FALSE)
        RETURN operaciones.tambcuentas_cedeval%ROWTYPE
    IS
        vrt_datos_tambcuentas_cedeval operaciones.tambcuentas_cedeval%ROWTYPE;
    BEGIN
        SELECT *
        INTO vrt_datos_tambcuentas_cedeval
        FROM operaciones.tambcuentas_cedeval
        WHERE cod_cia = p_cod_cia
          AND cte     = p_cte
          AND cta     = p_cta
          AND tcta    = p_tcta;

        RETURN vrt_datos_tambcuentas_cedeval;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            IF p_raise_no_data_found
            THEN
                RAISE NO_DATA_FOUND;
            ELSE
                RETURN NULL;
            END IF;
        WHEN OTHERS THEN
            errpkg.log_error('operaciones.pkg_queries.datos_tambcuentas_cedeval');
            RAISE;
    END datos_tambcuentas_cedeval;  
    
    FUNCTION operacion_en_orden(
      p_cod_cia IN VARCHAR2, p_tipo_orden IN VARCHAR2,
      p_cod_cliente IN VARCHAR2, p_mercado IN VARCHAR2,
      p_cod_titulo IN VARCHAR2, p_serie IN VARCHAR2,
      p_fecha_proceso IN DATE, p_dias_vigencia IN NUMBER,
      p_nm_operacion IN VARCHAR2
    )
      RETURN BOOLEAN
    IS
      CURSOR c_operaciones_disponibles IS
        select todas_las_operaciones.cod_cia, todas_las_operaciones.c_titulo as titulo,
          todas_las_operaciones.serie, (fecha_vence - fecha_emision) as plazo_titulo, emisor.emisor,
          emisor.tasa_vigente, to_char(fecha_vence, 'dd-mm-yyyy') as periodicidad_pago_titulo, todas_las_operaciones.plazo_op as plazo_operacion_ejecutado,
          nvl(todas_las_operaciones.ren_bto,0) as rendimiento_bruto_ejecutado, todas_las_operaciones.v_nominal as monto_ejecutado, 
          todas_las_operaciones.nm_operacion, emisor.perfil_riesgo
        from (
          select cod_cia, c_titulo, 'V' as tipo_operacion, serie,
            codcliente_v as cod_cliente, t_mercado as mercado, f_operacion, nm_operacion,
            plazo_op, v_nominal, ren_bto
          from operaciones.boleta
          where codcliente_v is not null
          union all
          select cod_cia, c_titulo, 'C' as tipo_operacion, serie,
            codcliente as cod_cliente, t_mercado as mercado, f_operacion, nm_operacion,
            plazo_op, v_nominal, ren_bto
          from operaciones.boleta
          where codcliente is not null
        ) todas_las_operaciones
        inner join operaciones.tacemibv emisor ON
          emisor.titulo = todas_las_operaciones.c_titulo and
          emisor.serie = todas_las_operaciones.serie
        where todas_las_operaciones.cod_cia = p_cod_cia and 
          ((p_cod_titulo is null or p_serie is null) or (todas_las_operaciones.c_titulo = p_cod_titulo and todas_las_operaciones.serie = p_serie)) and
          p_tipo_orden = todas_las_operaciones.tipo_operacion and
          p_cod_cliente = todas_las_operaciones.cod_cliente and
          p_mercado = todas_las_operaciones.mercado and 
          todas_las_operaciones.f_operacion between p_fecha_proceso and (p_fecha_proceso + p_dias_vigencia - 1) and
          todas_las_operaciones.nm_operacion = p_nm_operacion;      
    BEGIN
      FOR rec IN c_operaciones_disponibles
      LOOP
        RETURN TRUE;
      END LOOP;
      
      RETURN FALSE;
    END;
    
    FUNCTION cod_cliente_cta_cedeval(p_compania IN VARCHAR2,
                                     p_cte IN VARCHAR2,
                                     p_cta IN VARCHAR2,
                                     p_tcta IN VARCHAR2,
                                     p_raise_no_data_found IN BOOLEAN := FALSE)
    RETURN VARCHAR2
    IS
        l_cod_cliente operaciones.cliente.codcliente%TYPE;
    BEGIN
        SELECT cod_cliente
        INTO l_cod_cliente
        FROM operaciones.tambcuentas_cedeval
        WHERE cod_cia = p_compania AND
              cte = p_cte AND
              cta = p_cta AND
              tcta = p_tcta;

        IF l_cod_cliente  IS NULL
        THEN
            RAISE NO_DATA_FOUND;
        ELSE
            RETURN  l_cod_cliente;
        END IF;

    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            IF p_raise_no_data_found
            THEN
                saif2000.errpkg.log_error;
                RAISE NO_DATA_FOUND;
            ELSE
                RETURN NULL;
            END IF;
        WHEN OTHERS THEN
            errpkg.log_error('operaciones.pkg_queries.cod_cliente_cta_cedeval');
            RAISE;
    END cod_cliente_cta_cedeval;    
    
END PKG_QUERIES;
/

GRANT EXECUTE ON OPERACIONES.PKG_QUERIES TO PUBLIC;

GRANT EXECUTE ON OPERACIONES.PKG_QUERIES TO RL_MENU_ADMIN_OPERACIONES;

GRANT EXECUTE ON OPERACIONES.PKG_QUERIES TO RL_SAIF_ADMIN_PROVEE;

GRANT EXECUTE ON OPERACIONES.PKG_QUERIES TO RL_SAIF_ANALISTA_PROYECTOS;

GRANT EXECUTE ON OPERACIONES.PKG_QUERIES TO RL_SAIF_AUDITOR_INTERNO;

GRANT EXECUTE ON OPERACIONES.PKG_QUERIES TO RL_SAIF_CONTADOR;

GRANT EXECUTE ON OPERACIONES.PKG_QUERIES TO RL_SAIF_CORREDOR;

GRANT EXECUTE ON OPERACIONES.PKG_QUERIES TO RL_SAIF_GERENTE;

GRANT EXECUTE ON OPERACIONES.PKG_QUERIES TO RL_SAIF_JEFE_OPERACIONES;

GRANT EXECUTE ON OPERACIONES.PKG_QUERIES TO RL_SAIF_OPERADOR;

GRANT EXECUTE ON OPERACIONES.PKG_QUERIES TO RL_SAIF_OPERADOR_CONTABLE;

GRANT EXECUTE ON OPERACIONES.PKG_QUERIES TO RL_SAIF_SUPERVISOR_OPERACIONES;
