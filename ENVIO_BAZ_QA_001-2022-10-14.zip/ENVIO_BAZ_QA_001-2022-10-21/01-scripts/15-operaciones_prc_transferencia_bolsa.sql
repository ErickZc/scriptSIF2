CREATE OR REPLACE PROCEDURE OPERACIONES.TRANSFERENCIA_BOLSA (cod_cia1 in varchar2, FechaFinal in date, maxfecha in date, FechaInicial in OUT date,
P_error_salida in out varchar2)  
 IS 
 --
 WCODIGO VARCHAR2(2);
 x number;
 Mno_registros   number := 0;
    
 --
 --
BEGIN
 --
/* En esta variable debemos indicar la compa��aa que debe ser igual que el C�digo de la Casa Corredora */
  Begin
    Select cod_casa into wCodigo
    From OPERACIONES.DGENERAL
    where Codigo = cod_cia1;
  exception
      when no_data_found then
           P_error_salida := sqlerrm||' Codigo de Casa no encontrado en Par�metros Generales';
           return;
           when others then
           P_error_salida := sqlerrm||' Seleccionando c�digo de Casa';
            return;
  End;
  --wCodigo := :B0.COD_CIA1;
  --
  /*IF FechaFinal <= maxfecha THEN
    P_error_salida := sqlerrm||'Las operaciones de este periodo ya fueron transferidas.';
    RETURN;
    --  
  ELSIF FechaInicial < maxfecha THEN*/ 
    FechaInicial := maxfecha + 1;
  --END IF;  
  --
/*Begin
  SELECT count(*)
      into x      
      FROM BOLETA_DE_OPERACIONES17@bolsa
     WHERE fecha_operacion
         BETWEEN FechaInicial
             AND FechaFinal and
             to_char(fecha_operacion, 'yyyy')>= 2006;
        exception
           when others then
           P_error_salida := sqlerrm||' Contando operaciones en Bolsa de Valores';
           RETURN;

  end;
  if x = 0 then
      P_error_salida := sqlerrm||'No existen operaciones para este periodo.';
    RETURN;
  end if;*/
  --
  Begin
  delete operaciones.boleta
  WHERE  f_operacion
         BETWEEN FechaInicial
             AND FechaFinal
             and manual_automatica = 'A';
  EXCEPTION
    WHEN OTHERS THEN
         p_error_salida := sqlerrm||'Eliminando operaciones del d�a';
         RETURN;              
  End;
  begin
  --
  INSERT INTO operaciones.boleta 
          (COD_CIA,
          NM_OPERACION,                  F_OPERACION  ,        
              MONEDA       ,              C_TITULO     , 
                SERIE        ,              OPERACION    ,  
                DIAS_OPERA   ,              T_MERCADO    ,  
                TS_INTERES   ,              D_VENCIMIENTO,
                V_NOMINAL    ,              RENDIMIENTO  ,  
                PRECIO       ,              V_TRANSADO   ,  
                V_COMBOLSA   ,              V_VTABOLSA   ,  
                V_COMCASA    ,              V_VTACASA    ,  
                PRE_RECOMP   ,              PLAZO_OP     ,  
                REN_BTO      ,              
                CODCLIENTE   ,            CODCLIENTE_V ,
                T_CLIENTE    ,  
                T_CLIENTE_C  ,             COM_COMPRA   ,
                COM_VENTA    ,        F_LIQUIDA    ,
                INT_ACUM     ,        COM_COMPRABV ,
                COM_VENTABV  ,        COSTO_FINAN  ,
                DIAS_ACUM    ,            CRUZADA,
                F_VENCIMIENTO,                MONTO_DADO_EN_GARANTIA,
                MANUAL_AUTOMATICA)
  SELECT cod_cia1,  
            NUMERO_OPERACION,            TRUNC(FECHA_OPERACION) ,       
                MONEDA          ,            TITULO          ,       
                SERIE           ,            TIPO_OPERACION  ,       
                DIAS_OPERACION  ,            MERCADO         ,       
                TASA_INTERES    ,            DIAS_VENCE      ,       
                VALOR_NOMINAL   ,            RENDI_NETO      ,       
                PRECIO          ,            VALOR_TRANSADO  ,       
                COMI_BVES_C     ,            COMI_BVES_V     ,       
                COMI_CASA_C     ,            COMI_CASA_V     ,       
                PRECIO_RECOMPRA ,            PLAZO_OPERACION ,       
                RENDI_BRUTO     ,            CLIENTE_COMPRA  ,       
                CLIENTE_VENDE   ,            TIPO_CLIENTE_V  ,       
                TIPO_CLIENTE_C  ,     PCOMI_CASA_C    ,
                PCOMI_CASA_V    ,     TRUNC(FECHA_LIQUIDA)   ,
                INTERES_ACUM    ,     PCOMI_BVES_C    ,
                PCOMI_BVES_V    ,     PCOSTO_FINAN    ,
                DIAS_ACUM       ,            'N',
                TRUNC(FECHA_VENCE),  MONTO_DADO_EN_GARANTIA,
                'A'
        From BOLETA_DE_OPERACIONES17@bolsa x
  WHERE  x.fecha_operacion
         BETWEEN FechaInicial
             AND FechaFinal and
             to_char(x.fecha_operacion, 'yyyy') >= 2006  and
             
  Not exists (select 'X' from operaciones.boleta y
                          where to_number(x.nUMERO_operacion) = to_number(y.nm_operacion));
  EXCEPTION            
      when dup_val_on_index then
      P_error_salida := sqlerrm||' Registro ya existe';
     RETURN;
    when no_data_found then
     P_error_salida := sqlerrm||'No hay operaciones para transferir';
     RETURN;
    WHEN others THEN      
      P_error_salida := sqlerrm||' Ha ocurrido un error al trasladar informacion desde la Bolsa de Valores';
      RETURN;
  end;        
  --
  BEGIN
          UPDATE operaciones.boleta SET
                   cruzada  = 'S',
                 c_compra = wcodigo,
                 c_venta  = wcodigo
            WHERE f_operacion  
            BETWEEN FechaInicial
            AND FechaFinal
                    AND SUBSTR(CODCLIENTE,1,2)   = wCodigo
                 AND SUBSTR(CODCLIENTE_V,1,2) = wCodigo;  
  END;     
 -- asignando codigo de casa a operaciones con casa nula
  BEGIN
          UPDATE operaciones.boleta SET
                   c_compra  = Wcodigo
            WHERE f_operacion  
            BETWEEN FechaInicial
            AND FechaFinal
            AND substr(codcliente,1,2) = wcodigo
            and c_compra is null;
  END;          
   BEGIN
          UPDATE operaciones.boleta SET
                   c_venta  = Wcodigo
            WHERE f_operacion  
            BETWEEN FechaInicial
            AND FechaFinal
            AND substr(codcliente_v,1,2) = wcodigo
            and c_venta is null;
  END;  
 --  anulando codigo de clientes cero en boleta
   /*BEGIN
          UPDATE operaciones.boleta SET
                   codcliente  = null
            WHERE f_operacion  
            BETWEEN FechaInicial
            AND FechaFinal
            and regexp_like(codcliente,'^[0-9]+$');
  END;          
   BEGIN
          UPDATE operaciones.boleta SET
                   codcliente_V  = null
            WHERE f_operacion  
            BETWEEN FechaInicial
            AND FechaFinal
            and regexp_like(codcliente_v,'^[0-9]+$');
  END;*/
--
--
/*BEGIN
          UPDATE operaciones.boleta SET
             c_compra = decode(nvl(v_combolsa,0) + nvl(v_comcasa,0), 0,null, wcodigo),
             c_venta  = decode(nvl(v_vtabolsa,0) + nvl(v_vtacasa,0), 0,null, wcodigo)
            WHERE f_operacion  
            BETWEEN FechaInicial
              AND FechaFinal
                    AND  cruzada  = 'N';
  END;*/
 --
  BEGIN
            UPDATE operaciones.boleta SET
                        F_RECOMPRA=F_OPERACION+DIAS_OPERA
                WHERE f_operacion  
            BETWEEN FechaInicial
            AND FechaFinal 
                        AND T_MERCADO='r';
    END;        
--
  BEGIN
            UPDATE operaciones.boleta SET
                        F_RECOMPRA=F_LIQUIDA
                WHERE f_operacion  
            BETWEEN FechaInicial
            AND FechaFinal 
                        AND T_MERCADO<>'r';
  END;  
  
  BEGIN
            
      UPDATE operaciones.boleta x  
      SET    x.tipo_titulo_int = (select y.tipo_titulo
                            from operaciones.tacemibv y
                            where x.cod_cia = y.cod_cia and 
                            X.C_TITULO = Y.TITULO and
                            X.SERIE    = y.serie )
                                                                
                WHERE T_MERCADO ='i' and 
                x.tipo_titulo_int is null;

  END;
  
  --
  -- Actualizando emisiones de bolsa de valores (fechas de pagos de cupones y emisores)
  --
                      -- Si no existe, se inserta la emision
   
                     
                      Begin
                        Insert into OPERACIONES.TacEmibv(COD_CIA, TITULO, SERIE, COD_EMISOR, EMISOR,
                               CODIGO_SIBE, CODIGO_SP, FECHA_ULT_PAGO, TASA_ANTERIOR,
                               TASA_VIGENTE, FECHA_REAJUSTE, FECHA_PROX_REAJUSTE,
                               TASA_BASE, SOBRE_TASA,  FECHA_EMISION, FECHA_VENCE,
                               MONTO_AUTORIZADO, FECHA_PROX_PAGO, TIPO_ANO,
                               gravado_exento, publico_privado, tipo_renta_titulo,
                               perfil_riesgo, 
                               descripcion_emision, dias_al_vencimiento)
                        SELECT '01', TITULO, SERIE, CEMISOR, EMISOR, 
                               CODIGO_SIBE, CODIGO_SP, FECHA_ULT_PAGO, TASA_ANTERIOR,
                               TASA_VIGENTE, FECHA_REAJUSTE, FECHA_PROX_REAJUSTE,
                               TASA_BASE, SOBRE_TASA, FECHA_EMISION, FECHA_VENCE,
                               MONTO_AUTORIZADO, FECHA_PROX_PAGO, TIPO_ANO,
                               Gravado_ISR, 
                               decode(PUBLICO_PRIVADO, 'PU', 'PUBLICO', 'PR', 'PRIVADO'),
                               decode(Tasa_vigente,0, 'V', null, 'V', 'F'), '0',
                               descripcion, dias_vence 
                         From EMISIONES17@bolsa X
               WHERE NOT EXISTS (SELECT 'X' FROM TACEMIBV Y
                 WHERE  X.TITULO = Y.TITULO AND
                        X.SERIE  = Y.SERIE  AND
                        X.CEMISOR = Y.COD_EMISOR);
                        
                      Exception
                      when dup_val_on_index then
                           p_error_salida:= sqlerrm|| ' Registro ya exite en Insertando Emisiones';
                                   return;
                      when others then
                           p_error_salida:= sqlerrm|| ' Insertando Emisiones';
                                   return;
                      End; 
                      
            -- si ya existe, se actualiza la emision
            Begin
                 Update OPERACIONES.TACEMIBV x
                 Set  x.Fecha_ult_pago = (select y.fecha_ult_pago from EMISIONES17@bolsa y
                                           where x.titulo = y.titulo and
                                                 x.serie  = y.serie  and
                                                 x.Cod_emisor = y.cemisor);
                  Exception
                      when others then
                           P_error_salida := sqlerrm||' Actualizando Fecha ultimo pago';
                                   RETURN;
               End;      
            Begin
                 Update OPERACIONES.TACEMIBV x
                 Set  x.tasa_anterior = (select y.tasa_anterior from EMISIONES17@bolsa y
                                           where x.titulo = y.titulo and
                                                 x.serie  = y.serie  and
                                                 x.Cod_emisor = y.cemisor);
                  Exception
                      when others then
                          P_error_salida := sqlerrm|| ' Actualizando tasa anterior';
                           RETURN;
               End;      
            Begin
                 Update OPERACIONES.TACEMIBV x
                 Set    x.tasa_vigente = (select y.tasa_vigente from EMISIONES17@bolsa y
                                           where x.titulo = y.titulo and
                                                 x.serie  = y.serie  and
                                                 x.Cod_emisor = y.cemisor);
                  Exception
                      when others then
                           P_error_salida := sqlerrm|| ' Actualizando tasa vigente';
                          RETURN;
               End;      
            Begin
                 Update OPERACIONES.TACEMIBV x
                 Set                                      
                                        x.fecha_reajuste = (select y.fecha_reajuste from EMISIONES17@bolsa y
                                           where x.titulo = y.titulo and
                                                 x.serie  = y.serie  and
                                                 x.Cod_emisor = y.cemisor);
                  Exception
                      when others then
                           P_error_salida := sqlerrm|| ' Actualizando Fecha reajuste';
                          RETURN;
               End;      
            Begin
                 Update OPERACIONES.TACEMIBV x
                 Set                                          
                                        x.fecha_prox_reajuste = (select y.fecha_prox_reajuste from EMISIONES17@bolsa y
                                           where x.titulo = y.titulo and
                                                 x.serie  = y.serie  and
                                                 x.Cod_emisor = y.cemisor);
                  Exception
                      when others then
                          P_error_salida := sqlerrm|| ' Actualizando Fecha proximo reajuste';
                          RETURN;
               End;      
                                                                                                 
            Begin
                 Update OPERACIONES.TACEMIBV x
                 Set                                          
                                        x.fecha_prox_pago = (select y.fecha_prox_pago from EMISIONES17@bolsa y
                                           where x.titulo = y.titulo and
                                                 x.serie  = y.serie  and
                                                 x.Cod_emisor = y.cemisor);
             Exception
                      when others then
                           P_error_salida := sqlerrm||' Actualizando titulo fecha proximo pago';
                            RETURN;       
                                     
              End;
              
            Begin
                 Update OPERACIONES.TACEMIBV x
                 Set                                          
                                        x.fecha_vence = (select trunc(fecha_vence) from EMISIONES17@bolsa y
                                           where x.titulo = y.titulo and
                                                 x.serie  = y.serie  and
                                                 x.Cod_emisor = y.cemisor);
             Exception
                      when others then
                           P_error_salida := sqlerrm||' Actualizando Fecha de vencimiento';
                            RETURN;       
                                     
              End; 
              
            
            Begin
                 Update OPERACIONES.TACEMIBV x
                 Set  x.EMISOR = 
                      (select Y.EMISOR 
                       from EMISIONES17@bolsa y
                       where x.titulo = y.titulo and
                             x.serie  = y.serie  and
                             x.Cod_emisor = y.cemisor);
             Exception
             when others then
                  P_error_salida := sqlerrm||
                  'Actualizando titulo - EMISOR';
                    RETURN;       
                                     
            End;
            
            Begin
                 Update OPERACIONES.TACEMIBV x
                 Set  x.CODIGO_SIBE = 
                      (select Y.CODIGO_SIBE 
                       from EMISIONES17@bolsa y
                       where x.titulo = y.titulo and
                             x.serie  = y.serie  and
                             x.Cod_emisor = y.cemisor);
             Exception
             when others then
                  P_error_salida := sqlerrm||
                  'Actualizando titulo - CODIGO SIBE';
                    RETURN;       
                                     
            End; 
            Begin
                 Update OPERACIONES.TACEMIBV x
                 Set  x.CODIGO_SP = 
                      (select Y.CODIGO_SP 
                       from EMISIONES17@bolsa y
                       where x.titulo = y.titulo and
                             x.serie  = y.serie  and
                             x.Cod_emisor = y.cemisor);
             Exception
             when others then
                  P_error_salida := sqlerrm||
                  'Actualizando titulo - CODIGO SP';
                    RETURN;       
                                     
            End;
            Begin
                 Update OPERACIONES.TACEMIBV x
                 Set  x.TASA_BASE = 
                      (select Y.TASA_BASE 
                       from EMISIONES17@bolsa y
                       where x.titulo = y.titulo and
                             x.serie  = y.serie  and
                             x.Cod_emisor = y.cemisor);
             Exception
             when others then
                  P_error_salida := sqlerrm||
                  'Actualizando titulo - TASA BASE';
                    RETURN;       
                                     
            End;
            Begin
                 Update OPERACIONES.TACEMIBV x
                 Set  x.SOBRE_TASA = 
                      (select Y.SOBRE_TASA 
                       from EMISIONES17@bolsa y
                       where x.titulo = y.titulo and
                             x.serie  = y.serie  and
                             x.Cod_emisor = y.cemisor);
             Exception
             when others then
                  P_error_salida := sqlerrm||
                  'Actualizando titulo - SOBRE TASA';
                    RETURN;       
                                     
            End;
            
            Begin
                 Update OPERACIONES.TACEMIBV x
                 Set  x.FECHA_EMISION = 
                      (select Y.FECHA_EMISION 
                       from EMISIONES17@bolsa y
                       where x.titulo = y.titulo and
                             x.serie  = y.serie  and
                             x.Cod_emisor = y.cemisor);
             Exception
             when others then
                  P_error_salida := sqlerrm||
                  'Actualizando titulo -  FECHA EMISION';
                    RETURN;       
                                     
            End;
            
            Begin
                 Update OPERACIONES.TACEMIBV x
                 Set  x.MONTO_AUTORIZADO = 
                      (select Y.MONTO_AUTORIZADO 
                       from EMISIONES17@bolsa y
                       where x.titulo = y.titulo and
                             x.serie  = y.serie  and
                             x.Cod_emisor = y.cemisor);
             Exception
             when others then
                  P_error_salida := sqlerrm||
                  'Actualizando titulo - MONTO AUTORIZADO';
                    RETURN;       
                                     
            End;
            
            Begin
                 Update OPERACIONES.TACEMIBV x
                 Set  x.TIPO_ANO = 
                      (select Y.TIPO_ANO 
                       from EMISIONES17@bolsa y
                       where x.titulo = y.titulo and
                             x.serie  = y.serie  and
                             x.Cod_emisor = y.cemisor);
             Exception
             when others then
                  P_error_salida := sqlerrm||
                  'Actualizando titulo - TIPO A�O';
                    RETURN;       
                                     
            End;
            
            Begin
                 Update OPERACIONES.TACEMIBV x
                 Set  x.GRAVADO_EXENTO = 
                      (select Y.GRAVADO_ISR 
                       from EMISIONES17@bolsa y
                       where x.titulo = y.titulo and
                             x.serie  = y.serie  and
                             x.Cod_emisor = y.cemisor);
             Exception
             when others then
                  P_error_salida := sqlerrm||
                  'Actualizando titulo - GRAVADO EXENTO RENTA';
                    RETURN;       
                                     
            End;
            
            Begin
                 Update OPERACIONES.TACEMIBV x
                 Set  x.PUBLICO_PRIVADO = 
                      (select decode(Y.PUBLICO_PRIVADO, 'PU', 'PUBLICO', 'PR', 'PRIVADO')
                       from EMISIONES17@bolsa y
                       where x.titulo = y.titulo and
                             x.serie  = y.serie  and
                             x.Cod_emisor = y.cemisor);
             Exception
             when others then
                  P_error_salida := sqlerrm||
                  'Actualizando titulo - PUBLICO PRIVADO';
                    RETURN;       
                                     
            End; 
            
            Begin
                 Update OPERACIONES.TACEMIBV x
                 Set  x.TIPO_RENTA_TITULO = 
                      (select decode(Y.Tasa_vigente,0, 'V', null, 'V', 'F')
                       from EMISIONES17@bolsa y
                       where x.titulo = y.titulo and
                             x.serie  = y.serie  and
                             x.Cod_emisor = y.cemisor);
             Exception
             when others then
                  P_error_salida := sqlerrm||
                  'Actualizando titulo - TIPO RENTA TITULO';
                    RETURN;       
                                     
            End;   
            
            Begin
                 Update OPERACIONES.BOLETA x
                 Set  x.MONTO_DADO_EN_GARANTIA = 
                      (select NVL(Y.MONTO_DADO_EN_GARANTIA,0)
                       from BOLETA_DE_OPERACIONES17@bolsa y
                       where x.NM_OPERACION = y.NUMERO_OPERACION)
                 WHERE upper(t_mercado) = 'R'
                   and nvl(monto_dado_en_garantia,0) = 0
                   and to_char(x.f_operacion, 'yyyy') >= 2006; 
             Exception
             when others then
                  P_error_salida := sqlerrm||
                  'Actualizando titulo - TIPO RENTA TITULO';
                    RETURN;       
                                     
            End;


--
--
  
  commit;
  

  --  
 /* Begin
    SELECT count(*)
      into x
      From BOLETA_DE_OPERACIONES17@bolsa
     WHERE fecha_operacion
         BETWEEN FechaInicial
             AND FechaFinal and
             to_char(fecha_operacion, 'dd-mm-yyyy') >= '01-01-2005'
    AND  (SUBSTR(CLIENTE_COMPRA,1,2)   = wCodigo
          OR SUBSTR(CLIENTE_VENDE,1,2) = wCodigo);
  --
  End;
  if nvl(x,0) >= 0 then*/        
   dbms_output.put_line('Traslado completado exitosamente: ');--||to_char(x)||' operaciones transferidas'); 
  --end if;

  --
   --


 exception
 when others then
      SAIF2000.ERRPKG.LOG_ERROR;
      p_error_salida:= dbms_utility.format_error_backtrace|| ' Ejecutando transferencia';
      --p_error_salida:= dbms_utility.format_error_STACK|| ' Ejecutando transferencia';            
END TRANSFERENCIA_BOLSA;
/

GRANT EXECUTE ON OPERACIONES.TRANSFERENCIA_BOLSA TO RL_MENU_ADMIN_OPERACIONES;

GRANT EXECUTE ON OPERACIONES.TRANSFERENCIA_BOLSA TO RL_SAIF_CUMPLIMIENTO;

GRANT EXECUTE ON OPERACIONES.TRANSFERENCIA_BOLSA TO RL_SAIF_ISR;

GRANT EXECUTE ON OPERACIONES.TRANSFERENCIA_BOLSA TO RL_SAIF_OPERADOR;
