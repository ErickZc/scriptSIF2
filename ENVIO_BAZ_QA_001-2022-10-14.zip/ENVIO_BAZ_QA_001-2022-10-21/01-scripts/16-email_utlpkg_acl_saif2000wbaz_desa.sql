BEGIN
   dbms_network_acl_admin.create_acl (
        acl         => 'utlpkg_saif2000wbaz_desa.xml',
        description  => 'Normal Access',
        principal    => 'CONNECT',
        is_grant     => TRUE,
        privilege    => 'connect',
        start_date   => NULL,
        end_date     => NULL
     );
   COMMIT;
END;
/
BEGIN
   dbms_network_acl_admin.add_privilege (
        acl         => 'utlpkg_saif2000wbaz_desa.xml',
        principal    => 'SAIF2000',
        is_grant     => TRUE,
        privilege    => 'connect',
        start_date   => NULL,
        end_date     => NULL
     );
   COMMIT;
END;
/
BEGIN
   dbms_network_acl_admin.assign_acl (
        acl         => 'utlpkg_saif2000wbaz_desa.xml',
        host         => '172.29.1.113',
        lower_port   => 25,
        upper_port   => 110
     );
   COMMIT;
END;
