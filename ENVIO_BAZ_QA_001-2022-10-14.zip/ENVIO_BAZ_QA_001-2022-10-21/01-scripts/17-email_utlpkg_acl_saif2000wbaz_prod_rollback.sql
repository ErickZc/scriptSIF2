Begin
   dbms_network_acl_admin.drop_acl (
        acl	     => 'utlpkg_saif2000wbaz_prod.xml'
     );
   commit;
end;
/