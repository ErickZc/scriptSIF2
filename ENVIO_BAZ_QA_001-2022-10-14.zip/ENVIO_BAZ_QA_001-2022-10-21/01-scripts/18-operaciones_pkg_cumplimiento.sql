CREATE OR REPLACE PACKAGE OPERACIONES.pkg_cumplimiento IS
    TYPE rt_concidencia_cadena IS RECORD(
        cod_cliente operaciones.cliente.codcliente%TYPE,
        nombre_cliente operaciones.cliente.nombrecliente%TYPE,
        nombre_campo VARCHAR2(4000),
        valor_campo VARCHAR2(4000),
        relacion_incidencia VARCHAR2(4000),
        estado_cliente VARCHAR2(40)
    );

    TYPE it_concidencias_lista_negra IS TABLE OF operaciones.tamblista_negra%ROWTYPE INDEX BY PLS_INTEGER;
    TYPE it_concidencias_cadena IS TABLE OF rt_concidencia_cadena INDEX BY PLS_INTEGER;

    en_error_validando_xml CONSTANT NUMBER := -31011;
    e_error_validando_xml EXCEPTION;
    PRAGMA EXCEPTION_INIT(e_error_validando_xml, -31011);

    en_empty_or_null_blob CONSTANT NUMBER := -20001;
    e_empty_or_null_blob EXCEPTION;
    PRAGMA EXCEPTION_INIT(e_empty_or_null_blob, -20001);

    en_file_is_not_in_table CONSTANT NUMBER := -20002;
    e_file_is_not_in_table EXCEPTION;
    PRAGMA EXCEPTION_INIT(e_file_is_not_in_table, -20002);

    en_non_schema_xml_document CONSTANT NUMBER := '-19030';
    e_not_schema_xml_document EXCEPTION;
    PRAGMA EXCEPTION_INIT(e_not_schema_xml_document, -19030);

    FUNCTION busqueda_en_datos_clientes(p_compania IN VARCHAR2,
                                    p_cadena_a_buscar IN VARCHAR2
                                    ) RETURN it_concidencias_cadena;

    FUNCTION cadena_de_busqueda_valida(p_cadena_busqueda VARCHAR2
                                        ) RETURN BOOLEAN;

    PROCEDURE procesa_xml_lista_negra(p_compania IN VARCHAR2,
                                        p_xml_document IN OUT NOCOPY BLOB);

    FUNCTION error_registro_lista(prt_lista IN operaciones.tamblista_negra%ROWTYPE
                                    ) RETURN VARCHAR2;

    PROCEDURE extrae_y_procesa_blob(p_id IN INTEGER);

    FUNCTION coincidencias_lista_negra(p_compania IN VARCHAR2,
                                        p_nombre  IN VARCHAR2,
                                        p_cod_cliente IN VARCHAR2,
                                        p_relacion_cliente IN VARCHAR2,
                                        p_origen_coincidencia IN VARCHAR2)
        RETURN INTEGER;

    PROCEDURE log_cliente_fatca(p_compania IN VARCHAR2,
                                        p_nombre  IN VARCHAR2,
                                        p_cod_cliente IN VARCHAR2,
                                        p_relacion_cliente IN VARCHAR2,
                                        p_cod_pais IN VARCHAR2,
                                        p_tipo_indicio IN VARCHAR2);
    PROCEDURE log_referencia_coinci_ln(p_cod_cia IN VARCHAR2,
                                            p_cod_cliente IN VARCHAR2,
                                            p_origen_coincidencia IN VARCHAR2);
    PROCEDURE log_beneficiario_coinci_ln(p_cod_cia IN VARCHAR2,
                                            p_cod_cliente IN VARCHAR2,
                                            p_origen_coincidencia IN VARCHAR2);
    PROCEDURE log_autorizado_coinci_ln(p_cod_cia IN VARCHAR2,
                                            p_cod_cliente IN VARCHAR2,
                                            p_origen_coincidencia IN VARCHAR2);
    PROCEDURE log_accionista_coinci_ln(p_cod_cia IN VARCHAR2,
                                            p_cod_cliente IN VARCHAR2,
                                            p_origen_coincidencia IN VARCHAR2);
    PROCEDURE log_junta_coinci_ln(p_cod_cia IN VARCHAR2,
                                            p_cod_cliente IN VARCHAR2,
                                            p_origen_coincidencia IN VARCHAR2);
    PROCEDURE log_cliente_coinci_ln(p_cod_cia IN VARCHAR2,
                                            p_cod_cliente IN VARCHAR2,
                                            p_origen_coincidencia IN VARCHAR2);
    PROCEDURE log_accionista_indicio_fatca(p_cod_cia IN VARCHAR2,
                                           p_cod_cliente IN VARCHAR2);
    PROCEDURE log_junta_indicio_fatca(p_cod_cia IN VARCHAR2,
                                           p_cod_cliente IN VARCHAR2);
    PROCEDURE log_autorizado_indicio_fatca(p_cod_cia IN VARCHAR2,
                                           p_cod_cliente IN VARCHAR2);
    PROCEDURE log_cliente_indicio_fatca(p_cod_cia IN VARCHAR2,
                                         p_cod_cliente IN VARCHAR2);
END pkg_cumplimiento;
/

GRANT EXECUTE ON OPERACIONES.PKG_CUMPLIMIENTO TO PUBLIC;

GRANT EXECUTE ON OPERACIONES.PKG_CUMPLIMIENTO TO RL_MENU_ADMIN_OPERACIONES;

GRANT EXECUTE ON OPERACIONES.PKG_CUMPLIMIENTO TO RL_SAIF_CORREDOR;

GRANT EXECUTE ON OPERACIONES.PKG_CUMPLIMIENTO TO RL_SAIF_CUMPLIMIENTO;

GRANT EXECUTE ON OPERACIONES.PKG_CUMPLIMIENTO TO RL_SAIF_GERENTE;

CREATE OR REPLACE PACKAGE BODY OPERACIONES.pkg_cumplimiento IS
    FUNCTION busqueda_en_datos_clientes(p_compania IN VARCHAR2,
                                        p_cadena_a_buscar IN VARCHAR2
                                        )
        RETURN it_concidencias_cadena
    IS
        v_cadena_a_buscar VARCHAR2(4000)
            := saif2000.pkg_saif_reglas_negocio.quita_vocales_especiales(p_cadena_a_buscar);

        vit_matchs_found it_concidencias_cadena;

        PROCEDURE inserta_record(p_cod_cliente IN VARCHAR,
                                    p_nombre_cliente IN VARCHAR2,
                                    p_nombre_campo IN VARCHAR2,
                                    p_valor_campo IN VARCHAR2,
                                    p_relacion_incidencia IN VARCHAR2,
                                    p_estado_cliente IN VARCHAR2)
        IS
            v_index PLS_INTEGER;

            FUNCTION record_to_insert RETURN rt_concidencia_cadena
            IS
                vrt_match_found rt_concidencia_cadena;
            BEGIN
                vrt_match_found.cod_cliente := p_cod_cliente;
                vrt_match_found.nombre_cliente := p_nombre_cliente;
                vrt_match_found.nombre_campo := p_nombre_campo;
                vrt_match_found.valor_campo := p_valor_campo;
                vrt_match_found.relacion_incidencia := p_relacion_incidencia;
                vrt_match_found.estado_cliente := p_estado_cliente;

                RETURN vrt_match_found;
            END record_to_insert;
        BEGIN
            v_index := vit_matchs_found.COUNT + 1;
            vit_matchs_found(v_index) := record_to_insert;
        END;

        -------------------------------------------------------

        FUNCTION coincide_con_busqueda(p_valor_campo IN VARCHAR2)
            RETURN BOOLEAN
        IS
            v_valor_campo VARCHAR2(4000)
                :=  saif2000.pkg_saif_reglas_negocio.quita_vocales_especiales(p_valor_campo);
        BEGIN
            IF REGEXP_LIKE(v_valor_campo, v_cadena_a_buscar, 'i')
            THEN
                RETURN TRUE;
            ELSE
                RETURN FALSE;
            END IF;
        END coincide_con_busqueda;

        -------------------------------------------------------

        PROCEDURE procesa_clientes
        IS
            TYPE nt_clientes IS TABLE OF operaciones.cliente%ROWTYPE;
            vnt_clientes nt_clientes;

            PROCEDURE clientes_to_nested_table IS
            BEGIN
                SELECT *
                BULK COLLECT INTO vnt_clientes
                FROM operaciones.cliente
                WHERE cod_cia = p_compania;
            END clientes_to_nested_table;

            PROCEDURE procesa_clientes_en_lote
            IS
                v_row PLS_INTEGER;

                FUNCTION descri_estado_cliente(p_estado_cliente IN VARCHAR2) RETURN VARCHAR2
                IS
                BEGIN
                    RETURN  CASE
                                WHEN p_estado_cliente = 'A' THEN 'Activo'
                                WHEN p_estado_cliente = 'I' THEN 'Inactivo'
                            ELSE
                                NULL
                            END;
                END descri_estado_cliente;

                /*a_ representa Analizar un campo para verificar si la cadena de
                busqueda se encuentra en ese campo ejemplo: a_campo_a_analizar */
                PROCEDURE a_nombrecliente(p_index IN PLS_INTEGER) IS
                BEGIN
                    IF coincide_con_busqueda(p_valor_campo => vnt_clientes(p_index).nombrecliente)
                    THEN
                        inserta_record(p_cod_cliente => vnt_clientes(p_index).codcliente,
                                    p_nombre_cliente => vnt_clientes(p_index).nombrecliente,
                                    p_nombre_campo => 'Nombre Cliente',
                                    p_valor_campo => vnt_clientes(p_index).nombrecliente,
                                    p_relacion_incidencia => 'Cliente',
                                    p_estado_cliente => descri_estado_cliente(vnt_clientes(p_index).estado_cliente));
                    END IF;
                END a_nombrecliente;
                -----------------------------------------------------
                PROCEDURE a_nombre_conyuge(p_index IN PLS_INTEGER) IS
                BEGIN
                    IF coincide_con_busqueda(p_valor_campo => vnt_clientes(p_index).nombre_conyuge)
                    THEN
                        inserta_record(p_cod_cliente => vnt_clientes(p_index).codcliente,
                                    p_nombre_cliente => vnt_clientes(p_index).nombrecliente,
                                    p_nombre_campo => 'Nombre Conyuge',
                                    p_valor_campo => vnt_clientes(p_index).nombre_conyuge,
                                    p_relacion_incidencia => 'Conyuge Cliente',
                                    p_estado_cliente => descri_estado_cliente(vnt_clientes(p_index).estado_cliente));
                    END IF;
                END a_nombre_conyuge;
                ---------------------------------------------------------
                PROCEDURE a_abreviatura_empresa(p_index IN PLS_INTEGER) IS
                BEGIN
                    IF coincide_con_busqueda(p_valor_campo => vnt_clientes(p_index).abreviatura_empresa)
                    THEN
                        inserta_record(p_cod_cliente => vnt_clientes(p_index).codcliente,
                                    p_nombre_cliente => vnt_clientes(p_index).nombrecliente,
                                    p_nombre_campo => 'Abreviatura Empresa',
                                    p_valor_campo => vnt_clientes(p_index).abreviatura_empresa,
                                    p_relacion_incidencia => 'Abreviatura Cliente',
                                    p_estado_cliente => descri_estado_cliente(vnt_clientes(p_index).estado_cliente));
                    END IF;
                END a_abreviatura_empresa;
                ---------------------------------------------------------
                PROCEDURE a_notario_crea_escritura(p_index IN PLS_INTEGER) IS
                BEGIN
                    IF coincide_con_busqueda(p_valor_campo => vnt_clientes(p_index).notario_crea_escritura)
                    THEN
                        inserta_record(p_cod_cliente => vnt_clientes(p_index).codcliente,
                                    p_nombre_cliente => vnt_clientes(p_index).nombrecliente,
                                    p_nombre_campo => 'Notario Crea Escritura',
                                    p_valor_campo => vnt_clientes(p_index).notario_crea_escritura,
                                    p_relacion_incidencia => 'Notario Escritura Cliente',
                                    p_estado_cliente => descri_estado_cliente(vnt_clientes(p_index).estado_cliente));
                    END IF;
                END a_notario_crea_escritura;
                ---------------------------------------------------------
                PROCEDURE a_notario_modifica_escritura(p_index IN PLS_INTEGER) IS
                BEGIN
                    IF coincide_con_busqueda(p_valor_campo => vnt_clientes(p_index).notario_crea_escritura)
                    THEN
                        inserta_record(p_cod_cliente => vnt_clientes(p_index).codcliente,
                                    p_nombre_cliente => vnt_clientes(p_index).nombrecliente,
                                    p_nombre_campo => 'Notario Modifica Escritura',
                                    p_valor_campo => vnt_clientes(p_index).notario_modifica_escritura,
                                    p_relacion_incidencia => 'Notario Escritura Cliente',
                                    p_estado_cliente => descri_estado_cliente(vnt_clientes(p_index).estado_cliente));
                    END IF;
                END a_notario_modifica_escritura;
                ---------------------------------------------------------
                PROCEDURE a_nombre_representante_legal(p_index IN PLS_INTEGER) IS
                BEGIN
                    IF coincide_con_busqueda(p_valor_campo => vnt_clientes(p_index).nombre_representante_legal)
                    THEN
                        inserta_record(p_cod_cliente => vnt_clientes(p_index).codcliente,
                                    p_nombre_cliente => vnt_clientes(p_index).nombrecliente,
                                    p_nombre_campo => 'Nombre Representante Legal',
                                    p_valor_campo => vnt_clientes(p_index).nombre_representante_legal,
                                    p_relacion_incidencia => 'Representante Legal',
                                    p_estado_cliente => descri_estado_cliente(vnt_clientes(p_index).estado_cliente));
                    END IF;
                END a_nombre_representante_legal;
                ---------------------------------------------------------
                PROCEDURE a_lugar_trabajo_rep_legal(p_index IN PLS_INTEGER) IS
                BEGIN
                    IF coincide_con_busqueda(p_valor_campo => vnt_clientes(p_index).lugar_trabajo_rep_legal)
                    THEN
                        inserta_record(p_cod_cliente => vnt_clientes(p_index).codcliente,
                                    p_nombre_cliente => vnt_clientes(p_index).nombrecliente,
                                    p_nombre_campo => 'Lugar Trabajo Representante Legal',
                                    p_valor_campo => vnt_clientes(p_index).lugar_trabajo_rep_legal,
                                    p_relacion_incidencia => 'Representante Legal',
                                    p_estado_cliente => descri_estado_cliente(vnt_clientes(p_index).estado_cliente));
                    END IF;
                END a_lugar_trabajo_rep_legal;
                ---------------------------------------------------------
                PROCEDURE a_nombre_rela_rep_legal(p_index IN PLS_INTEGER) IS
                BEGIN
                    IF coincide_con_busqueda(p_valor_campo => vnt_clientes(p_index).nombre_rela_rep_legal)
                    THEN
                        inserta_record(p_cod_cliente => vnt_clientes(p_index).codcliente,
                                    p_nombre_cliente => vnt_clientes(p_index).nombrecliente,
                                    p_nombre_campo => 'Relacionado del Representante Legal',
                                    p_valor_campo => vnt_clientes(p_index).nombre_rela_rep_legal,
                                    p_relacion_incidencia => 'Representante Legal',
                                    p_estado_cliente => descri_estado_cliente(vnt_clientes(p_index).estado_cliente));
                    END IF;
                END a_nombre_rela_rep_legal;
                ---------------------------------------------------------
                PROCEDURE a_lugartrabajo(p_index IN PLS_INTEGER) IS
                BEGIN
                    IF coincide_con_busqueda(p_valor_campo => vnt_clientes(p_index).lugartrabajo)
                    THEN
                        inserta_record(p_cod_cliente => vnt_clientes(p_index).codcliente,
                                    p_nombre_cliente => vnt_clientes(p_index).nombrecliente,
                                    p_nombre_campo => 'Lugar Trabajo Cliente',
                                    p_valor_campo => vnt_clientes(p_index).lugartrabajo,
                                    p_relacion_incidencia => 'Cliente',
                                    p_estado_cliente => descri_estado_cliente(vnt_clientes(p_index).estado_cliente));
                    END IF;
                END a_lugartrabajo;
                ---------------------------------------------------------
                PROCEDURE a_nombre_persona_dependencia(p_index IN PLS_INTEGER) IS
                BEGIN
                    IF coincide_con_busqueda(p_valor_campo => vnt_clientes(p_index).nombre_persona_dependencia)
                    THEN
                        inserta_record(p_cod_cliente => vnt_clientes(p_index).codcliente,
                                    p_nombre_cliente => vnt_clientes(p_index).nombrecliente,
                                    p_nombre_campo => 'Nombre Dependencia',
                                    p_valor_campo => vnt_clientes(p_index).nombre_persona_dependencia,
                                    p_relacion_incidencia => 'Cliente',
                                    p_estado_cliente => descri_estado_cliente(vnt_clientes(p_index).estado_cliente));
                    END IF;
                END a_nombre_persona_dependencia;

                ---------------------------------------------------------
                PROCEDURE a_nombre_rela(p_index IN PLS_INTEGER) IS
                BEGIN
                    IF coincide_con_busqueda(p_valor_campo => vnt_clientes(p_index).nombre_rela)
                    THEN
                        inserta_record(p_cod_cliente => vnt_clientes(p_index).codcliente,
                                    p_nombre_cliente => vnt_clientes(p_index).nombrecliente,
                                    p_nombre_campo => 'Relacionado Cliente',
                                    p_valor_campo => vnt_clientes(p_index).nombre_rela,
                                    p_relacion_incidencia => 'Cliente',
                                    p_estado_cliente => descri_estado_cliente(vnt_clientes(p_index).estado_cliente));
                    END IF;
                END a_nombre_rela;
            BEGIN
                v_row := vnt_clientes.FIRST;

                WHILE(v_row IS NOT NULL)
                LOOP
                    a_nombrecliente(v_row);
                    a_nombre_conyuge(v_row);
                    a_abreviatura_empresa(v_row);
                    a_notario_crea_escritura(v_row);
                    a_notario_modifica_escritura(v_row);
                    a_nombre_representante_legal(v_row);
                    a_lugar_trabajo_rep_legal(v_row);
                    a_nombre_rela_rep_legal(v_row);
                    a_lugartrabajo(v_row);
                    a_nombre_persona_dependencia(v_row);
                    a_nombre_rela(v_row);

                    v_row := vnt_clientes.NEXT(v_row);
                END LOOP;
            END procesa_clientes_en_lote;
         BEGIN
            clientes_to_nested_table;
            procesa_clientes_en_lote;
         END procesa_clientes;

         -----------------------

         PROCEDURE procesa_referencias
         IS
            TYPE rt_referencias IS RECORD(
                codcliente operaciones.cliente.codcliente%TYPE,
                nombrecliente operaciones.cliente.nombrecliente%TYPE,
                nombre_referencia operaciones.tambrefxcl.nombre_referencia%TYPE,
                estado_cliente VARCHAR2(30)
            );

            TYPE nt_referencias IS TABLE OF rt_referencias;
            vnt_referencias nt_referencias;

            PROCEDURE referencias_to_nested_table IS
            BEGIN
                SELECT referencias.codcliente,
                    clientes.nombrecliente,
                    referencias.nombre_referencia,
                    CASE clientes.estado_cliente
                        WHEN 'A' THEN 'Activo'
                        WHEN 'I' THEN 'Inactivo'
                    END estado_cliente
                BULK COLLECT INTO vnt_referencias
                FROM operaciones.tambrefxcl referencias
                INNER JOIN operaciones.cliente clientes ON
                    clientes.cod_cia = referencias.cod_cia AND
                    clientes.codcliente = referencias.codcliente
                WHERE referencias.cod_cia = p_compania;
            END referencias_to_nested_table;

            PROCEDURE procesa_referencias_en_lote
            IS
                v_row PLS_INTEGER;

                /*a_ representa Analizar un campo para verificar si la cadena de
                busqueda se encuentra en ese campo ejemplo: a_campo_a_analizar */
                PROCEDURE a_nombre_referencia(p_index IN PLS_INTEGER) IS
                BEGIN
                    IF coincide_con_busqueda(p_valor_campo => vnt_referencias(p_index).nombre_referencia)
                    THEN
                        inserta_record(p_cod_cliente => vnt_referencias(p_index).codcliente,
                                    p_nombre_cliente => vnt_referencias(p_index).nombrecliente,
                                    p_nombre_campo => 'Nombre Referencia',
                                    p_valor_campo => vnt_referencias(p_index).nombre_referencia,
                                    p_relacion_incidencia => 'Referencia',
                                    p_estado_cliente => vnt_referencias(p_index).estado_cliente);
                    END IF;
                END a_nombre_referencia;
            BEGIN
                v_row := vnt_referencias.FIRST;

                WHILE(v_row IS NOT NULL)
                LOOP
                    a_nombre_referencia(v_row);

                    v_row := vnt_referencias.NEXT(v_row);
                END LOOP;
            END procesa_referencias_en_lote;
         BEGIN
            referencias_to_nested_table;
            procesa_referencias_en_lote;
         END procesa_referencias;

         -----------------------------

         PROCEDURE procesa_beneficiarios
         IS
            TYPE rt_beneficiario IS RECORD(
                codcliente operaciones.cliente.codcliente%TYPE,
                nombrecliente operaciones.cliente.nombrecliente%TYPE,
                nombre_beneficiario VARCHAR2(1000),
                estado_cliente VARCHAR2(30)
            );

            TYPE nt_beneficiarios IS TABLE OF rt_beneficiario;
            vnt_beneficiarios nt_beneficiarios;

            PROCEDURE beneficiarios_to_nested_table IS
            BEGIN
                SELECT beneficiarios.codcliente,
                    clientes.nombrecliente,
                    beneficiarios.nombenef||' '||
                        beneficiarios.apebenef AS nombre_beneficiario,
                    CASE clientes.estado_cliente
                        WHEN 'A' THEN 'Activo'
                        WHEN 'I' THEN 'Inactivo'
                    END estado_cliente
                BULK COLLECT INTO vnt_beneficiarios
                FROM operaciones.beneficiario beneficiarios
                INNER JOIN operaciones.cliente clientes ON
                    clientes.cod_cia = beneficiarios.cod_cia AND
                    clientes.codcliente = beneficiarios.codcliente
                WHERE beneficiarios.cod_cia = p_compania;
            END beneficiarios_to_nested_table;

            PROCEDURE procesa_beneficiarios_en_lote
            IS
                v_row PLS_INTEGER;

                /*a_ representa Analizar un campo para verificar si la cadena de
                busqueda se encuentra en ese campo ejemplo: a_campo_a_analizar */
                PROCEDURE a_nombre_beneficiario(p_index IN PLS_INTEGER) IS
                BEGIN
                    IF coincide_con_busqueda(p_valor_campo => vnt_beneficiarios(p_index).nombre_beneficiario)
                    THEN
                        inserta_record(p_cod_cliente => vnt_beneficiarios(p_index).codcliente,
                                    p_nombre_cliente => vnt_beneficiarios(p_index).nombrecliente,
                                    p_nombre_campo => 'Nombre Beneficiario',
                                    p_valor_campo => vnt_beneficiarios(p_index).nombre_beneficiario,
                                    p_relacion_incidencia => 'Beneficiario',
                                    p_estado_cliente => vnt_beneficiarios(p_index).estado_cliente);
                    END IF;
                END a_nombre_beneficiario;
            BEGIN
                v_row := vnt_beneficiarios.FIRST;

                WHILE(v_row IS NOT NULL)
                LOOP
                    a_nombre_beneficiario(v_row);
                    v_row := vnt_beneficiarios.NEXT(v_row);
                END LOOP;
            END procesa_beneficiarios_en_lote;
         BEGIN
            beneficiarios_to_nested_table;
            procesa_beneficiarios_en_lote;
         END procesa_beneficiarios;

         -----------------------------

         PROCEDURE procesa_personas_autorizadas
         IS
            TYPE rt_persona_auto IS RECORD(
                codcliente operaciones.cliente.codcliente%TYPE,
                nombrecliente operaciones.cliente.nombrecliente%TYPE,
                nombre_persona_auto VARCHAR2(1000),
                estado_cliente VARCHAR2(30)
            );

            TYPE nt_personas_auto IS TABLE OF rt_persona_auto;
            vnt_personas_auto nt_personas_auto;

            PROCEDURE pautorizadas_to_nested_table IS
            BEGIN
                SELECT persona_autorizada.codcliente,
                    clientes.nombrecliente,
                    persona_autorizada.nompersona||' '||
                        persona_autorizada.apepersona AS nombre_persona_auto,
                    CASE clientes.estado_cliente
                        WHEN 'A' THEN 'Activo'
                        WHEN 'I' THEN 'Inactivo'
                    END estado_cliente
                BULK COLLECT INTO vnt_personas_auto
                FROM operaciones.pautorizada persona_autorizada
                INNER JOIN operaciones.cliente clientes ON
                    clientes.cod_cia = persona_autorizada.cod_cia AND
                    clientes.codcliente = persona_autorizada.codcliente
                WHERE persona_autorizada.cod_cia = p_compania;
            END pautorizadas_to_nested_table;

            PROCEDURE procesa_pautorizadas_en_lote
            IS
                v_row PLS_INTEGER;

                /*a_ representa Analizar un campo para verificar si la cadena de
                busqueda se encuentra en ese campo ejemplo: a_campo_a_analizar */
                PROCEDURE a_nombre_persona_auto(p_index IN PLS_INTEGER) IS
                BEGIN
                    IF coincide_con_busqueda(p_valor_campo => vnt_personas_auto(p_index).nombre_persona_auto)
                    THEN
                        inserta_record(p_cod_cliente => vnt_personas_auto(p_index).codcliente,
                                    p_nombre_cliente => vnt_personas_auto(p_index).nombrecliente,
                                    p_nombre_campo => 'Nombre Persona Autorizada',
                                    p_valor_campo => vnt_personas_auto(p_index).nombre_persona_auto,
                                    p_relacion_incidencia => 'Persona Autorizada',
                                    p_estado_cliente => vnt_personas_auto(p_index).estado_cliente);
                    END IF;
                END a_nombre_persona_auto;
            BEGIN
                v_row := vnt_personas_auto.FIRST;

                WHILE(v_row IS NOT NULL)
                LOOP
                    a_nombre_persona_auto(v_row);

                    v_row := vnt_personas_auto.NEXT(v_row);
                END LOOP;
            END procesa_pautorizadas_en_lote;
         BEGIN
            pautorizadas_to_nested_table;
            procesa_pautorizadas_en_lote;
         END procesa_personas_autorizadas;

         -----------------------------

         PROCEDURE procesa_personas_jd
         IS
            TYPE rt_persona_jd IS RECORD(
                codcliente operaciones.cliente.codcliente%TYPE,
                nombrecliente operaciones.cliente.nombrecliente%TYPE,
                nombre_persona_jd VARCHAR2(1000),
                estado_cliente VARCHAR2(30)
            );

            TYPE nt_personas_jd IS TABLE OF rt_persona_jd;
            vnt_personas_jd nt_personas_jd;

            PROCEDURE personas_jd_to_nested_table IS
            BEGIN
                SELECT persona_jd.codcliente,
                    clientes.nombrecliente,
                    persona_jd.primer_nombre_jd||' '||
                        persona_jd.segundo_nombre_jd||' '||
                        persona_jd.primer_apellido_jd||' '||
                        persona_jd.segundo_apellido_jd||
                        CASE
                            WHEN persona_jd.apellido_casada_jd IS NULL
                            THEN NULL
                            WHEN persona_jd.apellido_casada_jd IS NOT NULL
                            THEN ' '||persona_jd.apellido_casada_jd
                        END AS  nombre_persona_jd,
                    CASE clientes.estado_cliente
                        WHEN 'A' THEN 'Activo'
                        WHEN 'I' THEN 'Inactivo'
                    END estado_cliente
                BULK COLLECT INTO vnt_personas_jd
                FROM operaciones.tambjdxcl persona_jd
                INNER JOIN operaciones.cliente clientes ON
                    clientes.cod_cia = persona_jd.cod_cia AND
                    clientes.codcliente = persona_jd.codcliente
                WHERE persona_jd.cod_cia = p_compania;
            END personas_jd_to_nested_table;

            PROCEDURE procesa_personas_jd_en_lote
            IS
                v_row PLS_INTEGER;

                /*a_ representa Analizar un campo para verificar si la cadena de
                busqueda se encuentra en ese campo ejemplo: a_campo_a_analizar */
                PROCEDURE a_nombre_persona_jd(p_index IN PLS_INTEGER) IS
                BEGIN
                    IF coincide_con_busqueda(p_valor_campo => vnt_personas_jd(p_index).nombre_persona_jd)
                    THEN
                        inserta_record(p_cod_cliente => vnt_personas_jd(p_index).codcliente,
                                    p_nombre_cliente => vnt_personas_jd(p_index).nombrecliente,
                                    p_nombre_campo => 'Nombre Persona Junta Directiva',
                                    p_valor_campo => vnt_personas_jd(p_index).nombre_persona_jd,
                                    p_relacion_incidencia => 'Junta Directiva',
                                    p_estado_cliente => vnt_personas_jd(p_index).estado_cliente);
                    END IF;
                END a_nombre_persona_jd;
            BEGIN
                v_row := vnt_personas_jd.FIRST;

                WHILE(v_row IS NOT NULL)
                LOOP
                    a_nombre_persona_jd(v_row);

                    v_row := vnt_personas_jd.NEXT(v_row);
                END LOOP;
            END procesa_personas_jd_en_lote;
         BEGIN
            personas_jd_to_nested_table;
            procesa_personas_jd_en_lote;
         END procesa_personas_jd;

         -----------------------

         PROCEDURE procesa_accionistas
         IS
            TYPE rt_accionista IS RECORD(
                codcliente operaciones.cliente.codcliente%TYPE,
                nombrecliente operaciones.cliente.nombrecliente%TYPE,
                nombre_accionista operaciones.tambacclfatca.nombre_accionista%TYPE,
                estado_cliente VARCHAR2(30)
            );

            TYPE nt_accionistas IS TABLE OF rt_accionista;
            vnt_accionistas nt_accionistas;

            PROCEDURE accionistas_to_nested_table IS
            BEGIN
                SELECT accionistas.codcliente,
                    clientes.nombrecliente,
                    accionistas.nombre_accionista,
                    CASE clientes.estado_cliente
                        WHEN 'A' THEN 'Activo'
                        WHEN 'I' THEN 'Inactivo'
                    END estado_cliente
                BULK COLLECT INTO vnt_accionistas
                FROM operaciones.tambacclfatca accionistas
                INNER JOIN operaciones.cliente clientes ON
                    clientes.cod_cia = accionistas.cod_cia AND
                    clientes.codcliente = accionistas.codcliente
                WHERE accionistas.cod_cia = p_compania;
            END accionistas_to_nested_table;

            PROCEDURE procesa_accionistas_en_lote
            IS
                v_row PLS_INTEGER;

                /*a_ representa Analizar un campo para verificar si la cadena de
                busqueda se encuentra en ese campo ejemplo: a_campo_a_analizar */
                PROCEDURE a_nombre_referencia(p_index IN PLS_INTEGER) IS
                BEGIN
                    IF coincide_con_busqueda(p_valor_campo => vnt_accionistas(p_index).nombre_accionista)
                    THEN
                        inserta_record(p_cod_cliente => vnt_accionistas(p_index).codcliente,
                                    p_nombre_cliente => vnt_accionistas(p_index).nombrecliente,
                                    p_nombre_campo => 'Nombre Accionista',
                                    p_valor_campo => vnt_accionistas(p_index).nombre_accionista,
                                    p_relacion_incidencia => 'Accionistas',
                                    p_estado_cliente => vnt_accionistas(p_index).estado_cliente);
                    END IF;
                END a_nombre_referencia;
            BEGIN
                v_row := vnt_accionistas.FIRST;

                WHILE(v_row IS NOT NULL)
                LOOP
                    a_nombre_referencia(v_row);

                    v_row := vnt_accionistas.NEXT(v_row);
                END LOOP;
            END procesa_accionistas_en_lote;
         BEGIN
            accionistas_to_nested_table;
            procesa_accionistas_en_lote;
         END procesa_accionistas;
    BEGIN
        procesa_clientes;
        procesa_referencias;
        procesa_beneficiarios;
        procesa_personas_autorizadas;
        procesa_personas_jd;
        procesa_accionistas;

        RETURN vit_matchs_found;
    EXCEPTION
        WHEN OTHERS THEN
            saif2000.errpkg.log_error;
            RAISE;
    END busqueda_en_datos_clientes;

    FUNCTION cadena_de_busqueda_valida(p_cadena_busqueda VARCHAR2)
        RETURN BOOLEAN
    IS
    BEGIN
        RETURN NVL(REGEXP_LIKE(p_cadena_busqueda, '^[[:alnum:][:blank:]]+$'), FALSE);
    END cadena_de_busqueda_valida;

    FUNCTION error_registro_lista(prt_lista IN operaciones.tamblista_negra%ROWTYPE)
        RETURN VARCHAR2
    IS
        v_error VARCHAR2(32767);

        PROCEDURE valida_campo_nulo(p_campo IN VARCHAR2,p_nombre_campo IN VARCHAR2)
        IS
            FUNCTION error_campo_nulo RETURN VARCHAR
            IS
            BEGIN
                IF p_campo IS NULL
                THEN
                    RETURN 'Campo '||p_nombre_campo||' no puede ser nulo-';
                ELSE
                    RETURN NULL;
                END IF;
            END error_campo_nulo;
        BEGIN
            v_error := v_error||error_campo_nulo;
        END valida_campo_nulo;

        PROCEDURE valida_tipo_persona
        IS
            v_campos_pnatural_llenos BOOLEAN;
        BEGIN
            IF UPPER(prt_lista.tipo_persona) IN ('NATURAL', 'JURIDICA')
            THEN
                IF UPPER(prt_lista.tipo_persona) = 'JURIDICA'
                THEN
                    v_campos_pnatural_llenos := prt_lista.primer_nombre IS NOT NULL OR
                        prt_lista.segundo_nombre IS NOT NULL OR
                        prt_lista.primer_apellido IS NOT NULL OR
                        prt_lista.segundo_apellido IS NOT NULL OR
                        prt_lista.apellido_casada IS NOT NULL;

                    IF v_campos_pnatural_llenos
                    THEN
                        v_error
                            := v_error||'Si la persona es Juridica no puede tener los'
                                ||' siguientes: campos primer y segundo nombre, '
                                ||' primer, segundo y apellido de casada-';
                    ELSE
                        NULL;
                    END IF;
                END IF;
            ELSE
                v_error := v_error||'Valor para campo tipo_persona erroneo debe'||
                                     ' de ser NATURAL o JURIDICA-';
            END IF;
        END valida_tipo_persona;
    BEGIN

        valida_campo_nulo(p_campo => prt_lista.nombre_persona,
                            p_nombre_campo => 'Nombre');

        valida_campo_nulo(p_campo => prt_lista.tipo_persona,
                            p_nombre_campo => 'Tipo Persona');

        valida_campo_nulo(p_campo => prt_lista.categoria,
                            p_nombre_campo => 'Categoria');

        valida_campo_nulo(p_campo => prt_lista.motivo,
                            p_nombre_campo => 'Motivo');

        valida_campo_nulo(p_campo => prt_lista.descripcion,
                            p_nombre_campo => 'Descripcion');

        IF prt_lista.tipo_persona IS NOT NULL
        THEN
            valida_tipo_persona;
        END IF;

        RETURN v_error;
    END error_registro_lista;

    PROCEDURE procesa_xml_lista_negra(p_compania IN VARCHAR2,
                                        p_xml_document IN OUT NOCOPY BLOB)
    IS
        vot_document XMLTYPE;

        PROCEDURE crea_xmltype
        IS
            v_xml_clob CLOB := saif2000.pkg_utilidades.blob_to_clob(p_blob => p_xml_document);

            PROCEDURE inserta_xsi
            IS
                v_xmlns_xsi VARCHAR2(200) := '<listas_negra xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="lista_negra.xsd">';
                v_cadena_a_remplazar VARCHAR2(100) := '<listas_negra>';
            BEGIN
                v_xml_clob := REGEXP_REPLACE(v_xml_clob, v_cadena_a_remplazar , v_xmlns_xsi ,1 ,1);
            END inserta_xsi;

        BEGIN
            inserta_xsi;
            vot_document := XMLTYPE(v_xml_clob);
        END crea_xmltype;

        PROCEDURE extrae_registros
        IS
            CURSOR c_registros_xml IS
                SELECT ROWNUM AS numero_registro,
                    EXTRACTVALUE(lista_negra.COLUMN_VALUE, '/registro_lista/nombre/text()') AS nombre,
                    EXTRACTVALUE(lista_negra.COLUMN_VALUE, '/registro_lista/primer_nombre/text()') AS primer_nombre,
                    EXTRACTVALUE(lista_negra.COLUMN_VALUE, '/registro_lista/segundo_nombre/text()') AS segundo_nombre,
                    EXTRACTVALUE(lista_negra.COLUMN_VALUE, '/registro_lista/primer_apellido/text()') AS primer_apellido,
                    EXTRACTVALUE(lista_negra.COLUMN_VALUE, '/registro_lista/segundo_apellido/text()') AS segundo_apellido,
                    EXTRACTVALUE(lista_negra.COLUMN_VALUE, '/registro_lista/apellido_casada/text()') AS apellido_casada,
                    EXTRACTVALUE(lista_negra.COLUMN_VALUE, '/registro_lista/tipo_persona/text()') AS tipo_persona,
                    EXTRACTVALUE(lista_negra.COLUMN_VALUE, '/registro_lista/tipo_documento/text()') AS tipo_documento,
                    EXTRACTVALUE(lista_negra.COLUMN_VALUE, '/registro_lista/numero_documento/text()') AS numero_documento,
                    EXTRACTVALUE(lista_negra.COLUMN_VALUE, '/registro_lista/nacionalidad/text()') AS nacionalidad,
                    EXTRACTVALUE(lista_negra.COLUMN_VALUE, '/registro_lista/categoria/text()') AS categoria,
                    EXTRACTVALUE(lista_negra.COLUMN_VALUE, '/registro_lista/motivo/text()') AS motivo,
                    EXTRACTVALUE(lista_negra.COLUMN_VALUE, '/registro_lista/descripcion/text()') AS descripcion
                FROM TABLE(XMLSEQUENCE(EXTRACT(vot_document,'/listas_negra/registro_lista'))) lista_negra;

            PROCEDURE procesa_registro(prt_lista_negra IN c_registros_xml%ROWTYPE)
            IS
                vrt_registro_a_insertar operaciones.tamblista_negra%ROWTYPE;
                v_error_registro VARCHAR2(32767);

                FUNCTION registro_tabla
                    RETURN operaciones.tamblista_negra%ROWTYPE
                IS
                    vrt_tabla operaciones.tamblista_negra%ROWTYPE;

                    FUNCTION texto_formateado(p_value IN VARCHAR2)
                        RETURN VARCHAR2
                    IS
                    BEGIN
                        RETURN UPPER(TRIM(p_value));
                    END;
                BEGIN
                    vrt_tabla.id := operaciones.seq_id_lista_negra.NEXTVAL;
                    vrt_tabla.nombre_persona := texto_formateado(prt_lista_negra.nombre);
                    vrt_tabla.primer_nombre := texto_formateado(prt_lista_negra.primer_nombre);
                    vrt_tabla.segundo_nombre := texto_formateado(prt_lista_negra.segundo_nombre);
                    vrt_tabla.primer_apellido := texto_formateado(prt_lista_negra.primer_apellido);
                    vrt_tabla.segundo_apellido := texto_formateado(prt_lista_negra.segundo_apellido);
                    vrt_tabla.apellido_casada := texto_formateado(prt_lista_negra.apellido_casada);
                    vrt_tabla.tipo_persona := texto_formateado(prt_lista_negra.tipo_persona);
                    vrt_tabla.tipo_documento := texto_formateado(prt_lista_negra.tipo_documento);
                    vrt_tabla.numero_documento := prt_lista_negra.numero_documento;
                    vrt_tabla.nacionalidad := prt_lista_negra.nacionalidad;
                    vrt_tabla.categoria := prt_lista_negra.categoria;
                    vrt_tabla.motivo := prt_lista_negra.motivo;
                    vrt_tabla.descripcion := prt_lista_negra.descripcion;
                    vrt_tabla.fecha := SYSDATE;

                    RETURN vrt_tabla;
                END registro_tabla;

                ----------------------------------------------------------

                PROCEDURE crea_registro_en_bitacora(p_error IN VARCHAR2, p_registro_duplicado IN BOOLEAN)
                IS
                    v_id_registro_duplicado operaciones.tamblista_negra.id%TYPE;

                BEGIN
                    IF p_registro_duplicado
                    THEN
                        v_id_registro_duplicado := operaciones.pkg_queries.id_lista_negra(p_nombre_persona => prt_lista_negra.nombre);
                    END IF;

                    INSERT INTO operaciones.tambregistros_erroneos_ln(id, id_duplicado, descripcion)
                    VALUES(prt_lista_negra.numero_registro, v_id_registro_duplicado, p_error);
                END crea_registro_en_bitacora;

                -----------------------------------------------------------

                PROCEDURE inserta_registro
                IS
                    e_valor_no_existe_en_catologo EXCEPTION;
                    PRAGMA EXCEPTION_INIT(e_valor_no_existe_en_catologo, -2291);

                    e_registro_duplicado EXCEPTION;
                    PRAGMA  EXCEPTION_INIT(e_registro_duplicado, -1);

                    v_error VARCHAR2(1000);
                BEGIN
                    INSERT INTO operaciones.tamblista_negra
                        VALUES vrt_registro_a_insertar;
                EXCEPTION
                    WHEN e_valor_no_existe_en_catologo
                    THEN
                        v_error := 'Campo nacionalidad puede ser nulo, si se inserta un valor debe '||
                                    'de estar definido en el catalogo de nacionalidades, Campos '||
                                    'motivo y categoria no deben ser nulos y estar definidos en catalogos';
                        crea_registro_en_bitacora(p_error => v_error
                                                    ,p_registro_duplicado => FALSE);
                    WHEN e_registro_duplicado
                    THEN
                        v_error := 'El registro ya se encuentra insertado'||
                                    ', Si desea modifique el registro';

                        crea_registro_en_bitacora(p_error => v_error
                                                    ,p_registro_duplicado => TRUE);
                END inserta_registro;
            BEGIN
                vrt_registro_a_insertar := registro_tabla;
                v_error_registro := error_registro_lista(vrt_registro_a_insertar);

                IF v_error_registro IS NULL
                THEN
                    inserta_registro;
                ELSE
                    crea_registro_en_bitacora(p_error => v_error_registro,
                                                p_registro_duplicado => FALSE);
                END IF;
            END procesa_registro;

            ----------------------------------------

            PROCEDURE limpia_bitacora
            IS
            BEGIN
                DELETE FROM operaciones.tambregistros_erroneos_ln;
            END;
        BEGIN
            limpia_bitacora;

            FOR rt_registro IN c_registros_xml
            LOOP
                procesa_registro(rt_registro);
            END LOOP;
        END extrae_registros;

        ----------------------------------------------------

        PROCEDURE valida_argumentos
        IS
        BEGIN
            IF NVL(DBMS_LOB.GETLENGTH(p_xml_document),0) = 0
            THEN
                RAISE e_empty_or_null_blob;
            END IF;
        END valida_argumentos;
    BEGIN
        valida_argumentos;
        crea_xmltype;
        vot_document.schemaValidate;
        extrae_registros;
    EXCEPTION
        WHEN e_empty_or_null_blob OR
            e_error_validando_xml OR
            e_not_schema_xml_document
        THEN
            RAISE;
        WHEN OTHERS THEN
            saif2000.errpkg.log_error('OPERACIONES.PKG_CUMPLIMIENTO.PROCESA_XML_LISTA_NEGRA');
            RAISE;
    END procesa_xml_lista_negra;

    PROCEDURE extrae_y_procesa_blob(p_id IN INTEGER)
    IS
        v_blob BLOB;

        PROCEDURE extrae_blob
        IS
        BEGIN
            SELECT archivo_blob
            INTO v_blob
            FROM saif2000.taselobs_temporales
            WHERE id = p_id;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                RAISE e_file_is_not_in_table;
        END extrae_blob;
    BEGIN
        extrae_blob;
        procesa_xml_lista_negra(p_compania => '01',
                                p_xml_document => v_blob);
    EXCEPTION
        WHEN e_empty_or_null_blob OR
            e_error_validando_xml OR
            e_file_is_not_in_table OR
            e_not_schema_xml_document
        THEN
            RAISE;
        WHEN OTHERS THEN
            saif2000.errpkg.log_error('OPERACIONES.PKG_CUMPLIMIENTO.EXTRAE_Y_PROCESA_BLOB');
            RAISE;
    END extrae_y_procesa_blob;

    FUNCTION coincidencias_lista_negra(p_compania IN VARCHAR2,
                                        p_nombre  IN VARCHAR2,
                                        p_cod_cliente IN VARCHAR2,
                                        p_relacion_cliente IN VARCHAR2,
                                        p_origen_coincidencia IN VARCHAR2)
        RETURN INTEGER
    IS
        PRAGMA AUTONOMOUS_TRANSACTION;

        v_nombre_limpio VARCHAR2(1000);
        vvt_nombre_to_search saif2000.vt_nombre_split;
        v_sensibilidad_busqueda INTEGER;
        v_edit_distance INTEGER;
        v_registros_insertados INTEGER;        
    BEGIN
        v_nombre_limpio := saif2000.pkg_utilidades.nombre_limpio(p_nombre);
        vvt_nombre_to_search := saif2000.pkg_utilidades.nombre_split_in_tokens(v_nombre_limpio);

        v_sensibilidad_busqueda := operaciones.pkg_queries.sensibilidad_busqueda_ln(p_compania, FALSE);
        v_edit_distance := operaciones.pkg_queries.edit_distance_busqueda_ln(p_compania, FALSE);

        IF v_sensibilidad_busqueda IS NULL OR v_edit_distance IS NULL
        THEN
            RAISE_APPLICATION_ERROR(pkg_exceptions.en_null_search_parameters,
                'Los parametros de sensibilidad_busqueda y edit_distance no puede ser nulos');
        END IF;

        INSERT INTO operaciones.tambcoincidencia_lista_negra(id_coincidencia_lista, fecha_generacion,
                                                            fecha_verificacion, coincidencia_verdadera,
                                                            cod_cliente, relacion_con_cliente,
                                                            nombre_persona_busqueda, id_lista_negra,
                                                            nombre_persona_coincidencia, tipo_persona,
                                                            tipo_documento, numero_documento,
                                                            nacionalidad, categoria,
                                                            motivo, descripcion,
                                                            fecha_ingreso_a_ln, cod_cia,
                                                            origen_coincidencia, hit_potencial)
        SELECT operaciones.seq_id_coincidencia_lst_negra.NEXTVAL, SYSDATE,
                NULL, NULL,
                p_cod_cliente, p_relacion_cliente,
                p_nombre, lista_negra.id,
                lista_negra.nombre_persona, lista_negra.tipo_persona,
                lista_negra.tipo_documento, lista_negra.numero_documento,
                lista_negra.nacionalidad, lista_negra.categoria,
                lista_negra.motivo, lista_negra.descripcion,
                lista_negra.fecha, p_compania,
                p_origen_coincidencia, 'S'
        FROM operaciones.tamblista_negra lista_negra
        WHERE lista_negra.nombre_split IS NOT NULL
            AND saif2000.pkg_utilidades.nombres_coinciden(vvt_nombre_to_search, lista_negra.nombre_split, v_sensibilidad_busqueda, v_edit_distance) = 1;        

        v_registros_insertados := SQL%ROWCOUNT;

        IF SQL%ROWCOUNT = 0 THEN
            INSERT INTO operaciones.tambcoincidencia_lista_negra(id_coincidencia_lista, fecha_generacion,
                                                                fecha_verificacion, coincidencia_verdadera,
                                                                cod_cliente, relacion_con_cliente,
                                                                nombre_persona_busqueda, id_lista_negra,
                                                                nombre_persona_coincidencia, tipo_persona,
                                                                tipo_documento, numero_documento,
                                                                nacionalidad, categoria,
                                                                motivo, descripcion,
                                                                fecha_ingreso_a_ln, cod_cia,
                                                                origen_coincidencia, hit_potencial)
            SELECT operaciones.seq_id_coincidencia_lst_negra.NEXTVAL, SYSDATE,
                    SYSDATE, 'N',
                    p_cod_cliente, p_relacion_cliente,
                    p_nombre, NULL,
                    NULL, NULL,
                    NULL, NULL,
                    NULL, NULL,
                    NULL, NULL,
                    NULL, p_compania,
                    p_origen_coincidencia, 'N'
            FROM DUAL;
        END IF;
        COMMIT;        
        RETURN v_registros_insertados;
    EXCEPTION
        WHEN OTHERS THEN
            errpkg.log_error('operaciones.pkg_cumplimiento.coincidencias_lista_negra');
            ROLLBACK;
            RAISE;
    END coincidencias_lista_negra;

    PROCEDURE log_cliente_fatca(p_compania IN VARCHAR2,
                                        p_nombre  IN VARCHAR2,
                                        p_cod_cliente IN VARCHAR2,
                                        p_relacion_cliente IN VARCHAR2,
                                        p_cod_pais IN VARCHAR2,
                                        p_tipo_indicio IN VARCHAR2)
    IS
        PRAGMA AUTONOMOUS_TRANSACTION;
    BEGIN
        IF bancos.pkg_queries.es_pais_fatca(p_cod_pais)
        THEN
            INSERT INTO operaciones.tamblog_indicio_fatca(id_indicio_fatca, cod_cia,
                                                            cod_cliente, nombre_posible_us_person,
                                                            relacion_cliente, cod_pais_indicio,
                                                            tipo_indicio)
            VALUES(operaciones.sed_id_indicio_fatca.NEXTVAL, p_compania,
                    p_cod_cliente, p_nombre,
                    p_relacion_cliente, p_cod_pais,
                    p_tipo_indicio);
        ELSE
            NULL;
        END IF;

        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            errpkg.log_error('operaciones.pkg_cumplimiento.log_cliente_fatca');
            ROLLBACK;
            RAISE;
    END log_cliente_fatca;

    PROCEDURE log_referencia_coinci_ln(p_cod_cia IN VARCHAR2,
                                            p_cod_cliente IN VARCHAR2,
                                            p_origen_coincidencia IN VARCHAR2)
    IS
      v_dummy INTEGER;
      CURSOR referencia is
        SELECT nombre_referencia
        FROM operaciones.tambrefxcl
        WHERE cod_cia = p_cod_cia
          AND codcliente = p_cod_cliente
          AND nombre_referencia IS NOT NULL
        ORDER BY nombre_referencia;

    BEGIN
       FOR f1 in referencia LOOP
            v_dummy := coincidencias_lista_negra(p_cod_cia, f1.nombre_referencia,
                                                p_cod_cliente, 'Referencia', p_origen_coincidencia);
       END LOOP;
    END log_referencia_coinci_ln;

    PROCEDURE log_beneficiario_coinci_ln(p_cod_cia IN VARCHAR2,
                                            p_cod_cliente IN VARCHAR2,
                                            p_origen_coincidencia IN VARCHAR2)
    IS
      v_dummy INTEGER;
      CURSOR beneficiario is
        SELECT nombenef||' '||apebenef nombre_beneficiario
        FROM operaciones.beneficiario
        WHERE cod_cia = p_cod_cia
          AND codcliente = p_cod_cliente
          AND nombenef||apebenef IS NOT NULL
        ORDER BY 1;

    BEGIN
       FOR f1 in beneficiario LOOP
            v_dummy := coincidencias_lista_negra(p_cod_cia, f1.nombre_beneficiario,
                                                p_cod_cliente, 'Beneficiario', p_origen_coincidencia);
       END LOOP;
    END log_beneficiario_coinci_ln;

    PROCEDURE log_autorizado_coinci_ln(p_cod_cia IN VARCHAR2,
                                            p_cod_cliente IN VARCHAR2,
                                            p_origen_coincidencia IN VARCHAR2)
    IS
      v_dummy INTEGER;
      CURSOR autorizado is
        SELECT nompersona||' '||apepersona nombre_autorizado
        FROM operaciones.pautorizada
        WHERE cod_cia = p_cod_cia
          AND codcliente = p_cod_cliente
          AND nompersona||apepersona IS NOT NULL
        ORDER BY 1;

    BEGIN
       FOR f1 in autorizado LOOP
            v_dummy := coincidencias_lista_negra(p_cod_cia, f1.nombre_autorizado,
                                                p_cod_cliente, 'Autorizado', p_origen_coincidencia);
       END LOOP;
    END log_autorizado_coinci_ln;

    PROCEDURE log_accionista_coinci_ln(p_cod_cia IN VARCHAR2,
                                            p_cod_cliente IN VARCHAR2,
                                            p_origen_coincidencia IN VARCHAR2)
    IS
      v_dummy INTEGER;
      CURSOR accionista is
        SELECT nombre_accionista
        FROM operaciones.tambacclfatca
        WHERE cod_cia = p_cod_cia
          AND codcliente = p_cod_cliente
          AND nombre_accionista IS NOT NULL
        ORDER BY 1;

    BEGIN
       FOR f1 in accionista LOOP
            v_dummy := coincidencias_lista_negra(p_cod_cia, f1.nombre_accionista,
                                                p_cod_cliente, 'Accionista', p_origen_coincidencia);
       END LOOP;
    END log_accionista_coinci_ln;

    PROCEDURE log_junta_coinci_ln(p_cod_cia IN VARCHAR2,
                                            p_cod_cliente IN VARCHAR2,
                                            p_origen_coincidencia IN VARCHAR2)
    IS
        v_dummy INTEGER;

        CURSOR junta(p_cod_cia1 IN VARCHAR2, p_cod_cliente1 IN VARCHAR) IS
            SELECT nombre_jd nombre_directivo
            FROM operaciones.tambjdxcl
            WHERE cod_cia = p_cod_cia1
              AND codcliente = p_cod_cliente1
              AND nombre_jd IS NOT NULL
            ORDER BY 1;

    BEGIN
        FOR f1 IN junta(p_cod_cia, p_cod_cliente) LOOP
            v_dummy := coincidencias_lista_negra(p_cod_cia, f1.nombre_directivo,
                                                p_cod_cliente, 'Junta Directiva', p_origen_coincidencia);
        END LOOP;
    END log_junta_coinci_ln;

    PROCEDURE log_cliente_coinci_ln(p_cod_cia IN VARCHAR2,
                                            p_cod_cliente IN VARCHAR2,
                                            p_origen_coincidencia IN VARCHAR2)
    IS
        vrt_cliente operaciones.cliente%ROWTYPE;
        vrt_referencia operaciones.tambrefxcl%ROWTYPE;
        vrt_beneficiario operaciones.beneficiario%ROWTYPE;
        vrt_autorizado operaciones.pautorizada%ROWTYPE;
        v_dummy INTEGER;

        C_NATURAL CONSTANT VARCHAR2(1) := 'N';
        C_JURIDICO CONSTANT VARCHAR2(1) := 'J';
    BEGIN
        vrt_cliente := operaciones.pkg_queries.datos_cliente(p_cod_cia, p_cod_cliente);
        
        IF vrt_cliente.nombrecliente IS NOT NULL
        THEN
            v_dummy := coincidencias_lista_negra(p_cod_cia, vrt_cliente.nombrecliente,
                                            p_cod_cliente, 'Cliente', p_origen_coincidencia);
        END IF;                                    

        IF vrt_cliente.persona = C_NATURAL
        THEN
            IF vrt_cliente.nombre_conyuge IS NOT NULL
            THEN
                v_dummy := coincidencias_lista_negra(p_cod_cia, vrt_cliente.nombre_conyuge,
                                                p_cod_cliente, 'C�nyuge', p_origen_coincidencia);
            END IF;
            IF vrt_cliente.lugartrabajo IS NOT NULL
            THEN
                v_dummy := coincidencias_lista_negra(p_cod_cia, vrt_cliente.lugartrabajo,
                                                p_cod_cliente, 'Lugar Trabajo', p_origen_coincidencia);
            END IF;
            IF vrt_cliente.nombre_persona_dependencia IS NOT NULL
            THEN
                v_dummy := coincidencias_lista_negra(p_cod_cia, vrt_cliente.nombre_persona_dependencia,
                                                p_cod_cliente, 'Persona de Dependencia', p_origen_coincidencia);
            END IF;
            IF vrt_cliente.nombre_rela IS NOT NULL THEN
                v_dummy := coincidencias_lista_negra(p_cod_cia, vrt_cliente.nombre_rela,
                                                 p_cod_cliente, 'Relacionado PEP', p_origen_coincidencia);
            END IF;
            log_referencia_coinci_ln(p_cod_cia,p_cod_cliente, p_origen_coincidencia);
            log_beneficiario_coinci_ln(p_cod_cia,p_cod_cliente, p_origen_coincidencia);
            log_autorizado_coinci_ln(p_cod_cia,p_cod_cliente, p_origen_coincidencia);
        ELSIF vrt_cliente.persona = C_JURIDICO
        THEN
            IF vrt_cliente.abreviatura_empresa IS NOT NULL THEN
                v_dummy := coincidencias_lista_negra(p_cod_cia, vrt_cliente.abreviatura_empresa,
                                                p_cod_cliente, 'Cliente', p_origen_coincidencia);
            END IF;
            IF vrt_cliente.notario_crea_escritura IS NOT NULL
            THEN
                v_dummy := coincidencias_lista_negra(p_cod_cia, vrt_cliente.notario_crea_escritura,
                                                p_cod_cliente, 'Notario Cre� Escritura Cliente', p_origen_coincidencia);
            END IF;
            IF vrt_cliente.notario_crea_escritura IS NOT NULL
            THEN                                     
                v_dummy := coincidencias_lista_negra(p_cod_cia, vrt_cliente.notario_modifica_escritura,
                                                p_cod_cliente, 'Notario Modific� Escritura Cliente', p_origen_coincidencia);
            END IF;                                   
            IF vrt_cliente.nombre_representante_legal IS NOT NULL
            THEN
                v_dummy := coincidencias_lista_negra(p_cod_cia, vrt_cliente.nombre_representante_legal,
                                                p_cod_cliente, 'Representante Legal', p_origen_coincidencia);
            END IF;
            IF vrt_cliente.nombre_rela_rep_legal IS NOT NULL THEN
                v_dummy := coincidencias_lista_negra(p_cod_cia, vrt_cliente.nombre_rela_rep_legal,
                                                p_cod_cliente, 'Relacionado PEP Representante Legal', p_origen_coincidencia);
            END IF;
            IF vrt_cliente.lugar_trabajo_rep_legal IS NOT NULL
            THEN 
                v_dummy := coincidencias_lista_negra(p_cod_cia, vrt_cliente.lugar_trabajo_rep_legal,
                                                p_cod_cliente, 'Lugar Trabajo Representante Legal', p_origen_coincidencia);
            END IF;                                    
            log_accionista_coinci_ln(p_cod_cia,p_cod_cliente, p_origen_coincidencia);
            log_junta_coinci_ln(p_cod_cia,p_cod_cliente, p_origen_coincidencia);
            log_autorizado_coinci_ln(p_cod_cia,p_cod_cliente, p_origen_coincidencia);
        ELSE
            NULL;
        END IF;
    END log_cliente_coinci_ln;
    
    PROCEDURE log_accionista_indicio_fatca(p_cod_cia IN VARCHAR2,
                                            p_cod_cliente IN VARCHAR2)
    IS
      v_dummy INTEGER;
      CURSOR accionista is
        SELECT nombre_accionista, cod_pais_nac1_accionista,
               cod_pais_nac2_accionista,cod_pais_nac3_accionista
        FROM operaciones.tambacclfatca
        WHERE cod_cia = p_cod_cia
          AND codcliente = p_cod_cliente
          AND nombre_accionista IS NOT NULL
        ORDER BY 1;

    BEGIN
       FOR f1 in accionista LOOP
            IF  bancos.pkg_queries.es_pais_fatca(f1.cod_pais_nac1_accionista)
            THEN
                operaciones.pkg_cumplimiento.log_cliente_fatca(
                            p_cod_cia, f1.nombre_accionista,
                            p_cod_cliente, 'Accionista',
                            f1.cod_pais_nac1_accionista, 'Pa�s Nacionalidad');
            END IF;
            IF  bancos.pkg_queries.es_pais_fatca(f1.cod_pais_nac2_accionista)
            THEN
                operaciones.pkg_cumplimiento.log_cliente_fatca(
                            p_cod_cia, f1.nombre_accionista,
                            p_cod_cliente, 'Accionista',
                            f1.cod_pais_nac2_accionista, 'Pa�s Nacionalidad');
            END IF;
            IF  bancos.pkg_queries.es_pais_fatca(f1.cod_pais_nac3_accionista)
            THEN
                operaciones.pkg_cumplimiento.log_cliente_fatca(
                            p_cod_cia, f1.nombre_accionista,
                            p_cod_cliente, 'Accionista',
                            f1.cod_pais_nac3_accionista, 'Pa�s Nacionalidad');
            END IF;
       END LOOP;
    END log_accionista_indicio_fatca;
    
    PROCEDURE log_junta_indicio_fatca(p_cod_cia IN VARCHAR2,
                                            p_cod_cliente IN VARCHAR2)
    IS
        v_dummy INTEGER;

        CURSOR junta(p_cod_cia1 IN VARCHAR2, p_cod_cliente1 IN VARCHAR) IS
            SELECT nombre_jd nombre_directivo, cod_pais_nac1_jd,
                   cod_pais_nac2_jd, cod_pais_nac3_jd
            FROM operaciones.tambjdxcl
            WHERE cod_cia = p_cod_cia1
              AND codcliente = p_cod_cliente1
              AND nombre_jd IS NOT NULL
            ORDER BY 1;

    BEGIN
        FOR f1 IN junta(p_cod_cia, p_cod_cliente) LOOP
            IF  bancos.pkg_queries.es_pais_fatca(f1.cod_pais_nac1_jd)
            THEN
                operaciones.pkg_cumplimiento.log_cliente_fatca(
                            p_cod_cia, f1.nombre_directivo,
                            p_cod_cliente, 'Directivo',
                            f1.cod_pais_nac1_jd, 'Pa�s Nacionalidad');
            END IF;
            IF  bancos.pkg_queries.es_pais_fatca(f1.cod_pais_nac2_jd)
            THEN
                operaciones.pkg_cumplimiento.log_cliente_fatca(
                            p_cod_cia, f1.nombre_directivo,
                            p_cod_cliente, 'Directivo',
                            f1.cod_pais_nac2_jd, 'Pa�s Nacionalidad');
            END IF;
            IF  bancos.pkg_queries.es_pais_fatca(f1.cod_pais_nac3_jd)
            THEN
                operaciones.pkg_cumplimiento.log_cliente_fatca(
                            p_cod_cia, f1.nombre_directivo,
                            p_cod_cliente, 'Directivo',
                            f1.cod_pais_nac3_jd, 'Pa�s Nacionalidad');
            END IF;
        END LOOP;
    END log_junta_indicio_fatca;
    
    PROCEDURE log_autorizado_indicio_fatca(p_cod_cia IN VARCHAR2,
                                            p_cod_cliente IN VARCHAR2)
    IS
      CURSOR autorizado is
        SELECT nompersona||' '||apepersona nombre_autorizado,
               cod_pais_residencia, cod_pais_nacimiento
        FROM operaciones.pautorizada
        WHERE cod_cia = p_cod_cia
          AND codcliente = p_cod_cliente
          AND nompersona||apepersona IS NOT NULL 
        ORDER BY 1;
    BEGIN
       FOR f1 in autorizado LOOP
            IF  bancos.pkg_queries.es_pais_fatca(f1.cod_pais_nacimiento)
            THEN
                operaciones.pkg_cumplimiento.log_cliente_fatca(
                            p_cod_cia, f1.nombre_autorizado,
                            p_cod_cliente, 'Autorizado',
                            f1.cod_pais_nacimiento, 'Pa�s Nacimiento');
            END IF;
            IF  bancos.pkg_queries.es_pais_fatca(f1.cod_pais_residencia)
            THEN
                operaciones.pkg_cumplimiento.log_cliente_fatca(
                            p_cod_cia, f1.nombre_autorizado,
                            p_cod_cliente, 'Autorizado',
                            f1.cod_pais_residencia, 'Pa�s Domicilio');
            END IF;
       END LOOP;
    END log_autorizado_indicio_fatca;
    
    PROCEDURE log_cliente_indicio_fatca(p_cod_cia IN VARCHAR2,
                                            p_cod_cliente IN VARCHAR2)
    IS
        vrt_cliente operaciones.cliente%ROWTYPE;
        C_NATURAL CONSTANT VARCHAR2(1) := 'N';
        C_JURIDICO CONSTANT VARCHAR2(1) := 'J';
    BEGIN
        vrt_cliente := operaciones.pkg_queries.datos_cliente(p_cod_cia, p_cod_cliente);


        IF vrt_cliente.persona = C_NATURAL
        THEN
            IF  bancos.pkg_queries.es_pais_fatca(vrt_cliente.cod_pais_nacimiento)
            THEN
                operaciones.pkg_cumplimiento.log_cliente_fatca(
                            p_cod_cia, vrt_cliente.nombrecliente ,
                            p_cod_cliente, 'Cliente',
                            vrt_cliente.cod_pais_nacimiento, 'Pa�s Nacimiento');
            END IF;
            IF  bancos.pkg_queries.es_pais_fatca(vrt_cliente.cod_pais_residencia)
            THEN
                operaciones.pkg_cumplimiento.log_cliente_fatca(
                            p_cod_cia, vrt_cliente.nombrecliente ,
                            p_cod_cliente, 'Cliente',
                            vrt_cliente.cod_pais_residencia, 'Pa�s Domicilio');
            END IF;
            IF  bancos.pkg_queries.es_pais_fatca(vrt_cliente.cod_pais_lab)
            THEN
                operaciones.pkg_cumplimiento.log_cliente_fatca(
                            p_cod_cia, vrt_cliente.nombrecliente ,
                            p_cod_cliente, 'Cliente',
                            vrt_cliente.cod_pais_lab, 'Pa�s Laboral');
            END IF;
            IF  bancos.pkg_queries.es_pais_fatca(vrt_cliente.cod_pais_nac1_extranjero)
            THEN
                operaciones.pkg_cumplimiento.log_cliente_fatca(
                            p_cod_cia, vrt_cliente.nombrecliente ,
                            p_cod_cliente, 'Cliente',
                            vrt_cliente.cod_pais_nac1_extranjero, 'Pa�s otra Nacionalidad');
            END IF;
            IF  bancos.pkg_queries.es_pais_fatca(vrt_cliente.cod_pais_nac2_extranjero)
            THEN
                operaciones.pkg_cumplimiento.log_cliente_fatca(
                            p_cod_cia, vrt_cliente.nombrecliente ,
                            p_cod_cliente, 'Cliente',
                            vrt_cliente.cod_pais_nac2_extranjero, 'Pa�s otra Nacionalidad');
            END IF;
            IF  bancos.pkg_queries.es_pais_fatca(vrt_cliente.cod_pais_nac3_extranjero)
            THEN
                operaciones.pkg_cumplimiento.log_cliente_fatca(
                            p_cod_cia, vrt_cliente.nombrecliente ,
                            p_cod_cliente, 'Cliente',
                            vrt_cliente.cod_pais_nac3_extranjero, 'Pa�s otra Nacionalidad');
            END IF;
            log_autorizado_indicio_fatca(p_cod_cia,p_cod_cliente);
        ELSIF vrt_cliente.persona = C_JURIDICO
          THEN
            IF  bancos.pkg_queries.es_pais_fatca(vrt_cliente.cod_pais_nacimiento)
            THEN
                operaciones.pkg_cumplimiento.log_cliente_fatca(
                            p_cod_cia, vrt_cliente.nombrecliente ,
                            p_cod_cliente, 'Cliente',
                            vrt_cliente.cod_pais_nacimiento, 'Pa�s constituci�n');
            END IF;
            IF  bancos.pkg_queries.es_pais_fatca(vrt_cliente.cod_pais_residencia)
            THEN
                operaciones.pkg_cumplimiento.log_cliente_fatca(
                            p_cod_cia, vrt_cliente.nombrecliente ,
                            p_cod_cliente, 'Cliente',
                            vrt_cliente.cod_pais_residencia, 'Pa�s Domicilio');
            END IF;
            IF  bancos.pkg_queries.es_pais_fatca(vrt_cliente.cod_pais_nacimiento_rep_legal)
            THEN
                operaciones.pkg_cumplimiento.log_cliente_fatca(
                            p_cod_cia, vrt_cliente.nombre_representante_legal,
                            p_cod_cliente, 'Representante Legal',
                            vrt_cliente.cod_pais_nacimiento_rep_legal, 'Pa�s Nacimiento');
            END IF;
            IF  bancos.pkg_queries.es_pais_fatca(vrt_cliente.cod_pais_residencia_rep_legal)
            THEN
                operaciones.pkg_cumplimiento.log_cliente_fatca(
                            p_cod_cia, vrt_cliente.nombre_representante_legal,
                            p_cod_cliente, 'Representante Legal',
                            vrt_cliente.cod_pais_residencia_rep_legal, 'Pa�s Domicilio');
            END IF;
            log_accionista_indicio_fatca(p_cod_cia,p_cod_cliente);
            log_junta_indicio_fatca(p_cod_cia,p_cod_cliente);
            log_autorizado_indicio_fatca(p_cod_cia,p_cod_cliente);
        ELSE
            NULL;
        END IF;
    END log_cliente_indicio_fatca;
END pkg_cumplimiento;
/

GRANT EXECUTE ON OPERACIONES.PKG_CUMPLIMIENTO TO PUBLIC;

GRANT EXECUTE ON OPERACIONES.PKG_CUMPLIMIENTO TO RL_MENU_ADMIN_OPERACIONES;

GRANT EXECUTE ON OPERACIONES.PKG_CUMPLIMIENTO TO RL_SAIF_CORREDOR;

GRANT EXECUTE ON OPERACIONES.PKG_CUMPLIMIENTO TO RL_SAIF_CUMPLIMIENTO;

GRANT EXECUTE ON OPERACIONES.PKG_CUMPLIMIENTO TO RL_SAIF_GERENTE;
