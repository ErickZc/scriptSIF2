DROP PACKAGE OPERACIONES.PKG_MONITOR;

CREATE OR REPLACE PACKAGE OPERACIONES.pkg_monitor
IS
    TYPE C_REP_GLOBAL IS REF CURSOR RETURN OPERACIONES.TAMBLIQUIDACION_GLOBAL%ROWTYPE;
    
    
    FUNCTION format(p_cadena in varchar2, p_tipo in varchar2, p_long integer, p_relleno in varchar2)
    RETURN VARCHAR2;

    PROCEDURE crea_trama_2515_productos (p_cod_cia IN Varchar2, p_fecha IN DATE);
    FUNCTION sele_trama_2515_productos (p_cod_cia IN Varchar2, p_fecha IN DATE)
    return varchar2;
                  
END PKG_MONITOR;
/

GRANT EXECUTE ON OPERACIONES.PKG_MONITOR TO PUBLIC;
DROP PACKAGE BODY OPERACIONES.PKG_MONITOR;

CREATE OR REPLACE PACKAGE BODY OPERACIONES.pkg_monitor
IS

FUNCTION Format(p_cadena in varchar2, p_tipo in varchar2, p_long integer, p_relleno in varchar2)
RETURN VARCHAR2 IS   
    -- p_cadena -- cadena para aplicar formato
    -- p_tipo -- tipo de dato recibido C-char, N-number, D-Date
    --p_long   -- longitud char a retornar
    -- p_relleno --  relleno para longitud
v_cadena varchar2(2000);
v_format varchar2(2000);
BEGIN
  
    -- si es caracter solo se rellenacon espacios
  IF p_tipo = 'C' THEN
     if p_cadena is not null then
     --quitando guiones y puntos
        v_format := substr(rpad(p_cadena,p_long, p_relleno),1, p_long);
     -- extrayendo cadena                       
     --v_format  := substr(v_cadena,1,p_long);
     --end;
     else
        v_format := rpad(' ', p_long, p_relleno);
     end if;
  end if;
  -- si es numerico solo se rellenacon espacios
  IF p_tipo = 'N' THEN     
     v_cadena  := lpad(to_char(p_cadena), p_long, p_relleno);
     v_format  := substr(v_cadena,1,p_long);     
  end if;
  
  -- tipo Date
  IF p_tipo = 'D'   THEN     
       if p_cadena is not null then
         
         v_format  := to_char(to_date(p_cadena), 'yyyymmdd');
         --v_format  := substr(v_cadena,1,p_long);     
        else          
         v_format  := '        ';--lpad(p_cadena, p_long, p_relleno);
        end if;  
  end if;
  return(v_format);
END Format; 
PROCEDURE crea_trama_2515_productos (p_cod_cia IN Varchar2, p_fecha IN DATE)
                      IS
                        

    --
     v_cod_trama    INTEGER := 2515;
     v_string_trama VARCHAR2(2000);
      
    --
    
    CURSOR C1 IS
    SELECT decode(replace(replace(x.nacional_extranjero, '-', ''), '.', ''), 'N', 'N'||replace(replace(x.nit, '-', ''), '.', ''),'E', 'N'||replace(replace(x.nit_extranjero, '-', ''), '.', ''))  acrm_no_identificacion,
       x.persona  acrm_tipo_persona_nj,
       '0001'  acrm_codigo_empresa,        
       y.t_mercado acrm_codigo_producto,  
       z.mercado acrm_descripcion_producto ,
       y.c_titulo acrm_codigo_subproducto,
       y.nm_operacion  acrm_no_producto_cuenta, 
       '00001'  acrm_tipo_cuenta, 
       y.f_operacion  , 
       a.abreviatura_moneda  , 
       y.v_nominal  acrm_monto_apertura , 
       ---------------------------------
       --estatus_producto nuevo/renovacion >>  s/N ordenes
       ---------------------------------
       x.corredor  , 
       '00001'  acrm_oficina_apertura,
       '00001'  acrm_sucursal_apertura, 
       '001'  acrm_region_sucursal, 
       y.v_nominal  acrm_saldo_producto, 
       y.v_nominal  acrm_saldo_prom_mensual,
       --------------------------- 
       b.fecha_ult_pago  , 
       b.fecha_vence  ,
       null  acrm_fecha_cancelacion,  
       y.codcliente  acrm_codigo_cliente, 
       y.usuario_add  acrm_usuario_apertura, 
       '0000000001'  acrm_canal_vinculacion, 
       null  acrm_fecha_activacion,
       (b.fecha_vence - y.f_liquida)  acrm_plazo,
       b.descripcion_emision 
FROM OPERACIONES.CLIENTE X, OPERACIONES.BOLETA Y, OPERACIONES.MERCADO Z, BANCOS.TABATMON A, OPERACIONES.TACEMIBV B
WHERE X.ESTADO_CLIENTE = 'A' AND
      X.CODCLIENTE    = Y.CODCLIENTE AND
      Y.T_MERCADO      = Z.CODMERCADO AND
      Y.MONEDA         = A.COD_MONEDA AND
      (Y.C_TITULO      = B.TITULO AND Y.SERIE = B.SERIE) AND
      Y.F_LIQUIDA = '15-08-2017'
UNION
SELECT SUBSTR(DECODE(x.NACIONAL_EXTRANJERO, 'N', 'N'||replace(replace(x.NIT, '-', ''), '.', ''),'E', 'N'||x.NIT_EXTRANJERO),1,18)  ACRM_NO_IDENTIFICACION, 
       
       X.PERSONA  ACRM_TIPO_PERSONA_NJ,
       '0001'  ACRM_CODIGO_EMPRESA, 
       Y.T_MERCADO  ACRM_CODIGO_PRODUCTO , 
       Z.MERCADO  ACRM_DESCRIPCION_PRODUCTO, 
       Y.C_TITULO  ACRM_CODIGO_SUBPRODUCTO,     
       Y.NM_OPERACION  ACRM_NO_PRODUCTO_CUENTA, 
       '00002'   ACRM_TIPO_CUENTA, 
       Y.F_OPERACION  , 
       A.ABREVIATURA_MONEDA  , 
       Y.V_NOMINAL  acrm_monto_apertura, 
       X.CORREDOR  , 
       '00001'   ACRM_OFICINA_APERTURA,
       '00001'   ACRM_SUCURSAL_APERTURA, 
       '001'   ACRM_REGION_SUCURSAL, 
       y.V_NOMINAL  ACRM_SALDO_PRODUCTO, 
       y.V_NOMINAL  ACRM_SALDO_PROM_MENSUAL, 
       B.FECHA_ULT_PAGO  , 
       B.FECHA_VENCE  ,
       NULL  ACRM_FECHA_CANCELACION,  
       Y.CODCLIENTE_V  ACRM_CODIGO_CLIENTE, 
       Y.USUARIO_ADD  ACRM_USUARIO_APERTURA, 
       '0000000001'  ACRM_CANAL_VINCULACION, 
       NULL  ACRM_FECHA_ACTIVACION,
       (B.FECHA_VENCE - Y.F_LIQUIDA)  ACRM_PLAZO ,
       b.descripcion_emision
FROM OPERACIONES.CLIENTE X, OPERACIONES.BOLETA Y, OPERACIONES.MERCADO Z, BANCOS.TABATMON A, OPERACIONES.TACEMIBV B
WHERE X.ESTADO_CLIENTE = 'A' AND
      X.CODCLIENTE    = Y.CODCLIENTE_V AND
      Y.T_MERCADO      = Z.CODMERCADO AND
      Y.MONEDA         = A.COD_MONEDA AND
      (Y.C_TITULO      = B.TITULO AND Y.SERIE = B.SERIE) AND
      Y.F_LIQUIDA = '15-08-2017'; 
BEGIN
    
        For f1 in C1 loop
            v_string_trama :=   format(f1.acrm_no_identificacion    ,'C', 18, ' ')
                              ||format(f1.acrm_tipo_persona_nj      ,'C', 1, ' ')
                              ||format(f1.acrm_codigo_empresa       ,'C', 4, ' ')        
                              ||format(f1.acrm_codigo_producto      ,'C', 5, ' ') 
                              ||format(f1.acrm_descripcion_producto ,'C', 20, ' ')
                              ||format(f1.acrm_codigo_subproducto   ,'C', 6, ' ')
                              ||format(f1.acrm_no_producto_cuenta   ,'C', 20, ' ') 
                              ||format(f1.acrm_tipo_cuenta   ,'C', 5, ' ') 
                              ||format(f1.f_operacion  ,'D', 8, ' ')
                              ||format(f1.abreviatura_moneda  ,'C', 3, ' ') 
                              ||format(f1.acrm_monto_apertura ,'N', 16, '0') 
                               ---------------------------------
                               --estatus_producto nuevo/renovacion >>  s/N ordenes
                               ---------------------------------
                               ||format(f1.corredor  ,'C', 12, ' ') 
                               ||format(f1.acrm_oficina_apertura ,'N', 5, '0')
                               ||format(f1.acrm_sucursal_apertura,'N', 5, '0') 
                               ||format(f1.acrm_region_sucursal,'N', 3, '0') 
                               ||format(f1.acrm_saldo_producto,'N', 16, '0') 
                               ||format(f1.acrm_saldo_prom_mensual ,'N', 16, '0')                               
                               ||format(f1.fecha_ult_pago  ,'D', 8, ' ') 
                               ||format(f1.fecha_vence  ,'D', 8, ' ')
                               ||format(f1.acrm_fecha_cancelacion,'D', 8, ' ')  
                               ||format(f1.acrm_codigo_cliente, 'C', 15, ' ')  
                               ||format(f1.acrm_usuario_apertura,'C', 10, ' ')  
                               ||format(f1.acrm_canal_vinculacion,'C', 10, ' ')  
                               ||format(f1.acrm_fecha_activacion,'D', 8, ' ')
                               ||format(f1.acrm_plazo ,'N', 5, '0')
                               ---------------------adicionales de la trama---
                               ||format(0 ,'N', 5, '0')
                               ||format(0 ,'N', 5, '0')
                               ||format(0 ,'N', 16, '0')
                               ||format(0 ,'N', 16, '0')
                               ||format(0 ,'N', 16, '0')
                               ||format(0 ,'N', 16, '0')
                               ||format(0 ,'N', 5, '0')
                               ||format(0 ,'N', 5, '0')
                               ||format(0 ,'N', 16, '0')
                               ||format(0 ,'N', 16, '0')
                               ||format(0 ,'N', 16, '0')
                               ||format(0 ,'N', 16, '0')
                               ||format(' ' ,'C', 10, ' ')
                               ||format(' ' ,'C', 10, ' ')
                               ||format(' ' ,'C', 10, ' ')
                               ||format(' ' ,'C', 10, ' ')
                               ||format(' ' ,'C', 10, ' ')
                               ||format(' ' ,'C', 10, ' ')
                               ||format(' ' ,'C', 10, ' ')
                               ||format(' ' ,'C', 1, ' ')
                               ||format(' ' ,'C', 1, ' ')
                               ||format(' ' ,'C', 1, ' ')
                               ||format(0 ,'C', 5, '0')
                               ||format(0 ,'C', 5, '0')
                               ||format(0 ,'C', 5, '0')
                               ||format(0 ,'C', 5, '0')
                               ||format(0 ,'C', 5, '0')
                               ||format('S' ,'C', 1, ' ')
                               ||format(f1.descripcion_emision ,'C', 20, ' ')
                               ;                            
                               
                               
            begin    
                INSERT INTO OPERACIONES.tambtrama_monitor(cod_cia, cod_trama, long_trama, trama )
                values(p_cod_cia, v_cod_trama, length(v_string_trama), v_string_trama);
           end;
        end loop;
        commit;
                                    
END crea_trama_2515_productos;


FUNCTION sele_trama_2515_productos (p_cod_cia IN Varchar2, p_fecha IN DATE)
                      
    RETURN VARCHAR2  
    IS
        l_trama operaciones.tambtrama_monitor.trama%type;
          
    BEGIN
            crea_trama_2515_productos (p_cod_cia, p_fecha);
            
        select  trama
           into l_trama
          from  operaciones.tambtrama_monitor
          where cod_cia = p_cod_cia;


        IF l_trama  IS NULL
        THEN
            RAISE NO_DATA_FOUND;
        ELSE
            RETURN  l_trama;
        END IF;

    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            null;
        WHEN OTHERS THEN
            errpkg.log_error('operaciones.pkg_monitor.sele_trama_2515_productos');
            RAISE;
    END sele_trama_2515_productos;
END PKG_MONITOR;
/

GRANT EXECUTE ON OPERACIONES.PKG_MONITOR TO PUBLIC;
