DROP PACKAGE OPERACIONES.PKG_MONITOR;

CREATE OR REPLACE PACKAGE OPERACIONES.pkg_monitor
IS
    TYPE C_REP_GLOBAL IS REF CURSOR RETURN OPERACIONES.TAMBLIQUIDACION_GLOBAL%ROWTYPE;
    
    
    FUNCTION format(p_cadena in varchar2, p_tipo in varchar2, p_long integer, p_relleno in varchar2)
    RETURN VARCHAR2;

    PROCEDURE crea_trama_2515_productos (p_cod_cia IN Varchar2, p_fecha IN DATE);
    
    PROCEDURE crea_trama_2505_personas (p_cod_cia IN Varchar2, p_fecha IN DATE);
                  
END PKG_MONITOR;
/

GRANT EXECUTE ON OPERACIONES.PKG_MONITOR TO PUBLIC;
DROP PACKAGE BODY OPERACIONES.PKG_MONITOR;

CREATE OR REPLACE PACKAGE BODY OPERACIONES.pkg_monitor
IS

FUNCTION Format(p_cadena in varchar2, p_tipo in varchar2, p_long integer, p_relleno in varchar2)
RETURN VARCHAR2 IS   
    -- p_cadena -- cadena para aplicar formato
    -- p_tipo -- tipo de dato recibido C-char, N-number, D-Date
    --p_long   -- longitud char a retornar
    -- p_relleno --  relleno para longitud
v_cadena varchar2(2000);
v_format varchar2(2000);
BEGIN
  
    -- si es caracter solo se rellenacon espacios
  IF p_tipo = 'C' THEN
     if p_cadena is not null then
     --quitando guiones y puntos
        v_format := substr(rpad(p_cadena,p_long, p_relleno),1, p_long);
     -- extrayendo cadena                       
     --v_format  := substr(v_cadena,1,p_long);
     --end;
     else
        v_format := rpad(' ', p_long, p_relleno);
     end if;
  end if;
  -- si es numerico solo se rellenacon espacios
  IF p_tipo = 'N' THEN     
     v_cadena  := lpad(to_char(p_cadena), p_long, p_relleno);
     v_format  := substr(v_cadena,1,p_long);     
  end if;
  
  -- tipo Date
  IF p_tipo = 'D'   THEN     
       if p_cadena is not null then
         
         v_format  := to_char(to_date(p_cadena), 'yyyymmdd');
         --v_format  := substr(v_cadena,1,p_long);     
        else          
         v_format  := '        ';--lpad(p_cadena, p_long, p_relleno);
        end if;  
  end if;
  return(v_format);
END Format; 
PROCEDURE crea_trama_2515_productos (p_cod_cia IN Varchar2, p_fecha IN DATE)
                      IS
                        

    --
     v_cod_trama    INTEGER := 2515;
     v_string_trama VARCHAR2(2000);
      
    --
    
    CURSOR C1 IS
    SELECT decode(replace(replace(x.nacional_extranjero, '-', ''), '.', ''), 'N', 'N'||replace(replace(x.nit, '-', ''), '.', ''),'E', 'N'||replace(replace(x.nit_extranjero, '-', ''), '.', ''))  acrm_no_identificacion,
       x.persona  acrm_tipo_persona_nj,
       '0001'  acrm_codigo_empresa,        
       y.t_mercado acrm_codigo_producto,  
       z.mercado acrm_descripcion_producto ,
       y.c_titulo acrm_codigo_subproducto,
       y.nm_operacion  acrm_no_producto_cuenta, 
       '00001'  acrm_tipo_cuenta, 
       y.f_operacion  , 
       a.abreviatura_moneda  , 
       y.v_nominal  acrm_monto_apertura , 
       ---------------------------------
       --estatus_producto nuevo/renovacion >>  s/N ordenes
       ---------------------------------
       x.corredor  , 
       '00001'  acrm_oficina_apertura,
       '00001'  acrm_sucursal_apertura, 
       '001'  acrm_region_sucursal, 
       y.v_nominal  acrm_saldo_producto, 
       y.v_nominal  acrm_saldo_prom_mensual,
       --------------------------- 
       b.fecha_ult_pago  , 
       b.fecha_vence  ,
       null  acrm_fecha_cancelacion,  
       y.codcliente  acrm_codigo_cliente, 
       y.usuario_add  acrm_usuario_apertura, 
       '0000000001'  acrm_canal_vinculacion, 
       null  acrm_fecha_activacion,
       (b.fecha_vence - y.f_liquida)  acrm_plazo,
       b.descripcion_emision 
from operaciones.cliente x, operaciones.boleta y, operaciones.mercado z, bancos.tabatmon a, operaciones.tacemibv b
where x.estado_cliente = 'A' and
      x.codcliente    = y.codcliente and
      y.t_mercado      = z.codmercado and
      y.moneda         = a.cod_moneda and
      (y.c_titulo      = b.titulo and y.serie = b.serie) and
      y.f_liquida = '15-08-2017'
union
select substr(decode(x.nacional_extranjero, 'N', 'N'||replace(replace(x.nit, '-', ''), '.', ''),'E', 'N'||x.nit_extranjero),1,18)  acrm_no_identificacion, 
       
       x.persona  acrm_tipo_persona_nj,
       '0001'  acrm_codigo_empresa, 
       y.t_mercado  acrm_codigo_producto , 
       z.mercado  acrm_descripcion_producto, 
       y.c_titulo  acrm_codigo_subproducto,     
       y.nm_operacion  acrm_no_producto_cuenta, 
       '00002'   acrm_tipo_cuenta, 
       y.f_operacion  , 
       a.abreviatura_moneda  , 
       y.v_nominal  acrm_monto_apertura, 
       x.corredor  , 
       '00001'   acrm_oficina_apertura,
       '00001'   acrm_sucursal_apertura, 
       '001'   acrm_region_sucursal, 
       y.v_nominal  acrm_saldo_producto, 
       y.v_nominal  acrm_saldo_prom_mensual, 
       b.fecha_ult_pago  , 
       b.fecha_vence  ,
       null  acrm_fecha_cancelacion,  
       y.codcliente_v  acrm_codigo_cliente, 
       y.usuario_add  acrm_usuario_apertura, 
       '0000000001'  acrm_canal_vinculacion, 
       null  acrm_fecha_activacion,
       (b.fecha_vence - y.f_liquida)  acrm_plazo ,
       b.descripcion_emision
from operaciones.cliente x, operaciones.boleta y, operaciones.mercado z, bancos.tabatmon a, operaciones.tacemibv b
where x.estado_cliente = 'A' and
      x.codcliente    = y.codcliente_v and
      y.t_mercado      = z.codmercado and
      y.moneda         = a.cod_moneda and
      (y.c_titulo      = b.titulo and y.serie = b.serie) and
      y.f_liquida = '15-08-2017'; 
BEGIN
    
        For f1 in C1 loop
            v_string_trama :=   format(f1.acrm_no_identificacion    ,'C', 18, ' ')
                              ||format(f1.acrm_tipo_persona_nj      ,'C', 1, ' ')
                              ||format(f1.acrm_codigo_empresa       ,'C', 4, ' ')        
                              ||format(f1.acrm_codigo_producto      ,'C', 5, ' ') 
                              ||format(f1.acrm_descripcion_producto ,'C', 20, ' ')
                              ||format(f1.acrm_codigo_subproducto   ,'C', 6, ' ')
                              ||format(f1.acrm_no_producto_cuenta   ,'C', 20, ' ') 
                              ||format(f1.acrm_tipo_cuenta   ,'C', 5, ' ') 
                              ||format(f1.f_operacion  ,'D', 8, ' ')
                              ||format(f1.abreviatura_moneda  ,'C', 3, ' ') 
                              ||format(f1.acrm_monto_apertura ,'N', 16, '0') 
                               ---------------------------------
                               --estatus_producto nuevo/renovacion >>  s/N ordenes
                               ---------------------------------
                               ||format(f1.corredor  ,'C', 12, ' ') 
                               ||format(f1.acrm_oficina_apertura ,'N', 5, '0')
                               ||format(f1.acrm_sucursal_apertura,'N', 5, '0') 
                               ||format(f1.acrm_region_sucursal,'N', 3, '0') 
                               ||format(f1.acrm_saldo_producto,'N', 16, '0') 
                               ||format(f1.acrm_saldo_prom_mensual ,'N', 16, '0')                               
                               ||format(f1.fecha_ult_pago  ,'D', 8, ' ') 
                               ||format(f1.fecha_vence  ,'D', 8, ' ')
                               ||format(f1.acrm_fecha_cancelacion,'D', 8, ' ')  
                               ||format(f1.acrm_codigo_cliente, 'C', 15, ' ')  
                               ||format(f1.acrm_usuario_apertura,'C', 10, ' ')  
                               ||format(f1.acrm_canal_vinculacion,'C', 10, ' ')  
                               ||format(f1.acrm_fecha_activacion,'D', 8, ' ')
                               ||format(f1.acrm_plazo ,'N', 5, '0')
                               ---------------------adicionales de la trama---
                               ||format(0 ,'N', 5, '0')
                               ||format(0 ,'N', 5, '0')
                               ||format(0 ,'N', 16, '0')
                               ||format(0 ,'N', 16, '0')
                               ||format(0 ,'N', 16, '0')
                               ||format(0 ,'N', 16, '0')
                               ||format(0 ,'N', 5, '0')
                               ||format(0 ,'N', 5, '0')
                               ||format(0 ,'N', 16, '0')
                               ||format(0 ,'N', 16, '0')
                               ||format(0 ,'N', 16, '0')
                               ||format(0 ,'N', 16, '0')
                               ||format(' ' ,'C', 10, ' ')
                               ||format(' ' ,'C', 10, ' ')
                               ||format(' ' ,'C', 10, ' ')
                               ||format(' ' ,'C', 10, ' ')
                               ||format(' ' ,'C', 10, ' ')
                               ||format(' ' ,'C', 10, ' ')
                               ||format(' ' ,'C', 10, ' ')
                               ||format(' ' ,'C', 1, ' ')
                               ||format(' ' ,'C', 1, ' ')
                               ||format(' ' ,'C', 1, ' ')
                               ||format(0 ,'C', 5, '0')
                               ||format(0 ,'C', 5, '0')
                               ||format(0 ,'C', 5, '0')
                               ||format(0 ,'C', 5, '0')
                               ||format(0 ,'C', 5, '0')
                               ||format('S' ,'C', 1, ' ')
                               ||format(f1.descripcion_emision ,'C', 20, ' ')
                               ;                            
                               
                               
            begin    
                INSERT INTO OPERACIONES.tambtrama_monitor(cod_cia, cod_trama, long_trama, trama )
                values(p_cod_cia, v_cod_trama, length(v_string_trama), v_string_trama);
           end;
        end loop;
        commit;
                                    
END crea_trama_2515_productos;

PROCEDURE crea_trama_2505_personas (p_cod_cia IN Varchar2, p_fecha IN DATE)
IS
    --
     v_cod_trama    INTEGER := 2505;
     v_string_trama VARCHAR2(2000);
      
    --
    
    CURSOR c1 IS
    SELECT decode(replace(replace(nacional_extranjero, '-', ''), '.', ''), 'N', 'N'||replace(replace(nit, '-', ''), '.', ''),'E', 'N'||replace(replace(nit_extranjero, '-', ''), '.', ''))  acrm_no_identificacion,
       substr(decode(persona, 'N',nombrecliente, 'J', nombre),1,70)   ACRM_NOMBRE_CLIENTE,
       '0001'  ACRM_CODIGO_EMPRESA, 
       codcliente  ACRM_CODIGO_PERSONA,
       persona  ACRM_TIPO_PERSONA_NJ,
       
       decode(persona, 'N',fecha_exp_docu_identidad, ' ')  ACRM_FECHA_EXPEDICION_ID,
       substr(decode(persona, 'N',lug_exp_docu_identidad, ' '),1,15)   ACRM_Ciudad_Expedici�n_ID,
       substr(decode(persona, 'N',lug_exp_docu_identidad, ' '),1,15)   ACRM_Departa_Expedici�n_ID,
       fecha_ingreso  ACRM_FECHA_APERTURA,
       '00001' acrm_oficina_apertura,
       '00001' acrm_sucursal_apertura,
       '0000000001' acrm_canal_vinculacion,
       categoria_contribuyente  acrm_banca, 
       estado_cliente  acrm_estatus_persona,
       ' '  ACRM_CLASE_CLIENTE,
       cod_actividad_economica_ciiu  acrm_codigo_activida_economica,
       corredor  acrm_codigo_de_ejecutivo,
       cod_ocupacion  acrm_profesion_oficio,
       substr(decode(persona, 'N',lugartrabajo, ' '),1,25)  acrm_empresa_donde_labora,
       decode(persona,'N',fecha_ingreso_lab,' ')  acrm_f_inicio_rela_laboral,  
       substr(decode(persona, 'N',cargo, ' '),1,20)  acrm_cargo_q_desempena,
       decode(persona,'N',(nvl(total_ingr_operac_mes,0) + nvl(total_ingr_no_operac_mes,0)) ,total_ingresos_mes)  acrm_ingresos_mensuales,
       decode(persona,'N',total_egre_operac_mes,total_egresos_mes) acrm_egresos_mensuales,
       decode(persona,'N',total_activos,0)  acrm_total_activos,
       decode(persona,'N',total_pasivos,0) acrm_total_pasivos,
       decode(persona,'N',total_ingr_operac_mes,0) acrm_sueldo,  
       email_cliente  acrm_correo_cliente,
       decode(persona,'N',maneja_recursos_publicos, 'N')  acrm_admon_fondos_publicos,
       decode(persona,'N',desempe_cargo_polit, 'N')  acrm_servidor_pep, 
       decode(persona,'N',empleado, 'N')  acrm_empleado_institucion,
       decode(persona,'N',estado_civil, 'N')  acrm_estado_civil, 
       nacimiento   acrm_f_nacimiento,
       cod_pais_nacimiento  acrm_nacionalidad, 
       substr(decode(persona,'N',lugnacimiento, domicilio),1,15)  acrm_ciudad_nacimiento,
       'San Salvador'  acrm_depto_nacimiento, 
       cod_pais_residencia  acrm_pais_residencia, 
       cod_municipio  acrm_ciudad_residencia,
       substr(direccion,1,50)  acrm_direccion_residencia,
       cod_municipio  acrm_municipio_residencia, 
       decode(persona,'N',telefono_casa, telefono)  acrm_telefono_particular,
       decode(persona,'N',sexo, null)  acrm_genero,
       telefono_movil  acrm_telefono_celular, 
       'N'  acrm_cuenta_en_el_exterior, 
       ' '  acrm_no_seguro_social, 
       replace(replace(nit, '-', ''), '.', '')  acrm_numero_ident_trib,
       'N'  acrm_empresa_en_formacion, 
       '00000'  acrm_clase_empresa,
       '00000'  acrm_tipo_empresa,
       '00000'  acrm_sector_economico,
       nvl(no_empleados,0) acrm_total_empleados,
       declara_impuestos  acrm_regimen_tributario, 
       no_domiciliado  acrm_tipo_contribuyente, 
       0  acrm_total_patrimonio, 
       decode(persona,'N',nvl(total_ingr_no_operac_mes,0),nvl(total_ingr_no_operac_mes,0))  acrm_otros_ingresos, 
       0  acrm_patrimonio_bruto,
       0  acrm_patrimonio_liquido, 
       0  acrm_ing_operacionales, 
       0  acrm_activo_corriente, 
       0  acrm_activo_fijo, 
       0  otros_activos,
       0  acrm_pasivo_corriente,
       0  acrm_pasivo_largo_plazo,
       fecha_mod acrm_fecha_act_datos,
       cod_pais_residencia  acrm_pais_exp_id, 
       cod_departamento  acrm_estado, 
       cod_pais_nacimiento  acrm_pais_nacimiento, 
       cod_municipio  acrm_ciudad_residencia2,
       ' '  acrm_licencia_conducir, 
       ' '  acrm_pais_exp_licencia,
       decode(persona,'N',nombre, ' ')  acrm_primer_nombre,
       ' '  acrm_segundo_nombre,
       decode(persona,'N',p_apellido, ' ')  acrm_primer_apellido, 
       decode(persona,'N',s_apellido, ' ')  acrm_segundo_apellido,
       decode(persona,'N',ape_casada, ' ')  acrm_apellido_casada,
       decode(persona,'N',cod_pais_lab, ' ')  acrm_pais_laboral, 
       ' '  acrm_apartado_postal, 
       ' '  acrm_tipo_licencia,
       decode(persona,'N',cod_departamento_lab, ' ')  acrm_depto_laboral,
       substr(decode(persona,'N',telefono, ' '),1,2)  acrm_telefono_laboral, 
       ' '  acrm_estrato_residencia,
       decode(persona,'N',nivel_academico, ' ')  acrm_nivel_academico,
       decode(persona,'N',(nvl(total_ingr_operac_mes,0) + nvl(total_ingr_no_operac_mes,0) - nvl(total_egre_operac_mes,0)), (nvl(total_ingr_operac_mes,0) + nvl(total_ingr_no_operac_mes,0) - nvl(total_egresos_mes,0)))  acrm_renta_liquida,
       0  acrm_obligaciones_financieras,
       perfil_cliente  acrm_reservado_alfa1,
       '          '  acrm_reservado_alfa2,
       '          '  acrm_reservado_alfa3,
       '          '  acrm_reservado_alfa4,
       '          '  acrm_reservado_alfa5,
       '          '  acrm_reservado_alfa6,
       '          '  acrm_reservado_alfa7,
       '          '  acrm_reservado_alfa8,
       '          '  acrm_reservado_alfa9,
       '          '  acrm_reservado_alfa10,
       0  acrm_reservado_num1,
       0  acrm_reservado_num2,
       0  acrm_reservado_num3,
       0  acrm_reservado_num4,
       0  acrm_reservado_num5, 
       '000000'  acrm_codigo_postal, 
       'N'  acrm_tiene_pobox, 
       ' '  acrm_pobox, 
       decode(persona,'N',telefono_eeuu_extranjero, ' ')  acrm_tel_si_es_extranjero                   
from operaciones.cliente
where estado_cliente = 'A'
order by codcliente;
 
BEGIN
    
        For f1 in C1 loop
            v_string_trama :=   
                            /*SELECT decode(replace(replace(nacional_extranjero, '-', ''), '.', ''), 'N', 'N'||replace(replace(nit, '-', ''), '.', ''),'E', 'N'||replace(replace(nit_extranjero, '-', ''), '.', ''))  acrm_no_identificacion,
       substr(decode(persona, 'N',nombrecliente, 'J', nombre),1,70)   ACRM_NOMBRE_CLIENTE,
       '0001'  ACRM_CODIGO_EMPRESA, 
       codcliente  ACRM_CODIGO_PERSONA,
       persona  ACRM_TIPO_PERSONA_NJ,
       
       decode(persona, 'N',fecha_exp_docu_identidad, ' ')  ACRM_FECHA_EXPEDICION_ID,
       substr(decode(persona, 'N',lug_exp_docu_identidad, ' '),1,15)   ACRM_Ciudad_Expedici�n_ID,
       substr(decode(persona, 'N',lug_exp_docu_identidad, ' '),1,15)   ACRM_Departa_Expedici�n_ID,
       fecha_ingreso  ACRM_FECHA_APERTURA,
       '00001' acrm_oficina_apertura,
       '00001' acrm_sucursal_apertura,
       '0000000001' acrm_canal_vinculacion,
       categoria_contribuyente  acrm_banca, 
       estado_cliente  acrm_estatus_persona,
       ' '  ACRM_CLASE_CLIENTE,
       cod_actividad_economica_ciiu  acrm_codigo_activida_economica,
       corredor  acrm_codigo_de_ejecutivo,
       cod_ocupacion  acrm_profesion_oficio,
       substr(decode(persona, 'N',lugartrabajo, ' '),1,25)  acrm_empresa_donde_labora,
       decode(persona,'N',fecha_ingreso_lab,' ')  acrm_f_inicio_rela_laboral,  
       substr(decode(persona, 'N',cargo, ' '),1,20)  acrm_cargo_q_desempena,
       decode(persona,'N',(nvl(total_ingr_operac_mes,0) + nvl(total_ingr_no_operac_mes,0)) ,total_ingresos_mes)  acrm_ingresos_mensuales,
       decode(persona,'N',total_egre_operac_mes,total_egresos_mes) acrm_egresos_mensuales,
       decode(persona,'N',total_activos,0)  acrm_total_activos,
       decode(persona,'N',total_pasivos,0) acrm_total_pasivos,
       decode(persona,'N',total_ingr_operac_mes,0) acrm_sueldo,  
       email_cliente  acrm_correo_cliente,
       decode(persona,'N',maneja_recursos_publicos, 'N')  acrm_admon_fondos_publicos,
       decode(persona,'N',desempe_cargo_polit, 'N')  acrm_servidor_pep, 
       decode(persona,'N',empleado, 'N')  acrm_empleado_institucion,
       decode(persona,'N',estado_civil, 'N')  acrm_estado_civil, 
       nacimiento   acrm_f_nacimiento,
       cod_pais_nacimiento  acrm_nacionalidad, 
       substr(decode(persona,'N',lugnacimiento, domicilio),1,15)  acrm_ciudad_nacimiento,
       'San Salvador'  acrm_depto_nacimiento, 
       cod_pais_residencia  acrm_pais_residencia, 
       cod_municipio  acrm_ciudad_residencia,
       substr(direccion,1,50)  acrm_direccion_residencia,
       cod_municipio  acrm_municipio_residencia, 
       decode(persona,'N',telefono_casa, telefono)  acrm_telefono_particular,
       decode(persona,'N',sexo, null)  acrm_genero,
       telefono_movil  acrm_telefono_celular, 
       'N'  acrm_cuenta_en_el_exterior, 
       ' '  acrm_no_seguro_social, 
       replace(replace(nit, '-', ''), '.', '')  acrm_numero_ident_trib,
       'N'  acrm_empresa_en_formacion, 
       '00000'  acrm_clase_empresa,
       '00000'  acrm_tipo_empresa,
       '00000'  acrm_sector_economico,
       nvl(no_empleados,0) acrm_total_empleados,
       declara_impuestos  acrm_regimen_tributario, 
       no_domiciliado  acrm_tipo_contribuyente, 
       0  acrm_total_patrimonio, 
       decode(persona,'N',nvl(total_ingr_no_operac_mes,0),nvl(total_ingr_no_operac_mes,0))  acrm_otros_ingresos, 
       0  acrm_patrimonio_bruto,
       0  acrm_patrimonio_liquido, 
       0  acrm_ing_operacionales, 
       0  acrm_activo_corriente, 
       0  acrm_activo_fijo, 
       0  otros_activos,
       0  acrm_pasivo_corriente,
       0  acrm_pasivo_largo_plazo,
       fecha_mod acrm_fecha_act_datos,
       cod_pais_residencia  acrm_pais_exp_id, 
       cod_departamento  acrm_estado, 
       cod_pais_nacimiento  acrm_pais_nacimiento, 
       cod_municipio  acrm_ciudad_residencia2,
       ' '  acrm_licencia_conducir, 
       ' '  acrm_pais_exp_licencia,
       decode(persona,'N',nombre, ' ')  acrm_primer_nombre,
       ' '  acrm_segundo_nombre,
       decode(persona,'N',p_apellido, ' ')  acrm_primer_apellido, 
       decode(persona,'N',s_apellido, ' ')  acrm_segundo_apellido,
       decode(persona,'N',ape_casada, ' ')  acrm_apellido_casada,
       decode(persona,'N',cod_pais_lab, ' ')  acrm_pais_laboral, 
       ' '  acrm_apartado_postal, 
       ' '  acrm_tipo_licencia,
       decode(persona,'N',cod_departamento_lab, ' ')  acrm_depto_laboral,
       substr(decode(persona,'N',telefono, ' '),1,2)  acrm_telefono_laboral, 
       ' '  acrm_estrato_residencia,
       decode(persona,'N',nivel_academico, ' ')  acrm_nivel_academico,
       decode(persona,'N',(nvl(total_ingr_operac_mes,0) + nvl(total_ingr_no_operac_mes,0) - nvl(total_egre_operac_mes,0)), (nvl(total_ingr_operac_mes,0) + nvl(total_ingr_no_operac_mes,0) - nvl(total_egresos_mes,0)))  acrm_renta_liquida,
       0  acrm_obligaciones_financieras,
       perfil_cliente  acrm_reservado_alfa1,
       '          '  acrm_reservado_alfa2,
       '          '  acrm_reservado_alfa3,
       '          '  acrm_reservado_alfa4,
       '          '  acrm_reservado_alfa5,
       '          '  acrm_reservado_alfa6,
       '          '  acrm_reservado_alfa7,
       '          '  acrm_reservado_alfa8,
       '          '  acrm_reservado_alfa9,
       '          '  acrm_reservado_alfa10,
       0  acrm_reservado_num1,
       0  acrm_reservado_num2,
       0  acrm_reservado_num3,
       0  acrm_reservado_num4,
       0  acrm_reservado_num5, 
       '000000'  acrm_codigo_postal, 
       'N'  acrm_tiene_pobox, 
       ' '  acrm_pobox, 
       decode(persona,'N',telefono_eeuu_extranjero, ' ')  acrm_tel_si_es_extranjero*/
                               null;                            
                               
                               
            begin    
                INSERT INTO OPERACIONES.tambtrama_monitor(cod_cia, cod_trama, long_trama, trama )
                values(p_cod_cia, v_cod_trama, length(v_string_trama), v_string_trama);
           end;
        end loop;
        commit;
                                    
END crea_trama_2505_personas;


END PKG_MONITOR;
/

GRANT EXECUTE ON OPERACIONES.PKG_MONITOR TO PUBLIC;
