UPDATE OPERACIONES.TACEMIBV x
SET                                          
    x.dias_al_vencimiento = (select y.dias_vence from EMISIONES17@bolsa y
WHERE x.titulo = y.titulo and
      x.serie  = y.serie  and
      x.Cod_emisor = y.cemisor);

UPDATE OPERACIONES.TACEMIBV x
SET                                          
    x.descripcion_emision = (select y.descripcion from EMISIONES17@bolsa y
WHERE x.titulo = y.titulo and
      x.serie  = y.serie  and
      x.Cod_emisor = y.cemisor);      

commit;      