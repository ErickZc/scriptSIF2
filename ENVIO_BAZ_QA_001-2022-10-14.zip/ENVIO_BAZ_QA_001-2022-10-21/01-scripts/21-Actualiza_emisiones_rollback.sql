UPDATE OPERACIONES.TACEMIBV x
SET x.dias_al_vencimiento = 0,                                         
    x.descripcion_emision = null;      

commit;      