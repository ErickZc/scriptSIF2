UPDATE operaciones.dgeneral
SET recibe_email_act_prohibida = 'mthernandez@bancoazul.com, hrivera@bancoazul.com.sv'
WHERE codigo = '01';
COMMIT;
