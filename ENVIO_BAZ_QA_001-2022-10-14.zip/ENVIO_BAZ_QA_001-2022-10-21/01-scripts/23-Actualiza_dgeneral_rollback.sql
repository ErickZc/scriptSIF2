UPDATE operaciones.dgeneral
SET recibe_email_act_prohibida = null
WHERE codigo = '01';
COMMIT;