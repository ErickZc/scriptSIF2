UPDATE saif2000.tasepara
SET SMTP_OUT_SERVER_ACTIVO = '172.29.1.113'
WHERE Cod_cia = '01';
commit;
