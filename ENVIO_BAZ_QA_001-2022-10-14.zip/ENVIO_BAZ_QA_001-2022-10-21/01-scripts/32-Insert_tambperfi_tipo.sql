SET DEFINE OFF;
Insert into OPERACIONES.TAMBPERFI_TIPO
   (COD_CIA, TIPO, ID, DESDE, HASTA)
 Values
   ('01', 'N', 3, 27, 35);
Insert into OPERACIONES.TAMBPERFI_TIPO
   (COD_CIA, TIPO, ID, DESDE, HASTA)
 Values
   ('01', 'N', 1, 1, 16);
Insert into OPERACIONES.TAMBPERFI_TIPO
   (COD_CIA, TIPO, ID, DESDE, HASTA)
 Values
   ('01', 'N', 4, 36, 44);
Insert into OPERACIONES.TAMBPERFI_TIPO
   (COD_CIA, TIPO, ID, DESDE, HASTA)
 Values
   ('01', 'N', 0, 0, 0);
Insert into OPERACIONES.TAMBPERFI_TIPO
   (COD_CIA, TIPO, ID, DESDE, HASTA)
 Values
   ('01', 'J', 0, 0, 0);
Insert into OPERACIONES.TAMBPERFI_TIPO
   (COD_CIA, TIPO, ID, DESDE, HASTA)
 Values
   ('01', 'N', 2, 17, 26);
Insert into OPERACIONES.TAMBPERFI_TIPO
   (COD_CIA, TIPO, ID, DESDE, HASTA)
 Values
   ('01', 'N', 5, 45, 0);
Insert into OPERACIONES.TAMBPERFI_TIPO
   (COD_CIA, TIPO, ID, DESDE, HASTA)
 Values
   ('01', 'J', 1, 1, 12);
Insert into OPERACIONES.TAMBPERFI_TIPO
   (COD_CIA, TIPO, ID, DESDE, HASTA)
 Values
   ('01', 'J', 2, 13, 19);
Insert into OPERACIONES.TAMBPERFI_TIPO
   (COD_CIA, TIPO, ID, DESDE, HASTA)
 Values
   ('01', 'J', 3, 20, 26);
Insert into OPERACIONES.TAMBPERFI_TIPO
   (COD_CIA, TIPO, ID, DESDE, HASTA)
 Values
   ('01', 'J', 4, 27, 33);
Insert into OPERACIONES.TAMBPERFI_TIPO
   (COD_CIA, TIPO, ID, DESDE, HASTA)
 Values
   ('01', 'J', 5, 34, 0);
Insert into OPERACIONES.TAMBPERFI_TIPO
   (COD_CIA, TIPO, ID, DESDE, HASTA)
 Values
   ('01', 'I', 1, 0, 8);
Insert into OPERACIONES.TAMBPERFI_TIPO
   (COD_CIA, TIPO, ID, DESDE, HASTA)
 Values
   ('01', 'I', 2, 9, 13);
Insert into OPERACIONES.TAMBPERFI_TIPO
   (COD_CIA, TIPO, ID, DESDE, HASTA)
 Values
   ('01', 'I', 3, 14, 18);
Insert into OPERACIONES.TAMBPERFI_TIPO
   (COD_CIA, TIPO, ID, DESDE, HASTA)
 Values
   ('01', 'I', 4, 19, 23);
Insert into OPERACIONES.TAMBPERFI_TIPO
   (COD_CIA, TIPO, ID, DESDE, HASTA)
 Values
   ('01', 'I', 5, 24, 0);
COMMIT;
