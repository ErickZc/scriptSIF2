SET DEFINE OFF;
Insert into OPERACIONES.TAMBVALORES_TIPO_PERFIL
   (COD_CIA, TIPO, ID_PREGUNTA, R1, R2, 
    R3, R4)
 Values
   ('01', 'I', 1, 1, 2, 
    3, 4);
Insert into OPERACIONES.TAMBVALORES_TIPO_PERFIL
   (COD_CIA, TIPO, ID_PREGUNTA, R1, R2, 
    R3, R4)
 Values
   ('01', 'I', 3, 4, 3, 
    2, 1);
Insert into OPERACIONES.TAMBVALORES_TIPO_PERFIL
   (COD_CIA, TIPO, ID_PREGUNTA, R1, R2, 
    R3, R4, DESCRI_PREGUNTA)
 Values
   ('01', 'N', 1, 4, 3, 
    2, 1, '�En qu� rango de edad se encuentra?');
Insert into OPERACIONES.TAMBVALORES_TIPO_PERFIL
   (COD_CIA, TIPO, ID_PREGUNTA, R1, R2, 
    R3, R4, DESCRI_PREGUNTA)
 Values
   ('01', 'N', 2, 2, 1, 
    0, 0, '�Domina un idioma adicional al idioma espa�ol?');
Insert into OPERACIONES.TAMBVALORES_TIPO_PERFIL
   (COD_CIA, TIPO, ID_PREGUNTA, R1, R2, 
    R3, R4, DESCRI_PREGUNTA)
 Values
   ('01', 'N', 3, 1, 2, 
    3, 4, 'Seleccione el rango en el que se encuentra su nivel de ingresos anual. (El Ingreso anual est� conformado por salarios, utilidades, otros ingresos).');
Insert into OPERACIONES.TAMBVALORES_TIPO_PERFIL
   (COD_CIA, TIPO, ID_PREGUNTA, R1, R2, 
    R3, R4, DESCRI_PREGUNTA)
 Values
   ('01', 'N', 6, 4, 3, 
    2, 1, '�A cu�nto equivale el capital disponible para invertir, con respecto al total de su');
Insert into OPERACIONES.TAMBVALORES_TIPO_PERFIL
   (COD_CIA, TIPO, ID_PREGUNTA, R1, R2, 
    R3, R4, DESCRI_PREGUNTA)
 Values
   ('01', 'N', 7, 4, 3, 
    2, 1, ' Se�ale c�mo espera que sea la tendencia de la principal fuente de sus ingresos en');
Insert into OPERACIONES.TAMBVALORES_TIPO_PERFIL
   (COD_CIA, TIPO, ID_PREGUNTA, R1, R2, 
    R3, R4, DESCRI_PREGUNTA)
 Values
   ('01', 'N', 8, 1, 2, 
    3, 0, '�Cu�ntos meses de gastos puede cubrir con sus ahorros, en caso de tener que afrontar situaciones imprevisatas?');
Insert into OPERACIONES.TAMBVALORES_TIPO_PERFIL
   (COD_CIA, TIPO, ID_PREGUNTA, R1, R2, 
    R3, R4, DESCRI_PREGUNTA)
 Values
   ('01', 'N', 9, 1, 2, 
    3, 4, '�Cu�l es el motivo fundamental de su inversi�n en bolsa?');
Insert into OPERACIONES.TAMBVALORES_TIPO_PERFIL
   (COD_CIA, TIPO, ID_PREGUNTA, R1, R2, 
    R3, R4, DESCRI_PREGUNTA)
 Values
   ('01', 'N', 10, 1, 2, 
    3, 0, ' �Cu�l es el horizonte temporal de su inversi�n?');
Insert into OPERACIONES.TAMBVALORES_TIPO_PERFIL
   (COD_CIA, TIPO, ID_PREGUNTA, R1, R2, 
    R3, R4, DESCRI_PREGUNTA)
 Values
   ('01', 'N', 11, 2, 1, 
    0, 0, '�Tiene experiencia de operar en el mercado de valores internacional?');
Insert into OPERACIONES.TAMBVALORES_TIPO_PERFIL
   (COD_CIA, TIPO, ID_PREGUNTA, R1, R2, 
    R3, R4, DESCRI_PREGUNTA)
 Values
   ('01', 'N', 12, 1, 2, 
    3, 0, 'Identifique el rango en que se encuentren sus a�os de experiencia en las negociaciones de los mercados de valores');
Insert into OPERACIONES.TAMBVALORES_TIPO_PERFIL
   (COD_CIA, TIPO, ID_PREGUNTA, R1, R2, 
    R3, R4, DESCRI_PREGUNTA)
 Values
   ('01', 'N', 14, 2, 1, 
    0, 0, ' �Conoce alguna de las siguientes opciones de inversi�n que ofrece el mercado burs�til salvadore�o?');
Insert into OPERACIONES.TAMBVALORES_TIPO_PERFIL
   (COD_CIA, TIPO, ID_PREGUNTA, R1, R2, 
    R3, R4, DESCRI_PREGUNTA)
 Values
   ('01', 'N', 15, 4, 3, 
    2, 1, '�Qu� factor es el que m�s incide, a la hora de toma de decisi�n, en sus inversiones?');
Insert into OPERACIONES.TAMBVALORES_TIPO_PERFIL
   (COD_CIA, TIPO, ID_PREGUNTA, R1, R2, 
    R3, R4, DESCRI_PREGUNTA)
 Values
   ('01', 'N', 16, 1, 2, 
    3, 4, ' �Cu�l ser�a su postura ante fluctuaciones en el mercado del precio de las inversiones en un per�odo determinado las que le exponen a una p�rdida de capital?');
Insert into OPERACIONES.TAMBVALORES_TIPO_PERFIL
   (COD_CIA, TIPO, ID_PREGUNTA, R1, R2, 
    R3, R4, DESCRI_PREGUNTA)
 Values
   ('01', 'N', 17, 1, 2, 
    3, 4, '�Qu� porcentaje, del monto total de las inversiones, se deber�a perder para tomar medidas extremas?');
Insert into OPERACIONES.TAMBVALORES_TIPO_PERFIL
   (COD_CIA, TIPO, ID_PREGUNTA, R1, R2, 
    R3, R4, DESCRI_PREGUNTA)
 Values
   ('01', 'N', 18, 1, 2, 
    3, 4, '�Cu�l de las siguientes afirmaciones se ajusta a mis expectativas de inversi�n?');
Insert into OPERACIONES.TAMBVALORES_TIPO_PERFIL
   (COD_CIA, TIPO, ID_PREGUNTA, R1, R2, 
    R3, R4, DESCRI_PREGUNTA)
 Values
   ('01', 'N', 19, 2, 1, 
    0, 0, '�Posee inversiones de diferente naturaleza (no financieras) ?');
Insert into OPERACIONES.TAMBVALORES_TIPO_PERFIL
   (COD_CIA, TIPO, ID_PREGUNTA, R1, R2, 
    R3, R4, DESCRI_PREGUNTA)
 Values
   ('01', 'J', 1, 1, 2, 
    3, 4, ' �Cu�l es el motivo fundamental de su inversi�n en bolsa?');
Insert into OPERACIONES.TAMBVALORES_TIPO_PERFIL
   (COD_CIA, TIPO, ID_PREGUNTA, R1, R2, 
    R3, R4, DESCRI_PREGUNTA)
 Values
   ('01', 'J', 3, 4, 3, 
    2, 1, '�A cu�nto equivale el capital disponible para invertir, con respecto al patrimonio de la');
Insert into OPERACIONES.TAMBVALORES_TIPO_PERFIL
   (COD_CIA, TIPO, ID_PREGUNTA, R1, R2, 
    R3, R4, DESCRI_PREGUNTA)
 Values
   ('01', 'J', 4, 4, 3, 
    2, 1, 'Se�ale c�mo espera que sea la tendencia de la principal fuente de sus ingresos en los pr�ximos 5 a�os');
Insert into OPERACIONES.TAMBVALORES_TIPO_PERFIL
   (COD_CIA, TIPO, ID_PREGUNTA, R1, R2, 
    R3, R4, DESCRI_PREGUNTA)
 Values
   ('01', 'J', 5, 1, 2, 
    3, 0, '�Cu�l es el horizonte temporal de su inversi�n?');
Insert into OPERACIONES.TAMBVALORES_TIPO_PERFIL
   (COD_CIA, TIPO, ID_PREGUNTA, R1, R2, 
    R3, R4, DESCRI_PREGUNTA)
 Values
   ('01', 'J', 6, 2, 1, 
    0, 0, ' �Ha realizado, con anterioridad, operaciones en el mercado burs�til?');
Insert into OPERACIONES.TAMBVALORES_TIPO_PERFIL
   (COD_CIA, TIPO, ID_PREGUNTA, R1, R2, 
    R3, R4, DESCRI_PREGUNTA)
 Values
   ('01', 'J', 7, 1, 2, 
    3, 0, 'Identifique el rango en que se encuentren sus a�os de experiencia en las negociaciones de los mercados de valores');
Insert into OPERACIONES.TAMBVALORES_TIPO_PERFIL
   (COD_CIA, TIPO, ID_PREGUNTA, R1, R2, 
    R3, R4, DESCRI_PREGUNTA)
 Values
   ('01', 'J', 8, 2, 1, 
    0, 0, '�Conoce alguna de las siguientes opciones de inversi�n que ofrece el mercado burs�til  salvadore�o?');
Insert into OPERACIONES.TAMBVALORES_TIPO_PERFIL
   (COD_CIA, TIPO, ID_PREGUNTA, R1, R2, 
    R3, R4, DESCRI_PREGUNTA)
 Values
   ('01', 'J', 9, 4, 3, 
    2, 1, '�Qu� factor es el que m�s incide, a la hora de toma de decisi�n, en sus inversiones?');
Insert into OPERACIONES.TAMBVALORES_TIPO_PERFIL
   (COD_CIA, TIPO, ID_PREGUNTA, R1, R2, 
    R3, R4, DESCRI_PREGUNTA)
 Values
   ('01', 'J', 10, 1, 2, 
    3, 4, '�Cu�l ser�a su postura ante fluctuaciones en el mercado del precio de las inversiones en un per�odo determinado las que le exponen a una p�rdia de capital?');
Insert into OPERACIONES.TAMBVALORES_TIPO_PERFIL
   (COD_CIA, TIPO, ID_PREGUNTA, R1, R2, 
    R3, R4, DESCRI_PREGUNTA)
 Values
   ('01', 'J', 11, 1, 2, 
    3, 4, '�Qu� porcentaje, del monto total de las inversiones, se deber�a perder para tomar  medidas extremas?');
Insert into OPERACIONES.TAMBVALORES_TIPO_PERFIL
   (COD_CIA, TIPO, ID_PREGUNTA, R1, R2, 
    R3, R4, DESCRI_PREGUNTA)
 Values
   ('01', 'J', 12, 1, 2, 
    3, 4, ' �Cu�l de las siguientes afirmaciones se ajusta a sus expectativas de inversi�n?');
Insert into OPERACIONES.TAMBVALORES_TIPO_PERFIL
   (COD_CIA, TIPO, ID_PREGUNTA, R1, R2, 
    R3, R4, DESCRI_PREGUNTA)
 Values
   ('01', 'J', 13, 2, 1, 
    0, 0, '�Posee inversiones de diferente naturaleza (no financieras)?');
Insert into OPERACIONES.TAMBVALORES_TIPO_PERFIL
   (COD_CIA, TIPO, ID_PREGUNTA, R1, R2, 
    R3, R4)
 Values
   ('01', 'I', 4, 4, 3, 
    2, 1);
Insert into OPERACIONES.TAMBVALORES_TIPO_PERFIL
   (COD_CIA, TIPO, ID_PREGUNTA, R1, R2, 
    R3, R4)
 Values
   ('01', 'I', 5, 1, 2, 
    3, 0);
Insert into OPERACIONES.TAMBVALORES_TIPO_PERFIL
   (COD_CIA, TIPO, ID_PREGUNTA, R1, R2, 
    R3, R4)
 Values
   ('01', 'I', 6, 2, 1, 
    0, 0);
Insert into OPERACIONES.TAMBVALORES_TIPO_PERFIL
   (COD_CIA, TIPO, ID_PREGUNTA, R1, R2, 
    R3, R4)
 Values
   ('01', 'I', 7, 1, 2, 
    3, 0);
Insert into OPERACIONES.TAMBVALORES_TIPO_PERFIL
   (COD_CIA, TIPO, ID_PREGUNTA, R1, R2, 
    R3, R4)
 Values
   ('01', 'I', 8, 1, 2, 
    3, 4);
Insert into OPERACIONES.TAMBVALORES_TIPO_PERFIL
   (COD_CIA, TIPO, ID_PREGUNTA, R1, R2, 
    R3, R4)
 Values
   ('01', 'I', 9, 1, 2, 
    3, 4);
COMMIT;
