INSERT INTO operaciones.tambtact(cod_cia, cod_t_actividad, descripcion, 
                                 bloqueo_automatico_actividad)
VALUES('01', 1, 'Actividad Gen�rica', 'N');
INSERT INTO operaciones.tambtact(cod_cia, cod_t_actividad, descripcion, 
                                 bloqueo_automatico_actividad)
VALUES('01', 2, 'Actividad Prohibida', 'S');

COMMIT;