DELETE operaciones.tambtact;

COMMIT;