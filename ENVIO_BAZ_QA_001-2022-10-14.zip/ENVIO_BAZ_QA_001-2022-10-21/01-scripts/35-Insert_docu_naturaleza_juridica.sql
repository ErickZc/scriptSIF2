    INSERT INTO operaciones.tambnatujur(cod_cia, cod_naturaleza_juridica, descri_naturaleza_juridica)
    VALUES ('01', '00', 'PERSONA NATURAL');
    ---
          insert into operaciones.tambdoxnatjur(cod_cia, cod_naturaleza_juridica, correlativo)
            select n.cod_cia, n.cod_naturaleza_juridica, c.correlativo
            FROM operaciones.tambnatujur n, OPERACIONES.TAMBDFCHECKLIST c
            WHERE  n.cod_cia = c.cod_cia
              AND  n.cod_naturaleza_juridica in ('00') -- personas naturales
              AND  C.PERSONA in ('N', 'A')
              AND  C.ESTADO_DFCKL = 'A';

---
insert into operaciones.tambdoxnatjur(cod_cia, cod_naturaleza_juridica, correlativo)
            select n.cod_cia, n.cod_naturaleza_juridica, c.correlativo
            FROM operaciones.tambnatujur n, OPERACIONES.TAMBDFCHECKLIST c
            WHERE  n.cod_cia = c.cod_cia
              AND  n.cod_naturaleza_juridica NOT in ('00', 'NA') -- personas JURIDICAS
              AND  C.PERSONA in ('J', 'A')
              AND  C.ESTADO_DFCKL = 'A';        

COMMIT;