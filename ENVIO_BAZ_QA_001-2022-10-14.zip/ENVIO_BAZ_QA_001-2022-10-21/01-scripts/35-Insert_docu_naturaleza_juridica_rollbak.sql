delete operaciones.tambnatujur
where cod_cia = '01' 
  and COD_NATURALEZA_JURIDICA  = '00';
  
DELETE operaciones.tambdoxnatjur
where cod_cia = '01';  
COMMIT;