-- TRAMA 2515-PRODUCTOS
----------------------------------------------
delete operaciones.tambtrama_monitor where cod_trama = 2515; 
execute operaciones.pkg_monitor.crea_trama_2515_productos (:p_fecha );
select *  from operaciones.tambtrama_monitor where cod_trama ='2515';
----------------------------------------------
-- TRAMA 2505-PERSONAS
delete operaciones.tambtrama_monitor where cod_trama = 2505;
EXECUTE operaciones.pkg_monitor.crea_trama_2505_personas (:p_fecha );
select *  from operaciones.tambtrama_monitor where cod_trama ='2505';
-------------------------------------------

