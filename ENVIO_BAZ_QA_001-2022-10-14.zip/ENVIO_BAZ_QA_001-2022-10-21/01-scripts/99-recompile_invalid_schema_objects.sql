execute dbms_utility.compile_schema('SAIF2000');
execute dbms_utility.compile_schema('CRM_CUSTOMER');
execute dbms_utility.compile_schema('CONTA');
execute dbms_utility.compile_schema('IVA');
execute dbms_utility.compile_schema('BANCOS');
execute dbms_utility.compile_schema('CUSTODIA');
execute dbms_utility.compile_schema('OPERACIONES');

